package cn.core.net;

import android.os.Environment;
import android.os.Handler;
import android.os.HandlerThread;
import android.util.Log;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.text.SimpleDateFormat;
import java.util.Date;

public class WriteLogger {

    private static final String MY_LOG_PATH_SDCARD_DIR = "/Wifilog/";// 日志文件在sdcard中的路径

    private HandlerThread looperThread;
    private Handler handler;
    private BufferedWriter out;

    public WriteLogger(String logFileName) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd-");// 日志文件格式
        Date now = new Date();
        String needWriteFile = dateFormat.format(now);
        looperThread = new HandlerThread("BackgroundHandler", android.os.Process.THREAD_PRIORITY_BACKGROUND);
        looperThread.start();
        handler = new Handler(looperThread.getLooper());
        File file1 = Environment.getExternalStorageDirectory();
        File path = new File(file1 + MY_LOG_PATH_SDCARD_DIR);
        try {
            if (!path.exists()) {
                path.mkdir();
            }

            File fileTxt = new File(path, needWriteFile + logFileName);
            if (!fileTxt.exists()) {
                fileTxt.createNewFile();
            }
            out = new BufferedWriter(new FileWriter(fileTxt, true));
        } catch (IOException e) {
            Log.w(e.getMessage(), e);
            throw new RuntimeException(e);
        }
    }

    private class WriteLoggerRunnable implements Runnable {

        private String msg;
        private Throwable throwable;

        public WriteLoggerRunnable(String msg, Throwable throwable) {

            this.msg = msg;
            this.throwable = throwable;
        }

        @Override
        public void run() {
            writeLog(msg, throwable);
        }

        private void writeLog(String log, Throwable throwable) {
            try {
                out.write(log);
                out.newLine();
                if (throwable != null) {
                    Writer result = new StringWriter();
                    PrintWriter printWriter = new PrintWriter(result);
                    throwable.printStackTrace(printWriter);
                    String stacktrace = result.toString();
                    printWriter.close();
                    out.write(stacktrace);
                    out.newLine();
                }
                out.flush();
            } catch (Exception e) {
                Log.w("dt", e.getMessage());
            } finally {
            }
        }
    }

    public void post(String msg, Throwable e) {
        handler.post(new WriteLoggerRunnable(msg, e));
    }
}
