package com.paic.pdi.logger.protobuf;

import com.google.protobuf.InvalidProtocolBufferException;

import cn.core.net.Lg;
import cn.core.net.secure.Base64;

public class ProtobufTest {

    public static void main(String[] args) {

        ActionV2ProtoBuf.ActionV2Message.Builder builder = ActionV2ProtoBuf.ActionV2Message.newBuilder();

        ActionV2ProtoBuf.ActionV2Message log = builder.build();

        byte[] value = log.toByteArray();

        String base64str = Base64.encode(value);
        Lg.i(base64str);

        try {
            ActionV2ProtoBuf.ActionV2Message log2 = ActionV2ProtoBuf.ActionV2Message.parseFrom(value);
            Lg.i(log2.toString());

        } catch (InvalidProtocolBufferException e) {
            Lg.w(e);
        }
    }

}
