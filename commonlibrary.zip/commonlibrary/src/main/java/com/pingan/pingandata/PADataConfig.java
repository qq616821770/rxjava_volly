package com.pingan.pingandata;

import android.text.TextUtils;

/**
 * Created by yueang on 16/10/13.
 */

public class PADataConfig {
    public static String getEnvironment() {
        return Environment.getEnvironment();
    }

    public static boolean isStg() {
        return Environment.isStg();
    }

    public static boolean isPrd() {
        return Environment.isPrd();
    }

    /**
     * 以下是几个顶级域名，所有域名都从这里找，找不到可以新增在这条注释下方
     *
     */

    private static String getBaseUrl() {
        if (isStg()) {
            return "http://test-wifi.pingan.com.cn:61080";
        } else {
            return "http://wifi.pingan.com.cn";
        }
    }

    private static String getCoreUrl() {
        if (isStg()) {
            return "http://test-wifi.pingan.com.cn:61080/pawf-core/rest";
        } else {
            return "http://wifi.pingan.com.cn/pawf-core/rest";
        }
    }

    private static String getUcUrl() {
        if (isStg()) {
            return "http://test-wifi.pingan.com.cn:61080/pawf-uc/rest";
        } else {
            return "http://wifi.pingan.com.cn/pawf-uc/rest";
        }
    }

    private static String getLoggerUrl() {
        if (isStg()) {
            return "http://test-pawf-account.pingan.com.cn:51080/pawf-logger/rest";
        } else {
            return "http://pawf-account.pingan.com.cn/pawf-logger/rest";
        }
    }
    private static String getPawfAccountUrl() {
        if (isStg()) {
            return "http://test-pawf-account.pingan.com.cn:51080/pawf-account";
        } else {
            return "http://pawf-account.pingan.com.cn/pawf-account";
        }
    }

    public static String getAppUsedFlowUrl(){
        return getPawfAccountUrl()+"/vpn/curMon/freeFlowUsed";
    }

    private static String getPayUrl() {
        if (isStg()) {
            return "http://test-wifi.pingan.com.cn:61080/pawf-pay/rest";
        } else {
            return "http://wifi.pingan.com.cn/pawf-pay/rest";
        }
    }

    private static String getDfpUrl() {
        if (isStg()) {
            return "http://test-wifi.pingan.com.cn:61080/pawf-dfp/rest";
        } else {
            return "http://wifi.pingan.com.cn/pawf-dfp/rest";
        }
    }

    private static String getCmsUrl() {
        if (isStg()) {
            return "http://test-wifi.pingan.com.cn:61080/pawf-cms/rest";
        } else {
            return "http://wifi.pingan.com.cn/pawf-cms/rest";
        }
    }

    public static String getNopUrl() {
        if (isStg()) {
            return "http://test1-pawfhd.pingan.com.cn:31080/pawf-nop/rest";
        } else {
            return "http://pawfhd.pingan.com.cn/pawf-nop/rest";
        }
    }

    public static String getOpUrl() {
        if (isStg()) {
            return "http://test1-pawfhd.pingan.com.cn:31080/pawf-op/rest";
        } else {
            return "https://pawfhd.pingan.com.cn/pawf-op/rest";
        }
    }

    public static String getFreeVPNBaseUrl() {
        if (isStg()) {
            return "http://test-wifi.pingan.com:50080/page/mianliu";
        } else {
            return "http://wifi.pingan.com/page/mianliu";
        }
    }


    public static String getMyVPNServiceUrl() {
        if (isStg()) {
            return "http://test-wifi.pingan.com:50080/page/dfp/my-service.html";
        } else {
            return "http://wifi.pingan.com/page/dfp/my-service.html";
        }
    }


    public static String getDPUploadActionListUrl() {
        return getLoggerUrl() + "/logger/actionLoggerV3";
    }

    public static String getDPUploadUserInfoUrl() {
        return getLoggerUrl() + "/logger/saveUserInfoV3";
    }

    public static boolean shouldShowPermission() {
        return false;
    }

    public static String getSendMsgUrl() {
        return getUcUrl() + "/member/padt/sendCode";
    }

    public static String getVerifyRegister() {
        return getUcUrl() + "/member/padt/verifyRegisterMsg.do";
    }

    public static String getUserLoginrUrl() {
        return getUcUrl() +  "/member/padt/userlogin.do";
    }

    /**
     * 忘记密码验证接口
     */
    public static String getForgetPasswordUrl() {
        return getUcUrl() +  "/member/padt/forgetPassword.do";
    }

    /**
     * 忘记密码重置密码验证接口
     */
    public static String getPassworedResetUrl() {
        return getUcUrl() +  "/member/padt/passwordReset.do";
    }


    /**
     * 多盟上报接口
     */
    public static String getDuoMengUploadUrl() {
        return getUcUrl() +  "/statistic/V2/userBehavior";
    }

    public static String getValidationMsUrl() {
        return getCoreUrl() + "/validationMsgV4";
    }

    public static String getPushType() {
        return Environment.getPushType();
    }


    public static String getUserShareUrl() {
        return getUcUrl() + "/ucSession/v2/userShare";
    }

    /**
     * 获取用户个人信息接口
     *
     * @return
     */
    public static String getUserInfo() {
        return getUcUrl() + "/ucSession/padt/personalInfo";
    }

    /**
     * 根据urlKey 获取相应分享的 url值
     *
     * @return
     */
    public static String getAppShareUrl(String urlKey) {
        if (urlKey == null || TextUtils.isEmpty(urlKey)) {
            return "http://wifi.pingan.com/dc";
        }
        if ("layabox".equals(urlKey)) {
            return "http://wifi.pingan.com/dc";
        } else {
            return "http://wifi.pingan.com/dc";
        }
    }

    public static String getPayOrderDataUrl() {
        return getPayUrl() + "/login/wifipay/payapi";
    }

    public static String getUserRegisterUrl() {
        return getUcUrl() + "/member/padt/userRegister";
    }

    /**
     * 剩余流量查询URL
     * @return
     */
    public static String getFlowStateUrl() {
        return getDfpUrl() + "/ucLogin/vpn/curUsedFlowV2";
    }

    /**
     * 购买流量状态URL
     * @return
     */
    public static String getBuyFlowStateUrl() {
        return getDfpUrl() + "/ucLogin/vpn/recentlyObtainStatus";
    }

    /**
     * Loading拉取所有配置URL
     * @return
     */
    public static String getChannelColumnUrl() {
        return getCmsUrl() + "/cms/getAllChannelColumnAdMap";
    }

    /**
     * home banner URL
     * @return
     */
    public static String getHomeBannerUrl() {
        return getCmsUrl() + "/cms/getAllChannelColumnAd";
    }


    /**
     * 仓库流量URL
     * @return
     */
    public static String getStoreHoseFlowUrl() {
        return getNopUrl() + "/uclogin/padt/dataHouse";
    }


    /**
     * 重新领取流量URL
     * @return
     */
    public static String getReObtainUrl() {
        return getDfpUrl() + "/ucLogin/vpn/reObtain";
    }


    public static String getUmengAppKey() {
        if (!isPrd()) {
            return "5822c3476e27a4688b00311e";
        } else {
            return "580ec06d65b6d64a9b0021f0";
        }
    }

    public static String getHeartBeatUrl() {
        return getUcUrl() + "/ucSession/v2/heartLogin.do";
    }

    public static String getPersistLoginUrl() {
        return getUcUrl() + "/member/padt/persistLogin.do";
    }

    public static String getH5BaseUrl() {
        if (isStg()) {
            return "http://test-wifi.pingan.com:50080/w/pa_dt/app";
        }

        return "http://wifi.pingan.com/w/pa_dt/app";
    }

    /**
     * APP免流包名
     */
    public static String getAPPFreeFlowPackageName() {
        if(isStg()){
            return "com.pingan.pinganwifi.yingyongmianliu.test";
        }else{
            return "com.pingan.pinganwifi.yingyongmianliu";
        }
    }
    /**
     * 手机免流包名
     */
    public static String getGlobalFreeFlowPackageName() {
        if(isStg()){
            return "com.pingan.pinganwifi.shoujimianliu.test";
        }else{
            return "com.pingan.pinganwifi.shoujimianliu";
        }
    }


    /**
     * 获取VPN外部免流使用的应用包名
     *
     * @return
     */
    public static String getFreeVPNFlowFingerPrintGlobal() {
        if(isStg()){
            return "2A:E8:26:34:73:8C:B7:96:06:C6:CB:9C:0E:E1:9A:03";
        }else{
            return "43:BE:F5:E6:FB:21:1F:7F:9E:40:44:F7:AC:CE:0D:C3";
        }
    }

    /**
     * 获取VPN外部免流非全局使用的应用包名
     *
     * @return
     */
    public static String getFreeVPNFlowPkgNameNoneGlobal() {
        if(isStg()){
            return "com.pingan.pinganwifi.yingyongmianliu.test";
        }else{
            return "com.pingan.pinganwifi.yingyongmianliu";
        }
    }


    /**
     * 获取VPN外部免流使用的应用包名
     *
     * @return
     */
    public static String getFreeVPNFlowPkgNameGlobal() {
        if(isStg()){
            return "com.pingan.pinganwifi.shoujimianliu.test";
        }else{
            return "com.pingan.pinganwifi.shoujimianliu";
        }
    }


    /**
     * 获取免流使用的应用包名
     *
     * @return
     */
    public static String getFreeFlowPkgName() {
        if(isStg()){
            return "com.pingan.pinganwifi.test";
        }else{
            return "com.pingan.pinganwifi";
        }
    }

    public static String getVpnFlowDetailUrl() {
        return getUcUrl() + "/w/pa_wifi/app/mianliu/control/index-andro.html";
    }


    /*
    *  修改用户密码接口
    * */
    public static String getNewUserResetPwdUrl() {
        return getUcUrl() + "/login/updPassword.do";
    }

    /*
    * 修改手机号接口
    * */
    public static String getMatchMobileVcodeUrl() {
        return getUcUrl() + "/ucSession/padt/updateMobile.do";
    }

    /**
     * 查询当前微信账户是否绑定状态 url
     */
    public static String getWXBindStateUrl() {
        return getUcUrl() + "/thirdapp/V2/wxLoginPawf";
    }

    /**
     * 获取账户绑定 url
     */
    public static String getBindAccountUrl() {
        return getUcUrl() + "/ucSession/thirdapp/V2/bindPawfUser";
    }

    /**
     * 查询第三方联合登录校验手机号码是否注册 url
     * */
    public static String getCheckMobileRegUrl() {
        return getUcUrl() + "/member/padt/checkMobileReg";
    }

    /**
     * 查询账户绑定第三方列表 url
     * */
    public static String getBindAccountListUrl() {
        return getUcUrl() + "/ucSession/thirdapp/queryUserBindInfo";
    }

    /**
     *  解绑大冲用户接口
     * */
    public static String getUnbindPaDataUserUrl() {
        return getUcUrl() + "/ucSession/thirdapp/V2/unbindPawfUser";
    }

    /**
    * 退出登录接口
    * */
    public static String getLogout() {
        return getUcUrl() + "/login/logout.do";
    }

    public static String getUploadImage() {
        return getUcUrl() + "/ucSession/padt/uploadImage.do";
    }

    /**
     * 获得七牛地址
     */
    public static String getqiniucdnUrl() {

        if (isStg()) {
            return "http://7xj0li.com2.z0.glb.qiniucdn.com/";
        } else {
            return "http://7xj0uu.com2.z0.glb.qiniucdn.com/";
        }
    }

    /*
    * 获得上传凭证地址
    * */
    public static String getUploadToken() {
        return getUcUrl() + "/login/getUploadToken.do";
    }


    /**
     * 更新用户个人信息接口
     *
     * @return
     */
    public static String getUpdateUserInfoUrl() {
        return getUcUrl() + "/ucSession/v2/updPersonalInfo";
    }

    /**
     * 第三方广告服务接口
     *
     * @return
     */
    public static String getThirdPartyAd() {
        return getCmsUrl() + "/cms/getThirdPartyAd";
    }

    /**
     * 搜狐新闻服务接口
     *
     * @return
     */
    public static String getNewsAPI() {
        return "http://api.m.sohu.com/news/partner/pinganwifi/";
    }

    /**
     * 获取流量接口
     *
     * @return
     */
    public static String getFlowUrl() {
        return getNopUrl() + "/uclogin/padt/getData";
    }

    /**
     * 广告曝光量/点击量统计接口
     *
     * @return
     */
    public static String getExposureUrl() {
        return getNopUrl() + "/padt/showData";
    }

    public static String getCheckVersionUrl() {
        return getCoreUrl() + "/V2/getVersion";
    }

    /**
     * 消息中心消息类别列表
     *
     * @return
     */
    public static String getMsgTypeListConfig() {
        return getUcUrl() + "/login/msgcenter/v2/getMsgTypeList";
    }

    /**
     * 消息中心某个类别下的详细消息
     *
     * @return
     */
    public static String getMsgListConfig() {
        return getUcUrl() + "/login/msgcenter/v3/getMsgList";
    }


    /*
    * 获得历史记录中已充值流量的地址
    * */
    public static String getRechargedFlowUrl() {
        return getDfpUrl() + "/ucLogin/vpn/allFlow";
    }


    /*
    * 获得历史记录中已使用流量的地址
    * */
    public static String getUsedFlowUrl() {
        return getDfpUrl() + "/ucLogin/vpn/hisUsedFlow";
    }


    /**
     * 获取上报pushid接口
     *
     * @return
     */
    public static String getReportPushIdUrl() {
        return getUcUrl() + "/push/padt/addInfo";
    }

    /*
    * 小红点请求接口
    *
    * */
    public static String getRedPointConfig() {
        return getOpUrl() + "/activityList/getReadPoint";
    }

    /**
     * 分享接口
     */
    public static String getShareConfig() {
        return getOpUrl() + "/getShareWordlist";
    }

    /**
     * 请求分享接口中的groupId值
     */
    public static String getGroupIdConfig() {
        if (isStg()) {
            return "2";
        } else {
            return "4";
        }
    }

    public static String getHZADIdByType(int type) {
        if (isStg()) {
            switch (type) {
                case 0:
                    return "2000505";
                case 1:
                case 2:
                    return "2000483";
            }
        } else {
            switch (type) {
                case 0:
                    return "1021120";
                case 1:
                    return "1021195";
                case 2:
                    return "1021196";
            }
        }

        return "";
    }

}
