package com.pingan.pingandata.utils;

import android.content.Context;
import android.content.res.Resources;
import android.os.Handler;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.pingan.commonlibrary.R;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

import cn.core.net.Lg;

public class ExToast {

    public static final int LENGTH_SHORT = 2 * 1000;
    public static final int LENGTH_LONG = 4 * 1000;

    private Toast toast;
    private Context mContext;
    private int mDuration = LENGTH_SHORT;
    private int animations = R.style.toast_anim;
    private static boolean isShow = false;
    private static String msg;
    private Object mTN;
    private Method show;
    private Method hide;

    private Handler handler = new Handler();

    public ExToast(Context context) {
        this.mContext = context;
        if(toast == null) {
            toast = new Toast(mContext);
        }
    }

    private Runnable hideRunnable = new Runnable() {
        @Override
        public void run() {
            hide();
        }
    };

    public void show() {
        if(TextUtils.isEmpty(msg)) return;
        if(isShow) return;
        Lg.i("isShow:" + isShow);
        initTN();
        try {
            show.invoke(mTN);
        } catch (Exception e) {
            Lg.w(e);
        }
        isShow = true;
        //判断duration，如果大于#LENGTH_ALWAYS 则设置消失时间
        handler.postDelayed(hideRunnable, mDuration);
    }

    /**
     * Close the view if it's showing, or don't show it if it isn't showing yet.
     * You do not normally have to call this.  Normally view will disappear on its own
     * after the appropriate duration.
     */
    public void hide() {
        if(!isShow) return;
        try {
            hide.invoke(mTN);
        } catch (Exception e) {
            Lg.w(e);
        }
        isShow = false;
    }

    public void setDuration(int duration) {
        mDuration = duration;
    }

    public int getDuration() {
        return mDuration;
    }

    public static ExToast makeText(Context context, String text, int duration) {
        Toast toast = Toast.makeText(context, text, Toast.LENGTH_SHORT);
        msg = text;
        ExToast exToast = new ExToast(context);
        exToast.toast = toast;
        exToast.mDuration = duration;
        exToast.toast.setGravity(Gravity.CENTER, 0, 0);
        if(!TextUtils.isEmpty(msg)) {
            View root = LayoutInflater.from(context).inflate(R.layout.toast_root, null);
            TextView tv = (TextView) root.findViewById(R.id.tv_toast);
            tv.setText(text);
            toast.setView(root);
        }
        return exToast;
    }

    /**
     * 带图标的Toast
     * @param isOk  成功或失败,成功没有msg,失败则显示msg
     * @param result  Toast底部的提示文案,类似 '发送成功'、'注册成功'等
     * @param text  Toast的msg文字,一般由后台返回
     */
    public static ExToast makeText(Context context, boolean isOk, String result, String text, int duration) {
        Toast toast = Toast.makeText(context, text, Toast.LENGTH_SHORT);
        msg = text;
        ExToast exToast = new ExToast(context);
        exToast.toast = toast;
        exToast.mDuration = duration;
        exToast.toast.setGravity(Gravity.CENTER, 0, 0);
        if(!TextUtils.isEmpty(msg)) {
            View root = LayoutInflater.from(context).inflate(R.layout.toast_icon_root, null);
            TextView tvMsg = (TextView) root.findViewById(R.id.tv_toast);
            TextView tvResult = (TextView) root.findViewById(R.id.tv_toast_result);
            ImageView imageView = (ImageView) root.findViewById(R.id.tv_toast_icon);
            if (isOk) {
                //成功不显示msg
                tvMsg.setVisibility(View.GONE);
                //显示Result
                tvResult.setVisibility(View.VISIBLE);
                tvResult.setText(result);
                imageView.setBackgroundResource(R.drawable.toast_success_bg);
            } else {
                //失败显示msg
                tvMsg.setVisibility(View.VISIBLE);
                tvMsg.setText(text);
                //不显示Result
                tvResult.setVisibility(View.GONE);
                imageView.setBackgroundResource(R.drawable.toast_fail_bg);
            }
            toast.setView(root);
        }
        return exToast;
    }

    public static ExToast makeText(Context context, int resId, int duration) throws Resources.NotFoundException {
        return makeText(context, context.getResources().getString(resId), duration);
    }

    public int getAnimations() {
        return animations;
    }

    public void setAnimations(int animations) {
        this.animations = animations;
    }

    private void initTN() {
        try {
            Field tnField = toast.getClass().getDeclaredField("mTN");
            tnField.setAccessible(true);
            mTN = tnField.get(toast);
            show = mTN.getClass().getMethod("show");
            hide = mTN.getClass().getMethod("hide");

            /**设置动画*/
            if(animations != -1) {
                Field tnParamsField = mTN.getClass().getDeclaredField("mParams");
                tnParamsField.setAccessible(true);
                WindowManager.LayoutParams params = (WindowManager.LayoutParams) tnParamsField.get(mTN);
                params.windowAnimations = animations;
            }
            /**调用tn.show()之前一定要先设置mNextView*/
            Field tnNextViewField = mTN.getClass().getDeclaredField("mNextView");
            tnNextViewField.setAccessible(true);
            tnNextViewField.set(mTN, toast.getView());

        } catch (Exception e) {
            Lg.w(e);
        }
    }

}