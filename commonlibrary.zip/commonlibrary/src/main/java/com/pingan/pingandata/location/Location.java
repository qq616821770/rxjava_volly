package com.pingan.pingandata.location;

/**
 * Created by yueang on 16/10/13.
 */

public class Location {

    private String longitude;
    private String latitude;
    private String type;

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getLatitude() {
        return latitude;
    }

    public String getType() {
        return type;
    }

    public void setType(Type type) {
        this.type = type.name();
    }

    public enum Type {
        gaode;
    }
}
