package com.pingan.pingandata.mvp;

/**
 * Created by yueang on 2016/10/31.
 */

public interface BaseView<T> {
    void setPresenter(T presenter);
}
