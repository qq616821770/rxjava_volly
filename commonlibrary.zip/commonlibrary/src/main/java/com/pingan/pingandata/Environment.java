package com.pingan.pingandata;

/**
 * 不要提交此文件，此文件由CI自动修改
 * Created by yueang on 2016/10/31.
 */

class Environment {
    private static final String ENVIRONMENT = "stg";
    private static final String PUSH_TYPE = "getui";

    static boolean isStg() {
        return "stg".equalsIgnoreCase(ENVIRONMENT);
    }

    public static boolean isPrd() {
        return "prd".equalsIgnoreCase(ENVIRONMENT);
    }

    static String getEnvironment() {
        return ENVIRONMENT;
    }

    static String getPushType() {
        return PUSH_TYPE;
    }
}
