package com.pingan.pingandata.service;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.support.annotation.Nullable;

import com.pingan.ak.component.bus.BaseBusEvent;
import com.pingan.ak.component.bus.RxBus;
import com.pingan.pingandata.Constance;

import cn.core.net.Lg;

/**
 * Created by yueang on 2016/11/11.
 */

public class UniversalService extends Service {

    private FixedRateTask fixedRateTask;

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        fixedRateTask = new FixedRateTask();
        fixedRateTask.start();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        fixedRateTask.abort();
        fixedRateTask = null;
    }

    private class FixedRateTask extends Thread {

        private volatile boolean shouldAbort = false;

        public void abort() {
            shouldAbort = true;
        }

        @Override
        public void run() {
            while (!shouldAbort) {
                Lg.d("固定频率广播发出");
                RxBus.getInstance().send(BaseBusEvent.APP_FIXED_RATE_TIMER_EVENT);

                try {
                    sleep(Constance.APP_FIXED_RATE_INTERVAL);
                } catch (InterruptedException e) {
                    Lg.w(e);
                }
            }
        }
    }
}
