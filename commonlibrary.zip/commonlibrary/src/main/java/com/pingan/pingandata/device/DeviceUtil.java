package com.pingan.pingandata.device;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.WindowManager;

import com.tendcloud.tenddata.TCAgent;

import java.lang.reflect.Method;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import cn.core.net.Lg;

import static com.pingan.pingandata.common.CommonUtils.isSimExist;

/**
 * Created by yueang on 16/10/14.
 */

public class DeviceUtil {

    public static boolean isWifiEnabled(Context context) {
        WifiManager wifiManager = (WifiManager) context.getSystemService(Context.WIFI_SERVICE);
        return wifiManager.isWifiEnabled();
    }

    /**
     * 关闭Wifi
     */
    public static boolean closeWifi(Context context) {
        WifiManager wifiManager = (WifiManager) context.getSystemService(Context.WIFI_SERVICE);
        if (!wifiManager.isWifiEnabled()) {
            return true;
        } else {
            return wifiManager.setWifiEnabled(false);
        }
    }

    public static String getDeviceId(Context context) {
        return TCAgent.getDeviceId(context);
    }

    public static String getImei(Context context) {
        String imei = null;
        TelephonyManager mTelephonyManager = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
        if (mTelephonyManager != null) {
            imei = mTelephonyManager.getDeviceId();
        }
        return imei == null ? "" : imei;
    }

    /**
     * 取得当前sim手机卡的imsi
     */
    public static String getIMSI(Context context) {
        if (null == context) {
            return "";
        }

        String imsi = "";
        try {
            TelephonyManager tm = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
            imsi = tm.getSubscriberId();
        } catch (Exception e) {
            Lg.w(e);
        }
        return imsi;
    }

    public static String getPhoneType() {
        return android.os.Build.MODEL;
    }

    public static String getDeviceType() {
        return "android";
    }

    /**
     * get system version
     *
     * @return
     */
    public static String getSystemVersion() {
        return android.os.Build.VERSION.RELEASE;
    }

    /**
     * get ophone brand
     *
     * @return
     */
    public static String getSystemOS() {
        return "Android";
    }

    /**
     * get System version code
     *
     * @return
     */
    public static int getSystemVersionCode() {
        return android.os.Build.VERSION.SDK_INT;
    }

    private static String macPattern = "[0-9A-F][0-9A-F]:[0-9A-F][0-9A-F]:[0-9A-F][0-9A-F]:[0-9A-F][0-9A-F]:[0-9A-F][0-9A-F]:[0-9A-F][0-9A-F]";

    public static String getMac(Context context) {
        String mac = "";
        try {
            WifiManager wifi = (WifiManager) context.getSystemService(Context.WIFI_SERVICE);
            WifiInfo info = wifi.getConnectionInfo();
            if (info != null)
                mac = info.getMacAddress();
            if (mac != null && mac.replaceAll(" ", "").toUpperCase(Locale.getDefault()).matches(macPattern)) {
                mac = mac.replaceAll(" ", "").toUpperCase(Locale.getDefault());
            } else {
                mac = "00:00:00:00:00:00";
            }
        } catch (Exception e) {
            Lg.e(DeviceUtil.class.getName() + " getMac ", e);
        }
        return mac;
    }

    public static String getWifiIpAddress(Context context) {

        String ip = "";
        String ssid = "";
        try {
            WifiManager wm = (WifiManager) context.getSystemService(Context.WIFI_SERVICE);
            WifiInfo info = wm.getConnectionInfo();
            if (info != null) {
                ip = intToInetAddress(info.getIpAddress());
                ssid = info.getSSID();
                if (ssid != null) {
                    ssid = ssid.replaceAll("\"", "");
                }
            }
        } catch (Exception e) {
            Lg.w(e);
        }

        return ip;
    }

    private static String intToInetAddress(int hostAddress) throws UnknownHostException {
        byte[] addressBytes = {(byte) (0xff & hostAddress), (byte) (0xff & (hostAddress >> 8)),
                (byte) (0xff & (hostAddress >> 16)), (byte) (0xff & (hostAddress >> 24))};
        return InetAddress.getByAddress(addressBytes).getHostAddress();
    }

    public static boolean isWiFiNetWork(Context context) {
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkINfo = cm.getActiveNetworkInfo();
        if (networkINfo != null && networkINfo.getType() == ConnectivityManager.TYPE_WIFI) {
            return true;
        }
        return false;
    }


    public static boolean isMobileConnected(Context context) {
        boolean isOpen = false;
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        try {
            // 方法被隐藏，不能保证绝对能读出数据流量是否开启
            Method method = ConnectivityManager.class.getMethod("getMobileDataEnabled");
            isOpen = (Boolean) method.invoke(cm);
        } catch (Exception e) {
            isOpen = false;
        }
        return isOpen;
    }

    /**
     * @description:开启关闭移动网络
     */
    public static boolean handleOnOffMobileData(Context context) {
        ConnectivityManager connManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        try {
            Class<?> cmClass = connManager.getClass();
            Class<?>[] argClasses = new Class[1];
            argClasses[0] = boolean.class;
            // 反射ConnectivityManager中hide的方法setMobileDataEnabled，可以开启和关闭GPRS网络
            Method method = null;

            if (!isSimExist(context)) {
                Lg.d("Mobile phone no SIM card.");
                return false;
            }
            method = cmClass.getMethod("setMobileDataEnabled", argClasses);
            method.invoke(connManager, true);
            return true;
        } catch (Exception e) {
            Lg.w(e);
        }

        return false;
    }


    /**
     * 返回手机服务商名字
     */
    public static String getProvidersName(Context context) {
        String ProvidersName = null;
        // 返回唯一的用户ID;就是这张卡的编号神马的
        String IMSI = getIMSI(context);
        if (IMSI == null) {
            return null;
        }

        // IMSI号前面3位460是国家，紧接着后面2位00 02是中国移动，01是中国联通，03是中国电信。
        if (IMSI.startsWith("46000") || IMSI.startsWith("46002")) {
            ProvidersName = "YD";
        } else if (IMSI.startsWith("46001")) {
            ProvidersName = "LT";
        } else if (IMSI.startsWith("46003")) {
            ProvidersName = "DX";
        } else {
            ProvidersName = "OTHER:" + IMSI;
        }
        return ProvidersName;
    }

    /**
     * 返回手机服务商编号
     */
    public static String getProvidersCode(Context context) {
        String ProvidersName = null;
        // 返回唯一的用户ID;就是这张卡的编号神马的
        String IMSI = getIMSI(context);
        if (IMSI == null) {
            return null;
        }

        // IMSI号前面3位460是国家，紧接着后面2位00 02 07是中国移动，01是中国联通，03是中国电信。
        if (IMSI.startsWith("46000") || IMSI.startsWith("46002")|| IMSI.startsWith("46007")) {
            ProvidersName = "10003";
        } else if (IMSI.startsWith("46001")) {
            ProvidersName = "10004";
        } else if (IMSI.startsWith("46003")) {
            ProvidersName = "10002";
        } else {
            ProvidersName = "OTHER:" + IMSI;
        }
        return ProvidersName;
    }

    //移动用户支持赠送且登录手机号与SIM卡手机号一致
    public static boolean isSupportYD(String phone, Context context) {
        if (null == context || TextUtils.isEmpty(phone)) {
            return false;
        }

        String yd = "^1(34[0-8]|(3[5-9]|5[017-9]|8[278])\\d)\\d{7}$";//移动
        Pattern p0 = Pattern.compile(yd);
        Matcher m0 = p0.matcher(phone);
        String providersName = m0.matches() ? "YD" : "";
        return providersName.equals(getProvidersName(context));
    }

    //联通用户支持赠送且登录手机号与SIM卡手机号一致
    public static boolean isSupportLT(String phone, Context context) {
        if(null == context || TextUtils.isEmpty(phone)) {
            return false;
        }

        String lt = "^1(3[0-2]|5[256]|8[56])\\d{8}$";                //联通
        Pattern p1 = Pattern.compile(lt);
        Matcher m1 = p1.matcher(phone);
        String providersName = m1.matches() ? "LT" : "";
        return providersName.equals(getProvidersName(context));
    }

    /**
     * 获取网络类型
     *
     * @return 1为wifi连接，2为2g网络，3为3g网络，-1为无网络连接
     */
    public static String getNetworkerStatus(Context context) {
        ConnectivityManager conMan = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo info = conMan.getActiveNetworkInfo();
        if (null != info && info.isConnected()) {
            if (info.getType() == ConnectivityManager.TYPE_MOBILE) {
                switch (info.getSubtype()) {
                    case 1:
                    case 2:
                    case 4:
                        // 2G网络
                        return "2G";
                    default:
                        // 3G及其以上网络
                        return "3G";
                }
            } else if (info.getType() == ConnectivityManager.TYPE_WIFI) {
                // wifi网络
                return "wifi";
            }
        }
        // 无网络
        return "";
    }

    public static String getAndroidId(Context context) {
        return Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ANDROID_ID);
    }

    public static String getManufacturer() {
        return Build.MANUFACTURER;
    }

    public static String getBrand() {
        return Build.BRAND;
    }

    public static String getPhoneModel() {
        return Build.MODEL;
    }

    public static int getScreenWidth(Context context) {
        WindowManager wm = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        DisplayMetrics dm = new DisplayMetrics();
        wm.getDefaultDisplay().getMetrics(dm);
        return dm.widthPixels;
    }

    public static int getScreenHeight(Context context) {
        WindowManager wm = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        DisplayMetrics dm = new DisplayMetrics();
        wm.getDefaultDisplay().getMetrics(dm);
        return dm.heightPixels;
    }
}
