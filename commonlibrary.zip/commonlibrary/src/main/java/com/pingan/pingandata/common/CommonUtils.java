package com.pingan.pingandata.common;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.pm.Signature;
import android.graphics.drawable.Drawable;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.PowerManager;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.WindowManager;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.Closeable;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.DecimalFormat;
import java.util.Enumeration;
import java.util.List;

import cn.core.base.NetUtil;
import cn.core.net.Lg;

/**
 * Created by yueang on 16/9/20.
 */
public class CommonUtils {

    /**
     * 获取当前渠道名称, 使用PackerNg方案获取渠道
     * @link https://github.com/mcxiaoke/packer-ng-plugin
     */
    public static String getChannelName(Context context) {
        return PackerNg.getMarket(context, "dt_default.com");
    }

    /**
     * 获取当前程序的版本号
     */
    public static int getVersionCode(Context context) {
        PackageManager packageManager;
        // getPackageName()是你当前类的包名，0代表是获取版本信息
        int code = 0;
        try {
            packageManager = context.getPackageManager();
            PackageInfo packInfo = packageManager.getPackageInfo(context.getPackageName(), 0);
            code = packInfo.versionCode;
        } catch (Exception e) {
            Lg.w(e);
        }
        return code;
    }

    /**
     * 获取当前程序的版本名
     * （去掉Deprecated注解，因为没有必要依赖某个组件的初始化）
     */
    public static String getVersionName(Context context) {
        PackageManager packageManager;
        String name = "";
        try {
            packageManager = context.getPackageManager();
            PackageInfo packInfo = packageManager.getPackageInfo(context.getPackageName(), 0);
            name = packInfo.versionName;
        } catch (Exception e) {
            Lg.w(e);
        }
        return name;
    }


    /**
     * 获取当前程序的版本号
     */
    public static PackageInfo getPackageInfo(Context context) {
        // 获取packagemanager的实例
        PackageManager packageManager = context.getPackageManager();
        // getPackageName()是你当前类的包名，0代表是获取版本信息
        PackageInfo packInfo = null;
        try {
            packInfo = packageManager.getPackageInfo(context.getPackageName(), 0);
        } catch (PackageManager.NameNotFoundException e) {
            Lg.w(e);
        }
        return packInfo;
    }

    /**
     * 根据报名获取应用信息
     * @param context
     * @param packageName 包名
     * @return 应用信息
     */
    public static ApplicationInfo getAppInfoByPackageName(Context context, String packageName) {
        PackageManager packageManager = context.getPackageManager();
        ApplicationInfo info = null;
        try {
            info = packageManager.getApplicationInfo(packageName, PackageManager.GET_META_DATA);
        } catch (PackageManager.NameNotFoundException e) {
            Lg.w(e);
        }
        return info;
    }

    /**
     * 根据报名获取应用icon
     * @param context
     * @param packageName 包名
     * @return icon
     */
    public static Drawable getAppIconByPackageName(Context context, String packageName) {
        PackageManager packageManager = context.getPackageManager();
        Drawable drawable = null;
        try {
            ApplicationInfo info = packageManager.getApplicationInfo(packageName, PackageManager.GET_META_DATA);
            drawable = info.loadIcon(packageManager);
        } catch (PackageManager.NameNotFoundException e) {
            Lg.w(e);
        } catch (Exception e) {
            Lg.w(e);
        }
        return drawable;
    }

    /**
     * 根据报名获取应用name
     * @param context
     * @param packageName 包名
     * @return 应用名称
     */
    public static String getAppNameByPackageName(Context context, String packageName) {
        PackageManager packageManager = context.getPackageManager();
        String appName = null;
        try {
            ApplicationInfo info = packageManager.getApplicationInfo(packageName, PackageManager.GET_META_DATA);
            appName = info.loadLabel(packageManager).toString();
        } catch (PackageManager.NameNotFoundException e) {
            Lg.w(e);
        } catch (Exception e) {
            Lg.w(e);
        }
        return appName;
    }

    public static void printStackTrace() {
        StackTraceElement[] elements = Thread.currentThread().getStackTrace();
        Lg.i("===================save data===================");
        for (StackTraceElement stackTraceElement : elements) {
            Lg.i(stackTraceElement.getFileName() + "\t" + stackTraceElement.getClassName() + "\t"
                    + stackTraceElement.getMethodName() + "\t" + stackTraceElement.getLineNumber());
        }
        Lg.i("===================save data end===================");
    }

    /**
     * @description:开启关闭移动网络
     */
    public static boolean handleOnOffMobileData(Context context) {
        ConnectivityManager connManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        try {
            connManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
            Class<?> cmClass = connManager.getClass();
            Class<?>[] argClasses = new Class[1];
            argClasses[0] = boolean.class;
            // 反射ConnectivityManager中hide的方法setMobileDataEnabled，可以开启和关闭GPRS网络
            Method method = null;

            if (!isSimExist(context)) {
                Lg.d("Mobile phone no SIM card.");
                return false;
            }
            method = cmClass.getMethod("setMobileDataEnabled", argClasses);
            method.invoke(connManager, true);
            return true;
        } catch (Exception e) {
            Lg.w(e);
        }

        return false;
    }

    public static boolean isSimExist(Context context) {
        TelephonyManager mTelephonyManager = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
        int simState = mTelephonyManager.getSimState();
        boolean exist = false;
        switch (simState) {
            case TelephonyManager.SIM_STATE_ABSENT:
            case TelephonyManager.SIM_STATE_UNKNOWN:
                exist = false;
                break;

            case TelephonyManager.SIM_STATE_READY:
                exist = true;
                break;
        }
        return exist;
    }

    public static boolean isRunInBackground(Context context) {
        boolean result = !isScreenOn(context) || isTaskBackground(context);
        Lg.i("isRunInBackground " + result);
        return result;
    }

    public static boolean isScreenOn(Context c) {
        PowerManager pm = (PowerManager) c.getSystemService(Context.POWER_SERVICE);
        return pm.isScreenOn();
    }

    private static boolean isTaskBackground(Context context) {
        ActivityManager am = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        List<ActivityManager.RunningTaskInfo> tasks = am.getRunningTasks(1);
        for (ActivityManager.RunningTaskInfo task : tasks) {
            Lg.i("task:" + task.baseActivity + ",numRunning:" + task.numRunning);
            if (task.numRunning == 0 || !context.getPackageName().equals(task.baseActivity.getPackageName())) {
                return true;
            }
        }
        return false;
    }

    /**
     * 通知栏的高度获取
     *
     * @param context
     * @return
     */
    public static int getStatusBarHeight(Context context) {
        Class<?> c = null;
        Object obj = null;
        Field field = null;
        int x = 0, statusBarHeight = 0;
        try {
            c = Class.forName("com.android.internal.R$dimen");
            obj = c.newInstance();
            field = c.getField("status_bar_height");
            x = Integer.parseInt(field.get(obj).toString());
            statusBarHeight = context.getResources().getDimensionPixelSize(x);
        } catch (Exception e1) {
            Lg.w(e1);
        }
        return statusBarHeight;
    }

    /**
     * 获取资源文件中的字符
     *
     * @param id
     * @return
     */
    public static String getStringFromResource(Context context, int id) {
        if (null == context || null == context.getResources().getString(id))
            return "";
        else
            return context.getResources().getString(id);
    }

    /**
     * @return
     * @description:移动网络是否可用
     * @author:XiongWei
     */
    public static boolean isMobileDataEnabled(Context context) {
        if (!isSimExist(context))
            return false;

        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        boolean isEnabled = false;
        try {
            Class clazz = cm.getClass();
            Method getMethod = clazz.getMethod("getMobileDataEnabled");
            getMethod.setAccessible(true);
            isEnabled = (Boolean) getMethod.invoke(cm);
        } catch (Exception e) {
            Lg.w(e);
            // 反射方式不能正常使用时
            NetworkInfo mobile = cm.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
            /* reason 可能会存储移动数据状态 */
            String reason = mobile.getReason();
            if (TextUtils.isEmpty(reason)) {
                int networkerStatus = NetUtil.getNetworkState(context);
                return networkerStatus != -1 && networkerStatus != 1;
            }
            return reason.equals("dataEnabled") || reason.equals("connected");
        }

        return isEnabled;
    }


    @SuppressLint("NewApi")
    public static boolean isRoaming(Context context) {
        int b = 0;
        try {
            b = Settings.Global.getInt(context.getContentResolver(), Settings.Global.DATA_ROAMING);
        } catch (Settings.SettingNotFoundException e) {
            Lg.w(e);
        }
        return b == 1 ? true : false;
    }

    public static String getCurrentOperator(Context context) {
        TelephonyManager t = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
        return "NetworkOperator: " + t.getNetworkOperator() + " NetworkOperatorName ::" + t.getNetworkOperatorName();
    }

    public static boolean isSmartone(Context context) {
        if ("45406".equals(getCurrentOperator(context))) {
            return true;
        }
        return false;
    }


    //单位换算
    //转换单位
    public static String refreshTraffic(long lg) {
        String str = "0KB";
        int b = 1024, c = 1048576;

        if (lg < 1024) {
            str = "0KB";
        } else if (lg >= b && lg < c) {
            int d = (int) (lg / b);
            str = d + "KB";
        } else {
            double e = (double) lg / c;
            java.text.DecimalFormat df = new java.text.DecimalFormat("#.0");
            str = df.format(e) + "MB";

        }
        return str;
    }

    public static String refreshTrafficNoUnit(long lg) {
        String str = "0";
        int b = 1024, c = 1048576;
        double e = (double) lg / c;
        java.text.DecimalFormat df = new java.text.DecimalFormat("#.0");
        str = df.format(e) + "";

        return str;
    }

    /**
     * 获取屏幕高度
     */
    public static int getScreenHeight(Context context) {
        WindowManager wm = (WindowManager) context
                .getSystemService(Context.WINDOW_SERVICE);
        int height = wm.getDefaultDisplay().getHeight();
        return height;

    }


    /**
     * 获取屏幕宽度
     */
    public static int getScreenWidth(Context context) {
        WindowManager wm = (WindowManager) context
                .getSystemService(Context.WINDOW_SERVICE);
        int width = wm.getDefaultDisplay().getWidth();
        return width;

    }

    /**
     * 检查是否打开WLAN定位
     *
     * @param context
     * @return true 打开WLAN定位
     */
    public static boolean checkLocationEnable(Context context) {
        LocationManager locationManager = (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);
        // 通过WLAN或移动网络(3G/2G)确定的位置（也称作AGPS，辅助GPS定位。主要用于在室内或遮盖物（建筑群或茂密的深林等）密集的地方定位）
        boolean isOpenNetwork = locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
        // 通过GPS卫星定位，定位级别可以精确到街（通过24颗卫星定位，在室外和空旷的地方定位准确、速度快）
        boolean isOpenGps = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
        return (isOpenNetwork || isOpenGps);
    }

    public static String getInstalledApkSignatureMd5(Activity activity, String packageName){
        if(activity==null){
            return null;
        }
        Signature[] sigs;

        try {
            PackageManager packageManager = activity.getBaseContext().getPackageManager();
            if(packageManager!=null){
                PackageInfo packageInfo = packageManager.getPackageInfo(packageName, PackageManager.GET_SIGNATURES);
                sigs = packageInfo.signatures;
                if(sigs!=null&&sigs[0]!=null)
                {
                    byte[] hexBytes = sigs[0].toByteArray();
                    MessageDigest digest = MessageDigest.getInstance("MD5");
                    byte[] md5digest;
                    if(digest != null)
                    {
                        md5digest = digest.digest(hexBytes);
                        StringBuilder sb = new StringBuilder();
                        for (byte aMd5digest : md5digest) {
                            sb.append((Integer.toHexString((aMd5digest & 0xFF) | 0x100)).substring(1, 3));
                        }
                        return sb.toString();
                    }
                }
            }

        } catch (PackageManager.NameNotFoundException e) {
            Lg.w(e);
        } catch (NoSuchAlgorithmException e) {
            Lg.w(e);
        } catch (Exception e){
            Lg.w(e);
        }
        return null;
    }
    /**
     * 判断手机是否Root
     *
     * @return
     */
    public static boolean isRoot() {
        String binPath = "/system/bin/su";
        String xBinPath = "/system/xbin/su";
        if (new File(binPath).exists() && isExecutable(binPath)) {
            return true;
        }
        if (new File(xBinPath).exists() && isExecutable(xBinPath)) {
            return true;
        }
        return false;
    }

    private static boolean isExecutable(String filePath) {
        Process p = null;
        try {
            p = Runtime.getRuntime().exec("ls -l " + filePath);
            BufferedReader in = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String str = in.readLine();
            Lg.i(str);
            if (str != null && str.length() >= 4) {
                char flag = str.charAt(3);
                if (flag == 's' || flag == 'x') {
                    return true;
                }
            }
        } catch (IOException e) {
            Lg.w(e);
        } finally {
            if (null!= p){
                p.destroy();
            }
        }
        return false;
    }
    public static String getJsonOrderString(String msg){
        JSONObject obj = new JSONObject();
        try {
            obj.put("msg",msg);
        } catch (JSONException e) {
            Lg.d("GetJsonOrderString err");
        }
        return obj.toString();
    }
    public static String getJsonOrderString(String msg1,String msg2){
        JSONObject obj = new JSONObject();
        try {
            obj.put("msg1",msg1);
            obj.put("msg2",msg2);
        } catch (JSONException e) {
            Lg.d("GetJsonOrderString err");
        }
        return obj.toString();
    }
    public static String getJsonOrderString(String msg1,String msg2,String msg3,String msg4,String msg5,String msg6){
        JSONObject outObj = new JSONObject();
        JSONObject inObj1 = new JSONObject();
        JSONObject inObj2 = new JSONObject();
        try {
            inObj1.put("msg1",msg1);
            inObj1.put("msg2",msg2);
            inObj1.put("msg3",msg3);
            inObj2.put("msg1",msg4);
            inObj2.put("msg2",msg5);
            inObj2.put("msg3",msg6);
            outObj.put("type1",inObj1);
            outObj.put("type2",inObj2);
        } catch (JSONException e) {
            Lg.d("GetJsonOrderString err");
        }
        return outObj.toString();
    }
    public static String getJsonOrderString(String msg1,String msg2,String msg3,String msg4,String msg5,String msg6,String msg7,String msg8){
        JSONObject outObj = new JSONObject();
        JSONObject inObj1 = new JSONObject();
        JSONObject inObj2 = new JSONObject();
        try {
            inObj1.put("msg1",msg1);
            inObj1.put("msg2",msg2);
            inObj1.put("msg3",msg3);
            inObj2.put("msg4",msg4);
            inObj2.put("msg1",msg5);
            inObj2.put("msg2",msg6);
            inObj2.put("msg3",msg7);
            inObj2.put("msg4",msg8);
            outObj.put("type1",inObj1);
            outObj.put("type2",inObj2);
        } catch (JSONException e) {
            Lg.d("GetJsonOrderString err");
        }
        return outObj.toString();
    }
    public static String getJsonOrderString(String msg1,String msg2,String msg3){
        JSONObject outObj = new JSONObject();
        JSONObject inObj1 = new JSONObject();
        try {
            inObj1.put("msg1",msg1);
            inObj1.put("msg2",msg2);
            inObj1.put("msg3",msg3);
            outObj.put("type1",inObj1);
        } catch (JSONException e) {
            Lg.d("GetJsonOrderString err");
        }
        return outObj.toString();
    }
    public static String getJsonOrderString(String key1,String val1,String key2,String val2){
        JSONObject obj = new JSONObject();
        try {
            obj.put(key1,val1);
            obj.put(key2,val2);
        } catch (JSONException e) {
            Lg.d("GetJsonOrderString err");
        }
        return obj.toString();
    }
    public static String getJsonOrderStrings(String msg1,String msg2,String msg3,String msg4){
        JSONObject obj = new JSONObject();
        try {
            obj.put("msg1",msg1);
            obj.put("msg2",msg2);
            obj.put("msg3",msg3);
            obj.put("msg4",msg4);
        } catch (JSONException e) {
            Lg.d("GetJsonOrderString err");
        }
        return obj.toString();
    }




    public static void closeSafely(Closeable c) {
        if (c != null) {
            try {
                c.close();
            } catch (IOException e) {
                Lg.w(e);
            }
        }
    }

    public static String getPhoneIp() {
        try {
            for (Enumeration en = NetworkInterface.getNetworkInterfaces(); en.hasMoreElements();) {
                NetworkInterface intf = (NetworkInterface) en.nextElement();
                for (Enumeration enumIpAddr = intf.getInetAddresses(); enumIpAddr.hasMoreElements();) {
                    InetAddress inetAddress = (InetAddress) enumIpAddr.nextElement();
                    if (!inetAddress.isLoopbackAddress() && inetAddress instanceof Inet4Address) {
                        // if (!inetAddress.isLoopbackAddress() && inetAddress
                        // instanceof Inet6Address) {
                        return inetAddress.getHostAddress().toString();
                    }
                }
            }
        } catch (Exception e) {
        }
        return "127.0.0.1";
    }


    /**
     * 检测Intent 是否有效
     * @param context
     * @param intent
     * @return
     */
    public static boolean isIntentAvailable(Context context, Intent intent) {
        if (context == null) {
            return false;
        }
        PackageManager pm = context.getPackageManager();
        List<ResolveInfo> resolves = pm.queryIntentActivities(intent, PackageManager.MATCH_DEFAULT_ONLY);
        return resolves != null && !resolves.isEmpty();
    }





    public static boolean hasNavigationBar(Activity activity){
        int height = activity.getWindowManager().getDefaultDisplay().getHeight();
        int deviceHeight = getRealHeight(activity);
        Lg.i("screenHeight:"+deviceHeight+",layoutHeight:"+height);
        if(getRealHeight(activity)>height){
            Lg.i("有虚拟按钮");
            return true;
        }else{
            Lg.i("没有有虚拟按钮");
            return false;
        }
    }

    private static int getRealHeight(Activity activity)
    {   int dpi = 0;
        Display display = activity.getWindowManager().getDefaultDisplay();
        DisplayMetrics dm = new DisplayMetrics();
        @SuppressWarnings("rawtypes")
        Class c;
        try {
            c = Class.forName("android.view.Display");
            @SuppressWarnings("unchecked")
            Method method = c.getMethod("getRealMetrics",DisplayMetrics.class);
            method.invoke(display, dm);
            dpi=dm.heightPixels;
        }catch(Exception e){
            Lg.w(e);
        }
        return dpi;
    }

    /**
     *
     * 检查请求地址是否包含网络协议
     *
     * @param sendURL
     *            请求Url全路径
     * @return true:包含协议 false:不包含协议
     */
    public static boolean hasHttpProtocol(String sendURL) {
        boolean hasProtocol = false;
        if (sendURL.startsWith("http") || sendURL.startsWith("https")) {
            hasProtocol = true;
        }
        return hasProtocol;
    }

    /**
     * 取得当前sim手机卡的imsi
     */
    public static String getIMSI(Context context) {
        if (null == context) {
            return null;
        }
        String imsi = "";
        try {
            TelephonyManager tm = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
            imsi = tm.getSubscriberId();
        } catch (Exception e) {
        }
        return imsi;
    }

    /**
     * 大于等于1024MB转换成GB,小于1024MB保持原数不变,单位也不变
     */
    public static String getGbFromMb(String flowNum) {
        DecimalFormat decimalFormat = new DecimalFormat(".00");

        if (!TextUtils.isEmpty(flowNum)) {
            float flowNumber = Float.parseFloat(flowNum);
            if (flowNumber >= 1024) {
                flowNumber = flowNumber / 1024;
                flowNum = decimalFormat.format(flowNumber);
                return flowNum;
            } else {
                return flowNum;
            }
        }
        return "0";
    }
}
