package com.pingan.pingandata.utils;

import org.json.JSONException;
import org.json.JSONObject;

import cn.core.net.Lg;

/**
 * @author chenshaosheng E-mail:ex-chenshaosheng001@pingan.com.cn
 * @version 2.0.4
 */
public class JsonUtil {
    public static String getJsonOrderString(String msg){
        JSONObject obj = new JSONObject();
        try {
            obj.put("msg",msg);
        } catch (JSONException e) {
            Lg.d("GetJsonOrderString err");
        }
        return obj.toString();
    }

    public static String getJsonOrderString(String msg1, String msg2){
        JSONObject obj = new JSONObject();
        try {
            obj.put("msg1",msg1);
            obj.put("msg2",msg2);
        } catch (JSONException e) {
            Lg.d("GetJsonOrderString err");
        }
        return obj.toString();
    }

    public static String getJsonOrderString(String msg1, String msg2, String msg3, String msg4, String msg5, String msg6){
        JSONObject outObj = new JSONObject();
        JSONObject inObj1 = new JSONObject();
        JSONObject inObj2 = new JSONObject();
        try {
            inObj1.put("msg1",msg1);
            inObj1.put("msg2",msg2);
            inObj1.put("msg3",msg3);
            inObj2.put("msg1",msg4);
            inObj2.put("msg2",msg5);
            inObj2.put("msg3",msg6);
            outObj.put("type1",inObj1);
            outObj.put("type2",inObj2);
        } catch (JSONException e) {
            Lg.d("GetJsonOrderString err");
        }
        return outObj.toString();
    }

    public static String getJsonOrderString(String msg1, String msg2, String msg3, String msg4, String msg5, String msg6, String msg7, String msg8){
        JSONObject outObj = new JSONObject();
        JSONObject inObj1 = new JSONObject();
        JSONObject inObj2 = new JSONObject();
        try {
            inObj1.put("msg1",msg1);
            inObj1.put("msg2",msg2);
            inObj1.put("msg3",msg3);
            inObj2.put("msg4",msg4);
            inObj2.put("msg1",msg5);
            inObj2.put("msg2",msg6);
            inObj2.put("msg3",msg7);
            inObj2.put("msg4",msg8);
            outObj.put("type1",inObj1);
            outObj.put("type2",inObj2);
        } catch (JSONException e) {
            Lg.d("GetJsonOrderString err");
        }
        return outObj.toString();
    }

    public static String getJsonOrderStrings(String msg1, String msg2, String msg3, String msg4, String msg5, String msg6, String msg7, String msg8, String msg9, String msg10){
        JSONObject outObj = new JSONObject();
        JSONObject inObj1 = new JSONObject();
        JSONObject inObj2 = new JSONObject();
        try {
            inObj1.put("msg1",msg1);
            inObj1.put("msg2",msg2);
            inObj1.put("msg3",msg3);
            inObj2.put("msg4",msg4);
            inObj2.put("msg5",msg5);
            inObj2.put("msg1",msg6);
            inObj2.put("msg2",msg7);
            inObj2.put("msg3",msg8);
            inObj2.put("msg4",msg9);
            inObj2.put("msg5",msg10);
            outObj.put("type1",inObj1);
            outObj.put("type2",inObj2);
        } catch (JSONException e) {
            Lg.d("GetJsonOrderString err");
        }
        return outObj.toString();
    }

    public static String getJsonOrderString(String msg1, String msg2, String msg3){
        JSONObject outObj = new JSONObject();
        JSONObject inObj1 = new JSONObject();
        try {
            inObj1.put("msg1",msg1);
            inObj1.put("msg2",msg2);
            inObj1.put("msg3",msg3);
            //outObj.put("type1",inObj1);
        } catch (JSONException e) {
            Lg.d("GetJsonOrderString err");
        }
        return outObj.toString();
    }

    public static String getJsonOrderString(String key1, String val1, String key2, String val2){
        JSONObject obj = new JSONObject();
        try {
            obj.put(key1,val1);
            obj.put(key2,val2);
        } catch (JSONException e) {
            Lg.d("GetJsonOrderString err");
        }
        return obj.toString();
    }

    public static String getJsonOrderStrings(String msg1, String msg2, String msg3, String msg4){
        JSONObject obj = new JSONObject();
        try {
            obj.put("msg1",msg1);
            obj.put("msg2",msg2);
            obj.put("msg3",msg3);
            obj.put("msg4",msg4);
        } catch (JSONException e) {
            Lg.d("GetJsonOrderString err");
        }
        return obj.toString();
    }

    public static String getJsonOrderStrings(String msg1, String msg2, String msg3, String msg4, String msg5){
        JSONObject obj = new JSONObject();
        try {
            obj.put("msg1",msg1);
            obj.put("msg2",msg2);
            obj.put("msg3",msg3);
            obj.put("msg4",msg4);
            obj.put("msg5",msg5);
        } catch (JSONException e) {
            Lg.d("GetJsonOrderString err");
        }
        return obj.toString();
    }
}
