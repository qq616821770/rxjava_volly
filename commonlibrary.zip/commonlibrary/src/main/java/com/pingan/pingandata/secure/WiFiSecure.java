package com.pingan.pingandata.secure;

import android.content.Context;

import java.io.UnsupportedEncodingException;

import cn.core.net.Lg;
import cn.core.net.secure.Base64;

/**
 * Created by yueang on 16/10/3.
 */

public class WiFiSecure {
    static {
        System.loadLibrary("WiFiSecure");
    }
    // 加解密统一使用的编码方式
    private final static String encoding = "utf-8";

    /**
     * 选择秘钥类型前,先到wifiSecure.cpp核对所选秘钥类型具体key值是否和你需要的一致
     */
    public enum Des3KeyType {
        APP_NEW,//加密库改造新key
        APP_CACHE,//APP数据存储
        APP//原APP Des3 key
    }

    /**
     * 选择秘钥类型前,先到wifiSecure.cpp核对所选秘钥类型具体key值是否和你需要的一致
     */
    public enum Sha1KeyType {
        APP_NEW,//加密库改造新key
        ANYDOOR,//任意门专用
        APP,//APP专用
        MAP,//地图专用
        SHOP_INFO,//商户专用
        SDK,//SDK专用
        PADC_HUZHONG,
        SDK_BILLING,//SDK对账专用
        MPUSH,//小米推送专用
        PADC_FLOW // 赚流量使用的sha1 key
    }

    private static volatile WiFiSecure sInstance;
    private static Object lock = new Object();
    private Context appContext;
    private String environment;
    private volatile boolean initialized;

    public static WiFiSecure getInstance() {
        if (sInstance == null) {
            synchronized (lock) {
                if (sInstance == null) {
                    sInstance = new WiFiSecure();
                }
            }
        }

        return sInstance;
    }

    private WiFiSecure(){}

    public void init(Context context, String environment) {
        appContext = context.getApplicationContext();
        this.environment = environment;
        initialized = true;
    }

    /**
     * @param arr 需要加签的参数
     * @return 签名后的字符串
     */
    public String getSignature(Sha1KeyType keyType, String... arr) {
        checkInit();
        return reCheckEmpty(getSignature(appContext, environment, keyType.name(), arr));
    }

    private void checkInit() {
        if (!initialized) {
            throw new RuntimeException("WiFiSecure not initialized!");
        }
    }

    private native String getSignature(Context context, String environment, String keyType, String... arr);

    /**
     * 3DES加密, 返回字符串
     * @param plainText
     * @param keyType
     * @return
     */
    public String des3Encode(Des3KeyType keyType,String plainText) {
        checkInit();

        byte[] plainBytes;
        try {
            plainBytes = plainText.getBytes(encoding);
        } catch (UnsupportedEncodingException e) {
            Lg.w(e);
            return null;
        }
        byte[] enBytes = reCheckEmpty(des3Encode(appContext, environment, plainBytes, keyType.name()));
        return Base64.encode(enBytes);
    }

    /**
     * 3DES加密, 返回字节数组
     * @param plainBytes
     * @param keyType
     * @return
     */
    public byte[] des3Encode(Des3KeyType keyType,byte[] plainBytes) {
        checkInit();

        return reCheckEmpty(des3Encode(appContext, environment, plainBytes, keyType.name()));
    }

    private native byte[] des3Encode(Context context, String environment, byte [] plainBytes, String keyType);

    /**
     * 3DES解密
     * @param encryptText
     * @param keyType
     * @return
     */
    public  String des3Decode(Des3KeyType keyType,String encryptText){
        checkInit();

        byte[] deBytes=  reCheckEmpty(des3Decode(appContext, environment, Base64.decode(encryptText), keyType.name()));
        if(deBytes == null) {
            return null;
        }
        try {
            return new String(deBytes,encoding);
        } catch (UnsupportedEncodingException e) {
            Lg.w(e);
            return null;
        }
    }

    /**
     * 3DES解密
     * @param encryptBytes
     * @param keyType
     * @return
     */
    public byte[] des3Decode(Des3KeyType keyType,byte[] encryptBytes) {
        checkInit();

        return reCheckEmpty(des3Decode(appContext, environment, encryptBytes, keyType.name()));
    }
    private native byte[] des3Decode(Context context, String environment, byte [] encryptBytes, String keyType);

    public boolean isValidAPK() {
        checkInit();
        boolean isValidAPK = isValidAPK(appContext, environment);
        needAppCrash(!isValidAPK);
        return isValidAPK;
    }

    private native boolean isValidAPK(Context context, String environment);


    /**
     * @return RsaKey
     */
    public String getRsaKey() {
        checkInit();
        return getRsaKey(appContext, environment);
    }

    private native String getRsaKey(Context context, String environment);

    private byte[] reCheckEmpty(byte[] result) {
        needAppCrash(result == null);
        return result;
    }

    private String reCheckEmpty(String result) {
        needAppCrash(result == null);
        return result;
    }

    private void needAppCrash(boolean needCrash) {
        if(needCrash && (!"prd".equalsIgnoreCase(environment))) {
            throw new RuntimeException("打包签名错误！");
        }
    }
}
