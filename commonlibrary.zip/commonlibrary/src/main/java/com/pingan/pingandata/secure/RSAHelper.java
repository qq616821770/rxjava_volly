package com.pingan.pingandata.secure;

import android.util.Base64;

import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;

import javax.crypto.Cipher;

import cn.core.net.Lg;

public class RSAHelper {

    // 加解密统一使用的编码方式
    private static String encoding = "utf-8";

    public static PublicKey getPublicKey(String key) throws Exception {
        byte[] keyBytes = Base64.decode(key, Base64.NO_WRAP | Base64.NO_PADDING);
        X509EncodedKeySpec keySpec = new X509EncodedKeySpec(keyBytes);
        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
        PublicKey publicKey = keyFactory.generatePublic(keySpec);
        return publicKey;
    }

    /**
     * 得到私钥
     * 
     * @param key 密钥字符串（经过base64编码）
     * @throws Exception
     */
    public static PrivateKey getPrivateKey(String key) throws Exception {
        byte[] keyBytes;
        keyBytes = Base64.decode(key, Base64.DEFAULT);
        PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(keyBytes);
        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
        PrivateKey privateKey = keyFactory.generatePrivate(keySpec);
        return privateKey;
    }

    /**
     * 使用公钥进行rsa加密操作
     * 
     * @param data 需要加密的数据
     * @param publicKey 公钥字符串
     * @return
     */
    public static String encryptByPublicKey(String data, String publicKey) {
        String encryptStr = "";
        try {
            // 根据模和指数获取公钥对象进行加密操作
            PublicKey publicKeyObj = getPublicKey(publicKey);
            // 加解密类
            Cipher cipher = Cipher.getInstance("RSA/None/PKCS1Padding");
            // 明文
            byte[] plainText = data.getBytes(encoding);
            // 加密
            cipher.init(Cipher.ENCRYPT_MODE, publicKeyObj);
            byte[] enBytes = cipher.doFinal(plainText);
            encryptStr = Base64.encodeToString(enBytes, Base64.NO_WRAP);
        } catch (Exception e) {
            Lg.w(e);
        }
        return encryptStr;
    }
}
