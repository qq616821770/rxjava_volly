package com.pingan.pingandata.utils;

import android.text.TextUtils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PatternUtil {

    public static boolean checkUserNameInput(String userName) {
    	String validateStr = "^(?![0-9])[\\w\\_[０-９]\u4e00-\u9fa5\uFF21-\uFF3A\uFF41-\uFF5A]+$";
        boolean rs = false;
        rs = matcher(validateStr, userName);
        if (rs) {
            int strLenth = getStrLength(userName);
            if (strLenth < 0 || strLenth > 16) {
                rs = false;
            }
        }
        return rs;
    }
    public static boolean checkUserName(String userName) {
        String validateStr = "^(?![0-9])[\\w\\_[０-９]\u4e00-\u9fa5\uFF21-\uFF3A\uFF41-\uFF5A]+$";
        boolean rs = false;
        rs = matcher(validateStr, userName);
        if (rs) {
            int strLenth = getStrLength(userName);
            if (strLenth < 4 || strLenth > 16) {
                rs = false;
            }
        }
        return rs;
    }
    public static int getStrLength(String value) {
        int valueLength = 0;
        String chinese = "[\u0391-\uFFE5]";
        for (int i = 0; i < value.length(); i++) {
            String temp = value.substring(i, i + 1);
            if (temp.matches(chinese)) {
                valueLength += 2;
            } else {
                valueLength += 1;
            }
        }
        return valueLength;
    }

    private static boolean matcher(String reg, CharSequence string) {
        boolean tem = false;
        Pattern pattern = Pattern.compile(reg);
        Matcher matcher = pattern.matcher(string);
        tem = matcher.matches();
        return tem;
    }

    public static boolean checkPhone(CharSequence phone) {
        // Pattern p = Pattern
        // .compile("^((13[0-9])|(15[^4,\\D])|(18[0,5-9])|(18[1,0-1]))\\d{8}$");
        Pattern p = Pattern.compile("^1\\d{10}$");
        Matcher m = p.matcher(phone);
        return m.matches();
    }

    public static boolean checkPassword(String password) {
//        String s = "[\u4e00-\u9fa5]";
        String s = "^[A-Za-z0-9]+$";
        Pattern p = Pattern.compile(s);
        Matcher m = p.matcher(password);
        if (m.find()) {
            int strLenth = getStrLength(password);
            if (strLenth < 6 || strLenth > 16) {
                return false;
            }
            return true;
        }
        return false;
    }

    public static boolean beginAsNum(String userName) {
        String s = "^([0-9])+";
        Pattern p = Pattern.compile(s);
        Matcher m = p.matcher(userName);
        return m.find();
    }


    // GENERAL_PUNCTUATION 判断中文的“号  
    // CJK_SYMBOLS_AND_PUNCTUATION 判断中文的。号  
    // HALFWIDTH_AND_FULLWIDTH_FORMS 判断中文的，号  
    private static final boolean isChinese(char c) {  
        Character.UnicodeBlock ub = Character.UnicodeBlock.of(c);
        if (ub == Character.UnicodeBlock.CJK_UNIFIED_IDEOGRAPHS
                || ub == Character.UnicodeBlock.CJK_COMPATIBILITY_IDEOGRAPHS
                || ub == Character.UnicodeBlock.CJK_UNIFIED_IDEOGRAPHS_EXTENSION_A
                || ub == Character.UnicodeBlock.GENERAL_PUNCTUATION
                || ub == Character.UnicodeBlock.CJK_SYMBOLS_AND_PUNCTUATION
                || ub == Character.UnicodeBlock.HALFWIDTH_AND_FULLWIDTH_FORMS) {
            return true;  
        }  
        return false;  
    }  
  
    public static final boolean isChinese(String strName) {
        char[] ch = strName.toCharArray();  
        for (int i = 0; i < ch.length; i++) {  
            char c = ch[i];  
            if (isChinese(c)) {  
                return true;  
            }  
        }  
        return false;  
    }

    public static boolean isYDPhoneNumber(CharSequence phone) {
        if (TextUtils.isEmpty(phone)) {
            return false;
        }

        String yd = "^1(34[0-8]|(3[5-9]|5[017-9]|8[278])\\d)\\d{7}$";//移动
        Pattern p0 = Pattern.compile(yd);
        Matcher m0 = p0.matcher(phone);
        return m0.matches();
    }

    public static boolean isLTPhoneNumber(CharSequence phone) {
        if(TextUtils.isEmpty(phone)) {
            return false;
        }

        String lt = "^1(3[0-2]|5[256]|8[56])\\d{8}$";                //联通
        Pattern p1 = Pattern.compile(lt);
        Matcher m1 = p1.matcher(phone);
        return m1.matches();
    }

    public static boolean checkSmsCode(CharSequence code) {
        return matcher("^\\d+$", code);
    }
}
