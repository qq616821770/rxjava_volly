package com.pingan.pingandata;

/**
 * 常量类，应用所有常量
 * @author chenlong
 *
 */
public class Constance {

    /**
     * 大冲流量伪协议头
     */
    public static final String PAGE_JUMP_PROTOCOL_SCHEME = "PINGANDATA";
    public static final String PAGE_JUMP_PROTOCOL_PAGE = "page";
    public static final String PAGE_JUMP_PROTOCOL_URL = "url";
    public static final String PAGE_JUMP_PROTOCOL_METHOD = "method";

    /**
     * 页面参数
     */
    public static final String EXTRA_URL = "url";
    public static final String EXTRA_TITLE = "title";
    public static final String EXTRA_PAGE_TYPE = "pageType";
    public static final String EXTRA_AD_SHOW_REPORT_URLS = "adShowReportUrls";
    public static final String EXTRA_AD_CLICK_REPORT_URLS = "adClickReportUrls";
    public static final String PAGE_TYPE_AD = "pageTypeAd";
    public static final String PAGE_TYPE_NEWS = "pageTypeNews";


    /**
     * 赚流量频道
     */
    public static final long EARN_FLOW_REWARD_TIME_DEFAULT = 5; // 单位秒
    public static final long EARN_FLOW_AD_UPDATE_TIME_DEFAULT = 300; // 单位秒


    /**
     * 应用统一服务相关
     */

    /**
     * 统一服务发出广播的间隔
     */
    public static final long APP_FIXED_RATE_INTERVAL = 60 * 1000;
    public static final long APP_HEART_BEAT_INTERVAL = 5 * 60 * 1000;

    public static final String ACTION_GO_AUTH_VPN = "action_auth_vpn";
    public static final String ACTION_LOGIN_RESULT_STATE = "action_login_result_state";
    public static final String PLATFORM = "android";
    public static final String REGISTER_STEP_2_SMS_CONTENT = "register_step_2_sms_content";
    public static final String REGISTER_STEP_1_START_BY_THIRD_APP = "register_step_1_start_by_third_app";
    public static final String REGISTER_STEP_2_SAFE_CODE = "register_step_2_safe_code";

    public static final String GUIDE_LOGIN = "guideLogin";

    public final static String ACTION_FDN ="action_fdn";
    public final static String ACTION_POP ="action_pop";
    public final static String ACTION_VPN_STOP="action_vpn_stop";
    public final static String ACTION_TYPE = "discover";
    public final static String ACTION_POP_FUND           = "action_pop_fund";
    public final static String ACTION_CACHE_BANK_LIST    = "action_cache_bank_list";
    public final static String ACTION_BANK_CHOOSE        = "action_bank_choose";
    public final static String ACTION_BANK_CHOOSE_NAME   = "action_bank_choose_name";
    public final static String ACTION_BANK_CHOOSE_ID     = "action_bank_choose_id";
    public final static String ACTION_BANK_AGREEMENT = "action_bank_agreement";
    public final static String ACTION_BANK_AGREEMENT_URL = "action_bank_agreement_url";
    public final static String WX_PAY_CALL_BACK = "com.pingan.pinganwifi.wx.pay";
    public final static int    REQUEST_CODE_OPEN_ACCOUNT = 1101;
    public final static int    REQUEST_CODE_BANK_BINDING = 1102;
    public final static int    REQUEST_CODE_BANK_CHOOSE  = 1103;
    public final static int    REQUEST_CODE_FORGET_PASSWORD  = 3254;
    public final static int    REQUEST_CODE_YZT_AUTH  = 4436;
    public static final int REQUEST_CODE_YZT_LOGIN = 4438;
    public static final int REQUEST_CODE_BIND = 4440;
    /**
     * 一账通绑定-未绑定且未注册-存在手机号-注册平安WIFI并绑定
     */
    public static final int RESULT_CODE_SETTING_BIND = 4444;
    public static final int RESULT_CODE_LOGIN_BACK = 4445;
    public static final int RESULT_CODE_BIND_BACK = 4446;
    public final static String YZT_AUTH_SUCCESS  = "YZT_AUTH_SUCCESS";
    public static final String ACTION_YZT_LOGIN = "action_yzt_login";

    /**
     * 一账通绑定-未绑定且未注册
     */
    public static final String YZT_LOGIN_STATUS_CODE_UNBOUND_AND_NOT_REGISTERED = "0";

    /**
     * 一账通绑定-已绑定
     */
    public static final String YZT_LOGIN_STATUS_CODE_BOUND = "1";

    /**
     * 一账通绑定-未绑定且已注册
     */
    public static final String YZT_LOGIN_STATUS_CODE_UNBOUND_AND_REGISTERED = "2";
    public static final int ADVERTISE_IMP_REQUEST_MAX_COUNT = 5;
    public static final int ADVERTISE_CLICK_REQUEST_MAX_COUNT = 5;

    public static final long EARN_FLOW_CHANGE_TAB_UPDATE_TIME_DEFAULT = 60;
    public static final String EARN_FLOW_REWARD_NEWS = "0.4M";
    public static final String EARN_FLOW_REWARD_AD = "2M";
    public static final String EXTRA_AID = "aid";
    public static final String EARN_FLOW_ERR_MSG_AD_EARNED_ALREADY = "这条广告的奖励您已经拿过啦";
    public static final String EARN_FLOW_ERR_MSG_NEWS_EARNED_ALREADY = "这条新闻的奖励您已经拿过啦";


    public static boolean vpnSwitchFlag = false;


    /**
     * 零钱宝充值金额
     */
    public static final String FUND_PAY_MONEY = "fund_pay_money";

    /**
     * 零钱宝开户时间
     */
    public static final String FUND_OPEN_TIME = "fund_open_time";

    /**
     * 零钱宝收益生效时间
     */
    public static final String FUND_START_TIME = "fund_start_time";

    /**
     * 零钱宝收益到账时间
     */
    public static final String FUND_ARRIVE_TIME = "fund_arrive_time";

    /**
     * 零钱宝开户成功充值的状态
     */
    public static final String FUND_ACCOUNT_STATE = "fund_account_state";

    /**
     * 零钱宝从哪里进入支付结果界面
     */
    public static final String FUND_FROM_WHICH = "fund_from_which";

    /**
     * 零钱宝首次进入支付结果界面
     */
    public static final String FUND_FIRST_TO_RESULT = "fund_first";

    /**
     * 零钱宝转入进入支付结果界面
     */
    public static final String FUND_INPUT_TO_RESULT = "fund_turn_in";

    /**
     * 零钱宝转出进入支付结果界面
     */
    public static final String FUND_OUTPUT_TO_RESULT = "fund_turn_out";

    public static final int FLOW_LOW_VALUE = 10;
    public static final int LIMITED_ICON_MUN = 9;

    /**
     * 使用记录-VPN流量打开
     */
    public static final long USE_RECORD_FDN_VPN = 2001;

    /**
     * 使用记录-平安免费wifi连接
     */
    public static final long USE_RECORD_PA_FREE_WIFI = 2002;

    public static final int FILECHOOSER_RESULTCODE = 2003;
    public static final int FILECUT_RESULTCODE = 2004;
    public static final int FILECHOOSER_RESULTCODE_FOR_ANDROID_5 = 2005;

    /**
     * 来源手机号
     */
    public static final String SOURCE_PHONE = "source_phone";
    /**
     * 来源渠道
     */
    public static final String SOURCE_CHANEL = "source_chanel";

    /**
     * 联合登陆进入,来自第三方(绑定微信)唤起APP
     */
    public static final String START_BY_THIRD_APP = "startByThirdApp";

    /**
     * 联合登陆进入,来自第三方(绑定微信),第二步的页面跳转的Key
     */
    public static final String START_BY_THIRD_APP_BIND_ACCOUNT_STEP_2 = "startByThirdAppStep2Key";

    /**
     * 个人中心，是否需要自动签到
     */
    public static final String IS_AUTO_SIGN_IN = "is_auto_sign_in";

    /**
     * APP本地消息通知
     */
    public static final String NOTIFI_PUSH_TYPE = "notifi_push_type";

    /**
     * 消息中心小红点更新广播
     */
    public static final String ACTION_UPDATE_MSG_REDPOINT = "UPDATE_MSG_REDPOINT";

    /**
     * 订单号
     */
    public static final String ORDER_ID = "order_id";

    /**
     * 订单支付成功
     */
    public static final String ORDERS_SUCCESSFUL_PAY = "orders_successful_pay";

    /**
     * 一账通登录、绑定成功
     */
    public static final String YZT_LOGIN_AND_BINDING = "yzt_login_and_binding";

    /**
     * 小歪钱包首页
     */
    public static final String FUND_HOME = "/page/app/coinPurse/accountHome/index.html";
    public static final String FUND_NEW_USER_GUIDE = "/page/app/coinPurse/newUserGuide/newUserGuide.html";



    public static final String EXTRA_BANK_NAME = "extra_bank_name";

    public static final String UPDATE_WIFICONNECTVIEW_TEXT = "update_wifi_connect_view_text";

    /**
     * 共享热点
     */
    public static final String PA_IS_SHARED = "1";

    /**
     * 公共标识
     */
    public static final String CONSTANT_TRUE = "1";

    /**
     * 魔窗后台配置的动态参数（不能与自身伪协议配置冲突）
     */
    public static final String MW_QUERY_PARAMETER = "url";

    /**
     * 官网渠道
     */
    public static final String CHANNEL_DEFAULT = "dt_default.com";

    public static final String REGISTER_STEP_1_PHONE_NUMBER = "register_step_1_phone_number";

    //// TODO: 16/11/7 暂时图片保存路径
    /**
     * SD卡缓存路径
     */
    public static final String CACHE_BASE = android.os.Environment.getExternalStorageDirectory() + "/PADataCache/";
    /**
     * 图片缓存
     */
    public static final String CACHE_IMAGES = CACHE_BASE + "/imgs/";

    public static final String CACHE_PHOTO_IMAGES = CACHE_BASE + "/face/";


    public static final int DISK_IMAGE_CACHE_SIZE = 1024 * 1024 * 1;

    /**
     * 广告请求间隔常量
     */
    public static final long ADVERTISE_REFRESH_TIME = 5 * 60 * 1000;
}
