package com.pingan.ak.component.trans;

import com.pingan.ak.component.bus.RxBus;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

import cn.core.net.Lg;
import rx.functions.Action1;

/**
 * Created by hexiaohong on 16/8/22.
 */
public class TransMgr {

    private static Map<String, TransTask> transTaskMap = new HashMap<String, TransTask>();

    public static void add(TransNode transNode, TransCallback transCallback, boolean start) {
        transNode.id = UUID.randomUUID().toString();

        if (transNode.transType == TransNode.TransType.Download) {
            DownloadTask downloadTask = new DownloadTask(transNode, transCallback);
            transTaskMap.put(transNode.id, downloadTask);
            if (downloadTask.checkTask()) {
                if (start) {
                    downloadTask.runTask();
                }
            }
        } else if (transNode.transType == TransNode.TransType.Upload) {
            UploadTask uploadTask = new UploadTask(transNode, transCallback);
            transTaskMap.put(transNode.id, uploadTask);
            if (uploadTask.checkTask()) {
                if (start) {
                    uploadTask.runTask();
                }
            }
        }
    }

    public static void start(String id) {
        if (transTaskMap.containsKey(id)) {
            TransTask transTask = transTaskMap.get(id);
            transTask.runTask();
        }
    }

    public static void stop(String id) {
        if (transTaskMap.containsKey(id)) {
            TransTask transTask = transTaskMap.get(id);
            transTask.pauseTask();
        }
    }

    public static void remove(String id) {
        if (transTaskMap.containsKey(id)) {
            TransTask transTask = transTaskMap.get(id);
            transTask.cancelTask();
            transTaskMap.remove(id);
        }
    }

    public static void clear() {
        Iterator<Map.Entry<String, TransTask>> iterator = transTaskMap.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<String, TransTask> entry = iterator.next();
            entry.getValue().cancelTask();
        }
        transTaskMap.clear();
    }

    public static void wifiDisconnected() {
        Iterator<Map.Entry<String, TransTask>> iterator = transTaskMap.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<String, TransTask> entry = iterator.next();
            TransTask transTask = entry.getValue();
            if (transTask.transNode.transNetwork == TransNode.TransNetwork.OnlyWifi) {
                transTask.hangupTask();
            }
        }
    }

    public static void wifiConnected() {
        Iterator<Map.Entry<String, TransTask>> iterator = transTaskMap.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<String, TransTask> entry = iterator.next();
            TransTask transTask = entry.getValue();
            if (transTask.transNode.transStatus == TransNode.TransStatus.Pending
                    || transTask.transNode.transStatus == TransNode.TransStatus.Failed) {
                transTask.runTask();
            }
        }
    }

    static {
        registerRxBus();
    }

    private static void registerRxBus() {
        RxBus.getInstance()
                .toObservable(ConnectEvent.class)
                .subscribe(new Action1<Object>() {
                    @Override
                    public void call(Object event) {
                        try {
                            if (event != null) {
                                if (event instanceof ConnectEvent) {
                                    ConnectEvent connectEvent = (ConnectEvent) event;
                                    if (connectEvent.isWifiConnected) {
                                        TransMgr.wifiConnected();
                                    } else {
                                        TransMgr.wifiDisconnected();
                                    }
                                }
                            }
                        } catch (Exception e) {
                            Lg.w(e);
                        }
                    }
                }, new Action1<Throwable>() {
                    @Override
                    public void call(Throwable t) {
                        Lg.w(t);
                        registerRxBus();
                    }
                });
    }
}
