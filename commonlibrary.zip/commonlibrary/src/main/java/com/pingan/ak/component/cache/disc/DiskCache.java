package com.pingan.ak.component.cache.disc;

import com.pingan.ak.component.cache.disc.rw.ReaderWriterDisk;

/**
 * Created by hexiaohong on 16/8/10.
 */
public interface DiskCache {

    <T> boolean put(String key, T t, ReaderWriterDisk<T> rw);

    <T> T get(String key, ReaderWriterDisk<T> rw);

    boolean remove(String key);

    void clear();
}
