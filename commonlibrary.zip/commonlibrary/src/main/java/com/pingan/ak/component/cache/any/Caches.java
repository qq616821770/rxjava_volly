package com.pingan.ak.component.cache.any;

import android.content.Context;

/**
 * Caches.
 * <p>
 * Created by hexiaohong on 16/9/8.
 */
public class Caches {

    private static Context mContext;

    // 不同策略及不同存储根目录，分别定义如下
    private volatile static LruCache mLruCache;
    private volatile static FixCache mFixCache;

    private volatile static FixFiles mFixFiles;

    /**
     * Init.
     *
     * @param context the context
     */
    public static void init(Context context) {
        mContext = context.getApplicationContext();
    }

    /**
     * Gets lru cache.
     *
     * @return the lru cache
     */
    public static LruCache getLruCache() {
        if (mLruCache == null) {
            synchronized (Caches.class) {
                if (mLruCache == null) {
                    mLruCache = new LruCache();
                    mLruCache.init(mContext);
                }
            }
        }
        return mLruCache;
    }

    /**
     * Gets fix cache.
     *
     * @return the fix cache
     */
    public static FixCache getFixCache() {
        if (mFixCache == null) {
            synchronized (Caches.class) {
                if (mFixCache == null) {
                    mFixCache = new FixCache();
                    mFixCache.init(mContext);
                }
            }
        }
        return mFixCache;
    }

    /**
     * Gets fix files.
     *
     * @return the fix files
     */
    public static FixFiles getFixFiles() {
        if (mFixFiles == null) {
            synchronized (Caches.class) {
                if (mFixFiles == null) {
                    mFixFiles = new FixFiles();
                    mFixFiles.init(mContext);
                }
            }
        }
        return mFixFiles;
    }
}
