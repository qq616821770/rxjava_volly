package com.pingan.ak.component.cache.disc.rw;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import com.pingan.ak.util.IoUtil;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.OutputStream;

import cn.core.net.Lg;

/**
 * Created by hexiaohong on 16/8/10.
 */
public class BitmapReaderWriterDisk extends ReaderWriterDisk<Bitmap> {

    @Override
    public Bitmap get(File file) {
        FileInputStream fis = null;

        try {
            fis = new FileInputStream(file);
            return BitmapFactory.decodeStream(fis);
        } catch (Exception e) {
            Lg.w(e);
        } finally {
            IoUtil.safeClose(fis);
        }

        return null;
    }

    @Override
    public boolean put(OutputStream os, Bitmap bitmap) {
        BufferedOutputStream bos = null;
        try {
            bos = new BufferedOutputStream(os, 1024 * 32);
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, bos);
            return true;
        } catch (Exception e) {
            Lg.w(e);
        } finally {
            IoUtil.safeClose(bos);
        }
        return false;
    }
}
