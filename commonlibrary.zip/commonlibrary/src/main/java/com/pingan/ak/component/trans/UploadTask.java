package com.pingan.ak.component.trans;


import com.pingan.ak.component.net.http.OkHttpUtils;

import java.io.File;
import java.io.IOException;

import cn.core.net.Lg;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Headers;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * Created by guoqiang on 16/8/22.
 */
class UploadTask extends TransTask {

    public UploadTask(TransNode transNode, TransCallback transCallback) {
        this.transNode = transNode;
        this.transCallback = transCallback;
    }

    @Override
    public boolean checkTask() {
        return true;
    }

    @Override
    public synchronized void runTask() {
        if (transNode.transStatus == TransNode.TransStatus.Running) {
            return;
        }

        transNode.transStatus = TransNode.TransStatus.Running;
        transNode.completeSize = 0L;
        transNode.totalSize = 0L;

        final File file = new File(transNode.localPath);

        Request.Builder builder = new Request.Builder();

        // url
        builder.url(transNode.url);

        // tag
        builder.tag(transNode.id);

        // file
        if (!file.exists() || !file.isFile()) {
            maybeFailed();
            return;
        }

        final OkHttpUtils.ProgressListener progressListener = new OkHttpUtils.ProgressListener() {
            @Override
            public void update(long bytesRead, long contentLength, boolean done) {
                transNode.completeSize = bytesRead;
                transNode.totalSize = contentLength;
                if (done) {
                    maybeSucceed();
                } else {
                    if (transCallback != null) {
                        transCallback.onTrans(transNode);
                    }
                }
            }
        };

        builder.post(new OkHttpUtils.ProgressRequestBody(
                RequestBody.create(MediaType.parse(transNode.mime), file), progressListener));

        // header
        builder.headers(Headers.of(transNode.headers));

        // call
        try {
            Request request = builder.build();

            OkHttpClient client = OkHttpUtils.getClient();

            // must async, support cancel
            client.newCall(request).enqueue(new Callback() {
                @Override
                public void onFailure(Call call, IOException e) {
                    Lg.w(e);
                    maybeFailed();
                }

                @Override
                public void onResponse(Call call, Response response) {
                    if (!response.isSuccessful()) {
                        maybeFailed();
                        return;
                    }

                    maybeSucceed();
                }
            });

        } catch (Exception e) {
            Lg.w(e);
            maybeFailed();
        }
    }

    @Override
    public void hangupTask() {
        transNode.transStatus = TransNode.TransStatus.Pending;
        OkHttpUtils.cancel(transNode.id);
    }

    @Override
    public void pauseTask() {
        transNode.transStatus = TransNode.TransStatus.Paused;
        OkHttpUtils.cancel(transNode.id);
    }

    @Override
    public void cancelTask() {
        transNode.transStatus = TransNode.TransStatus.Canceled;
        OkHttpUtils.cancel(transNode.id);
    }

    private void maybeSucceed() {
        if (transNode.transStatus == TransNode.TransStatus.Running) {
            transNode.transStatus = TransNode.TransStatus.Succeed;
        }
        if (transCallback != null) {
            transCallback.onTrans(transNode);
        }
    }

    private void maybeFailed() {
        if (transNode.transStatus != TransNode.TransStatus.Pending
                && transNode.transStatus != TransNode.TransStatus.Paused
                && transNode.transStatus != TransNode.TransStatus.Canceled) {

            transNode.transStatus = TransNode.TransStatus.Failed;
        }
        if (transCallback != null) {
            transCallback.onTrans(transNode);
        }
    }
}
