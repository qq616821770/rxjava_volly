package com.pingan.ak.component.cache.memory.impl;

import android.graphics.Bitmap;
import android.support.v4.util.LruCache;

import com.pingan.ak.component.cache.memory.MemoryCache;

import cn.core.net.Lg;

public class LruMemoryCache implements MemoryCache {

    private LruCache<String, Object> lruCache;

    public LruMemoryCache(int maxSize) {
        if (maxSize <= 0) {
            throw new IllegalArgumentException("maxSize <= 0");
        }
        lruCache = new LruCache<String, Object>(maxSize) {
            @Override
            protected int sizeOf(String key, Object value) {
                return LruMemoryCache.this.sizeOf(key, value);
            }
        };
    }

    @Override
    public <V> boolean put(String key, V value) {
        if (key == null || value == null) {
            throw new NullPointerException("key == null || value == null");
        }
        if (lruCache != null) {
            try {
                lruCache.put(key, value);
                return true;
            } catch (Exception e) {
                Lg.w(e);
            }
        }
        return false;
    }

    @Override
    public <V> V get(String key) {
        if (key == null) {
            throw new NullPointerException("key == null");
        }
        if (lruCache != null) {
            V values = null;
            try {
                values = (V) lruCache.get(key);
            } catch (Exception e) {
                Lg.w(e);
            }
            return values;
        }
        return null;
    }

    @Override
    public boolean remove(String key) {
        if (key == null) {
            throw new NullPointerException("key == null");
        }
        if (lruCache != null && lruCache.remove(key) != null) {
            return true;
        }
        return false;
    }

    @Override
    public void clear() {
        if (lruCache != null) {
            lruCache.evictAll();
        }
    }

    protected <V> int sizeOf(String key, V value) {
        if (value != null) {
            if (value instanceof Bitmap) {
                Bitmap bitmap = (Bitmap) value;
                return bitmap.getRowBytes() * bitmap.getHeight();
            } else if (value instanceof byte[]) {
                return ((byte[]) value).length;
            }
        }
        return 1;
    }
}