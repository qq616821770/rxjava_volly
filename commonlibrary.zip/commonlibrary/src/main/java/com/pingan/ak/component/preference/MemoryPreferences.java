package com.pingan.ak.component.preference;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.HashMap;
import java.util.Map;

/**
 * Memory Preferences.
 *
 * Created by hexiaohong on 16/8/5.
 */
public abstract class MemoryPreferences extends BasePreferences {

    // if strict, use memory cache
    private Map<String, Object> kvMap = new HashMap<String, Object>();

    @Override
    protected void put(SharedPreferences.Editor editor, String key, Object value) {
        if (value == null) {
            kvMap.put(key, null);
        } else if (value instanceof String) {
            kvMap.put(key, (String) value);
        } else if (value instanceof Integer) {
            kvMap.put(key, (Integer) value);
        } else if (value instanceof Boolean) {
            kvMap.put(key, (Boolean) value);
        } else if (value instanceof Float) {
            kvMap.put(key, (Float) value);
        } else if (value instanceof Long) {
            kvMap.put(key, (Long) value);
        } else {
            kvMap.put(key, value.toString());
        }
        super.put(editor, key, value);
    }

    @Override
    public String get(String key, String defaultValue) {
        if (kvMap.containsKey(key)) {
            return (String) kvMap.get(key);
        }
        String value = super.get(key, defaultValue);
        kvMap.put(key, value);
        return value;
    }

    @Override
    public int get(String key, int defaultValue) {
        if (kvMap.containsKey(key)) {
            return (Integer) kvMap.get(key);
        }

        int value = super.get(key, defaultValue);
        kvMap.put(key, value);
        return value;
    }

    @Override
    public boolean get(String key, boolean defaultValue) {
        if (kvMap.containsKey(key)) {
            return (Boolean) kvMap.get(key);
        }
        boolean value = super.get(key, defaultValue);
        kvMap.put(key, value);
        return value;
    }

    @Override
    public float get(String key, float defaultValue) {
        if (kvMap.containsKey(key)) {
            return (Float) kvMap.get(key);
        }
        float value = super.get(key, defaultValue);
        kvMap.put(key, value);
        return value;
    }

    @Override
    public long get(String key, long defaultValue) {
        if (kvMap.containsKey(key)) {
            return (Long) kvMap.get(key);
        }
        long value = super.get(key, defaultValue);
        kvMap.put(key, value);
        return value;
    }

    @Override
    public void remove(String key) {
        if (kvMap.containsKey(key)) {
            kvMap.remove(key);
        }
        super.remove(key);
    }

    @Override
    public void clear() {
        kvMap.clear();
        super.clear();
    }

    @Override
    public boolean contains(String key) {
        if (kvMap.containsKey(key)) {
            return true;
        }
        return super.contains(key);
    }
}
