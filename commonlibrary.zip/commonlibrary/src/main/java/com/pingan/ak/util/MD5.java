package com.pingan.ak.util;

import java.security.MessageDigest;

import cn.core.net.Lg;

/**
 * Created by hexiaohong on 16/8/9.
 */
public final class MD5 {

    private static final char[] hexDigits = new char[]
            {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f'};

    public static String hexDigest(String str) {
        try {
            return hexDigest(str.getBytes());
        } catch (Exception e) {
            Lg.w(e);
        }

        return null;
    }

    public static String hexDigest(byte[] bytes) {
        try {
            MessageDigest e = MessageDigest.getInstance("MD5");
            e.update(bytes);
            
            return hex(e.digest());
        } catch (Exception e) {
            Lg.w(e);
        }

        return null;
    }

    public static String hex(byte[] bytes) {
        char[] hexChars = new char[bytes.length * 2];
        for (int i = 0; i < bytes.length; i++) {
            int value = bytes[i] & 0xFF;
            hexChars[i * 2] = hexDigits[value >>> 4];
            hexChars[i * 2 + 1] = hexDigits[value & 0x0F];
        }
        return new String(hexChars);
    }

    public static void main(String[] args) {
        System.out.println(hexDigest("abc"));
    }
}
