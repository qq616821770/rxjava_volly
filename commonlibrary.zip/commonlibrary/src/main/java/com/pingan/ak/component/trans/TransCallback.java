package com.pingan.ak.component.trans;

/**
 * Created by hexiaohong on 16/8/22.
 */
public interface TransCallback {

    void onTrans(TransNode transNode);
}
