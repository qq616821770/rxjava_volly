package com.pingan.ak.component.cache.volley;

import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.BitmapFactory;

import com.android.volley.toolbox.ImageLoader.ImageCache;
import com.pingan.ak.component.cache.FileCache;
import com.pingan.ak.component.cache.FileUtils;

import java.io.BufferedOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import cn.core.net.Lg;

public class DiskCache implements ImageCache {

    private FileCache.CacheType cacheType = FileCache.CacheType.IMAGE_COVER;
	private static CompressFormat DISK_IMAGECACHE_COMPRESS_FORMAT = CompressFormat.PNG;
    private String cachePath;

    public DiskCache(String path) {
		cachePath = path;
		FileUtils.createIfNoExists(cachePath);
	}

	@Override
	public Bitmap getBitmap(String url) {
		String filePath = cachePath + FileCache.decodeKey(url) + cacheType.extension;
		Bitmap bitmap = null;
		try {
			byte[] data = FileUtils.readBytes(filePath);
			if (data != null && data.length > 0) {
				bitmap = BitmapFactory.decodeByteArray(data, 0, data.length);
			}
		} catch (Exception e) {
			Lg.w(e);
		}
		return bitmap;
	}

	@Override
	public void putBitmap(String url, Bitmap bitmap) {
		String filePath = cachePath + FileCache.decodeKey(url) + cacheType.extension;
		OutputStream out = null;
		try {
            int IO_BUFFER_SIZE = 8 * 1024;
            out = new BufferedOutputStream(new FileOutputStream(filePath), IO_BUFFER_SIZE);
            int DISK_IMAGECACHE_QUALITY = 100;
            bitmap.compress(DISK_IMAGECACHE_COMPRESS_FORMAT, DISK_IMAGECACHE_QUALITY, out);
		} catch (FileNotFoundException e) {
			Lg.w(e);
		} finally {
			if (out != null) {
				try {
					out.close();
				} catch (IOException ignored) {
					Lg.w(ignored);
				}
			}
		}
	}

}
