package com.pingan.ak.component.cache.any;

/**
 * Cache Key.
 * <p>
 * Support Column and Key.
 * Column support Path Format. example:"/c1/c2/c3".
 * <p>
 * Created by hexiaohong on 16/9/7.
 */
public class CacheKey {

    // 静态KEY，推荐新增，发布后不能修改.

    // Default
    public static final Key LoadingPage = new Key(Column.Default, "default-loading-page");

    // Movie
    public static final Key MovieList = new Key(Column.Movie, "movie-list");

    // Favorite
    public static final Key FavoriteList = new Key(Column.Favorite, "favorite-list");

    // Authorize
    public static final Key UserData = new Key(Column.Authorize, "user_data");
    public static final Key UserInfo = new Key(Column.Authorize, "user_info");


    /**
     * 栏目
     */
    public enum Column {
        Default(""),
        Movie("/movie"),
        Favorite("/user/favorite"),
        Authorize("/authorize");

        String name;

        Column(String name) {
            this.name = name;
        }
    }

    /**
     * 键值
     */
    public static class Key {
        Column column;
        String key;

        /**
         * 用于创建动态的KEY
         */
        public Key(Column column, String key) {
            this.column = column;
            this.key = key;
        }

        public String getColumn() {
            return this.column.name;
        }

        public String getKey() {
            return this.key;
        }
    }
}
