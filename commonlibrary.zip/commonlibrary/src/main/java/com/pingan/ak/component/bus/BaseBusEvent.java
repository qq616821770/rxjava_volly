package com.pingan.ak.component.bus;

import com.pingan.pingandata.location.Location;

/**
 * Created by yueang on 16/9/8.
 */
public class BaseBusEvent {


    public static class AppExitEvent extends BaseBusEvent {}
    public static class RegisterCompleteEvent extends BaseBusEvent {}
    public static class FindPasswordCompleteEvent extends BaseBusEvent {}
    public static class BindAccountCompleteEvent extends BaseBusEvent {}
    public static class AppFixedRateTimerEvent extends BaseBusEvent {}
    public static class GotComConfigEvent extends BaseBusEvent {}
    public static class LogOutEvent extends BaseBusEvent{}
    public static class AccountTimeOutEvent extends BaseBusEvent{}
    public static class LoginEvent extends BaseBusEvent {
        public static final int LOGIN_STATE_SUCESS = 0;
        public static final int LOGIN_STATE_FAIL = 1;
        public static final int STATE_OTHER_DEVICE = 2;
        public static final int STATE_TOKEN_INVALID = 3;
        private int loginState;
        protected long uid;

        public int getLoginState() {
            return loginState;
        }

        public long getUid() {
            return uid;
        }
    }

    public static class LocationUpdateEvent extends BaseBusEvent {
        private Location location;

        public Location getLocation() {
            return location;
        }

        public void setLocation(Location location) {
            this.location = location;
        }
    }

    public static final AppExitEvent APP_EXIT_EVENT = new AppExitEvent();
    public static final AppFixedRateTimerEvent APP_FIXED_RATE_TIMER_EVENT = new AppFixedRateTimerEvent();
    public static final RegisterCompleteEvent REGISTER_COMPLETE_EVENT = new RegisterCompleteEvent();
    public static final GotComConfigEvent GOT_COMCONFIG_EVENT = new GotComConfigEvent();
    public static final LogOutEvent LOG_OUT_EVENT = new LogOutEvent();
    public static final AccountTimeOutEvent ACOUNT_TIMEOUT_EVENT = new AccountTimeOutEvent();
    public static final FindPasswordCompleteEvent FIND_PASSWORD_COMPLETE_EVENT = new FindPasswordCompleteEvent();
    public static final BindAccountCompleteEvent BIND_ACCOUNT_COMPLETE_EVENT = new BindAccountCompleteEvent();

}
