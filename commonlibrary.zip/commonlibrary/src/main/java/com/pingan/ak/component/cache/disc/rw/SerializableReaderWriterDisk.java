package com.pingan.ak.component.cache.disc.rw;

import com.pingan.ak.util.IoUtil;

import java.io.File;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;

import cn.core.net.Lg;

/**
 * Created by hexiaohong on 16/8/10.
 */
public class SerializableReaderWriterDisk extends ReaderWriterDisk<Object> {

    @Override
    public Object get(File file) {
        ObjectInputStream ois = null;
        try {
            ois = new ObjectInputStream(new FileInputStream(file));
            return ois.readObject();
        } catch (Exception e) {
            Lg.w(e);
        } finally {
            IoUtil.safeClose(ois);
        }
        return null;
    }

    @Override
    public boolean put(OutputStream os, Object o) {
        ObjectOutputStream oos = null;
        try {
            oos = new ObjectOutputStream(os);
            oos.writeObject(o);
            oos.flush();
            return true;
        } catch (Exception e) {
            Lg.w(e);
        } finally {
            IoUtil.safeClose(oos);
        }
        return false;
    }
}
