package com.pingan.ak.component.cache.any;

import android.content.Context;

import com.pingan.ak.component.cache.disc.DiskCache;
import com.pingan.ak.component.cache.disc.impl.BaseDiskCache;
import com.pingan.ak.component.cache.disc.naming.BaseFileNameGenerator;
import com.pingan.ak.component.cache.memory.MemoryCache;
import com.pingan.ak.component.cache.memory.impl.WeakMemoryCache;

import java.io.File;
import java.io.IOException;

/**
 * Fix File.
 * <p/>
 * Disk Cache storage on /data/data/com.x.y.z/files.
 * <p/>
 * Created by hexiaohong on 16/10/12.
 */
public class FixFiles extends BaseCache {

    @Override
    protected MemoryCache createMemoryCache() {
        return new WeakMemoryCache();
    }

    @Override
    protected DiskCache createDiskCache(Context context, String column) throws IOException {
        if (column == null) column = "";
        File rootDir = context.getFilesDir();
        File cacheDir = new File(rootDir.getAbsolutePath() + column);
        return new BaseDiskCache(cacheDir, null, new BaseFileNameGenerator());
    }
}
