package com.pingan.ak.component.cache.disc.naming;

/**
 * Created by hexiaohong on 16/8/10.
 */
public interface FileNameGenerator {

    String generate(String key);
}
