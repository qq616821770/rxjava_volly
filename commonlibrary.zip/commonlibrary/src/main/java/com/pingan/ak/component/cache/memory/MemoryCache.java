package com.pingan.ak.component.cache.memory;

/**
 * Created by hexiaohong on 16/8/10.
 */
public interface MemoryCache {

    <T> boolean put(String key, T t);

    <T> T get(String key);

    boolean remove(String key);

    void clear();
}
