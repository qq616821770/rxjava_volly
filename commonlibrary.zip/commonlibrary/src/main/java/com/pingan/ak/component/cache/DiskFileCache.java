package com.pingan.ak.component.cache;

import android.os.Environment;
import android.support.annotation.NonNull;

import com.pingan.pingandata.file.generaladvert.FileLoader;


public class DiskFileCache implements FileLoader.FileCache {
    private String cachePath = Environment.getExternalStorageDirectory() + "/PingAnWifi/";

    public DiskFileCache(String path) {
        FileUtils.createIfNoExists(cachePath);
        cachePath = path;
    }

    @Override
    public byte[] getData(String url) {
        FileCache.CacheType cacheType = getType(url);
        String filePath = cachePath + FileCache.decodeKey(url) + cacheType;
        return FileUtils.readBytes(filePath);
    }

    @Override
    public void putData(String url, byte[] data) {
        FileCache.CacheType cacheType = getType(url);
        String filePath = cachePath + FileCache.decodeKey(url) + cacheType;
        FileUtils.writeByteFile(filePath, data);
    }

    @NonNull
    private FileCache.CacheType getType(String url) {
        FileCache.CacheType cacheType;
        if (url.endsWith(FileCache.CacheType.GIF.extension)) {
            cacheType = FileCache.CacheType.GIF;
        } else {
            cacheType = FileCache.CacheType.IMAGE_COVER;
        }
        return cacheType;
    }
}
