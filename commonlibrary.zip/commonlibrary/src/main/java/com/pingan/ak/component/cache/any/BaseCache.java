package com.pingan.ak.component.cache.any;

import android.content.Context;
import android.graphics.Bitmap;

import com.google.gson.Gson;
import com.pingan.ak.component.cache.disc.DiskCache;
import com.pingan.ak.component.cache.disc.rw.BitmapReaderWriterDisk;
import com.pingan.ak.component.cache.disc.rw.BytesReaderWriterDisk;
import com.pingan.ak.component.cache.disc.rw.InputStreamReaderWriterDisk;
import com.pingan.ak.component.cache.disc.rw.SerializableReaderWriterDisk;
import com.pingan.ak.component.cache.disc.rw.StringReaderWriterDisk;
import com.pingan.ak.component.cache.memory.MemoryCache;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import cn.core.net.Lg;

/**
 * Base Cache.
 * <p/>
 * Support Memory Cache, Disk Cache, Memory and Disk Cache.
 * <p/>
 * Support String, Bitmap, Serializable, Bytes, InputStream.
 * <p/>
 * Created by hexiaohong on 16/8/10.
 */
abstract class BaseCache {

    /**
     * The type Rw disk.
     */
    static class RWDisk {
        /**
         * The String reader writer disk.
         */
        static StringReaderWriterDisk stringReaderWriterDisk;
        /**
         * The Bitmap reader writer disk.
         */
        static BitmapReaderWriterDisk bitmapReaderWriterDisk;
        /**
         * The Serializable reader writer disk.
         */
        static SerializableReaderWriterDisk serializableReaderWriterDisk;

        /**
         * The Bytes reader writer disk.
         */
        static BytesReaderWriterDisk bytesReaderWriterDisk;

        /**
         * The Input stream reader writer disk.
         */
        static InputStreamReaderWriterDisk inputStreamReaderWriterDisk;

        /**
         * Gets string reader writer disk.
         *
         * @return the string reader writer disk
         */
        static StringReaderWriterDisk getStringReaderWriterDisk() {
            if (stringReaderWriterDisk == null) {
                synchronized (RWDisk.class) {
                    stringReaderWriterDisk = new StringReaderWriterDisk();
                }
            }
            return stringReaderWriterDisk;
        }

        /**
         * Gets bitmap reader writer disk.
         *
         * @return the bitmap reader writer disk
         */
        static BitmapReaderWriterDisk getBitmapReaderWriterDisk() {
            if (bitmapReaderWriterDisk == null) {
                synchronized (RWDisk.class) {
                    bitmapReaderWriterDisk = new BitmapReaderWriterDisk();
                }
            }
            return bitmapReaderWriterDisk;
        }

        /**
         * Gets serializable reader writer disk.
         *
         * @return the serializable reader writer disk
         */
        static SerializableReaderWriterDisk getSerializableReaderWriterDisk() {
            if (serializableReaderWriterDisk == null) {
                synchronized (RWDisk.class) {
                    serializableReaderWriterDisk = new SerializableReaderWriterDisk();
                }
            }
            return serializableReaderWriterDisk;
        }

        /**
         * Gets bytes reader writer disk.
         *
         * @return the bytes reader writer disk
         */
        static BytesReaderWriterDisk getBytesReaderWriterDisk() {
            if (bytesReaderWriterDisk == null) {
                synchronized (RWDisk.class) {
                    bytesReaderWriterDisk = new BytesReaderWriterDisk();
                }
            }
            return bytesReaderWriterDisk;
        }

        /**
         * Gets input stream reader writer disk.
         *
         * @return the input stream reader writer disk
         */
        static InputStreamReaderWriterDisk getInputStreamReaderWriterDisk() {
            if (inputStreamReaderWriterDisk == null) {
                synchronized (RWDisk.class) {
                    inputStreamReaderWriterDisk = new InputStreamReaderWriterDisk();
                }
            }
            return inputStreamReaderWriterDisk;
        }
    }

    private Context mContext;

    private Map<String, DiskCache> mDiskCaches;

    private MemoryCache mMemoryCache;

    private Gson gson = new Gson();

    /**
     * Instantiates a new Lru cache.
     */
    protected BaseCache() {

    }

    /**
     * Init.
     *
     * @param context the context
     */
    public void init(Context context) {
        mContext = context;
        mDiskCaches = new HashMap<String, DiskCache>();
        mMemoryCache = createMemoryCache();
    }

    /**
     * Clear memory.
     */
    public void clearMemory() {
        if (mMemoryCache != null) {
            mMemoryCache.clear();
        }
    }

    /**
     * Clear disk.
     */
    public void clearDisk() {
        if (mDiskCaches != null) {
            Iterator<Map.Entry<String, DiskCache>> iterator = mDiskCaches.entrySet().iterator();
            while (iterator.hasNext()) {
                iterator.next().getValue().clear();
            }
        }
    }

    /**
     * Clear.
     */
    public void clear() {
        clearMemory();
        clearDisk();
    }

    /**
     * Remove Memory.
     * @param key
     */
    public void removeMemory(String key) {
        if (mMemoryCache != null) {
            mMemoryCache.remove(key);
        }
    }

    /**
     * Remove Disk.
     * @param key
     */
    public void removeDisk(String key) {
        if (mDiskCaches != null) {
            mDiskCaches.remove(key);
        }
    }

    /**
     * Remove.
     * @param key
     */
    public void remove(String key) {
        removeMemory(key);
        removeDisk(key);
    }

    /**
     * Create memory cache memory cache.
     *
     * @return the memory cache
     */
    protected abstract MemoryCache createMemoryCache();

    /**
     * Create disk cache disk cache.
     *
     * @param context the context
     * @param column  the column
     * @return the disk cache
     * @throws IOException the io exception
     */
    protected abstract DiskCache createDiskCache(Context context, String column) throws IOException;

    private DiskCache getDiskCache(String column) throws IOException {
        if (column == null) column = "";
        column = column.replaceAll("/", File.separator);

        if (mDiskCaches.containsKey(column)) {
            return mDiskCaches.get(column);
        }

        DiskCache diskCache = createDiskCache(mContext, column);
        mDiskCaches.put(column, diskCache);

        return diskCache;
    }

    private DiskCache getDefaultDiskCache() throws IOException {
        return getDiskCache(null);
    }

    private Map<String, DiskCache> getDiskCaches() {
        return mDiskCaches;
    }

    private MemoryCache getMemoryCache() {
        return mMemoryCache;
    }


    /**
     * Gets from memory.
     *
     * @param <T> the type parameter
     * @param key the key
     * @return the from memory
     */
    public <T> T getFromMemory(String key) {
        return getMemoryCache().get(key);
    }

    /**
     * Gets from memory.
     *
     * @param <T> the type parameter
     * @param key the key
     * @return the from memory
     */
    public <T> T getFromMemory(CacheKey.Key key) {
        return getFromMemory(key.getColumn() + ":" + key.getKey());
    }

    /**
     * Gets string from disk.
     *
     * @param key the key
     * @return the string from disk
     */
    public String getStringFromDisk(String key) {
        try {
            return getDefaultDiskCache()
                    .get(key, RWDisk.getStringReaderWriterDisk());
        } catch (IOException e) {
            Lg.w(e);
        }
        return null;
    }

    /**
     * Gets string from disk.
     *
     * @param key the key
     * @return the string from disk
     */
    public String getStringFromDisk(CacheKey.Key key) {
        try {
            return getDiskCache(key.getColumn())
                    .get(key.getKey(), RWDisk.getStringReaderWriterDisk());
        } catch (IOException e) {
            Lg.w(e);
        }
        return null;
    }

    /**
     * Gets string from memory disk.
     *
     * @param key the key
     * @return the string from memory disk
     */
    public String getStringFromMemoryDisk(String key) {
        String value = getFromMemory(key);
        if (value == null) {
            value = getStringFromDisk(key);
            if (value != null) {
                putToMemory(key, value);
            }
        }
        return value;
    }

    /**
     * Gets string from memory disk.
     *
     * @param key the key
     * @return the string from memory disk
     */
    public String getStringFromMemoryDisk(CacheKey.Key key) {
        String value = getFromMemory(key);
        if (value == null) {
            value = getStringFromDisk(key);
            if (value != null) {
                putToMemory(key, value);
            }
        }
        return value;
    }

    /**
     * Gets bitmap from disk.
     *
     * @param key the key
     * @return the bitmap from disk
     */
    public Bitmap getBitmapFromDisk(String key) {
        try {
            return getDefaultDiskCache()
                    .get(key, RWDisk.getBitmapReaderWriterDisk());
        } catch (IOException e) {
            Lg.w(e);
        }
        return null;
    }

    /**
     * Gets bitmap from disk.
     *
     * @param key the key
     * @return the bitmap from disk
     */
    public Bitmap getBitmapFromDisk(CacheKey.Key key) {
        try {
            return getDiskCache(key.getColumn())
                    .get(key.getKey(), RWDisk.getBitmapReaderWriterDisk());
        } catch (IOException e) {
            Lg.w(e);
        }
        return null;
    }

    /**
     * Gets bitmap from memory disk.
     *
     * @param key the key
     * @return the bitmap from memory disk
     */
    public Bitmap getBitmapFromMemoryDisk(String key) {
        Bitmap value = getFromMemory(key);
        if (value == null) {
            value = getBitmapFromDisk(key);
            if (value != null) {
                putToMemory(key, value);
            }
        }
        return value;
    }

    /**
     * Gets bitmap from memory disk.
     *
     * @param key the key
     * @return the bitmap from memory disk
     */
    public Bitmap getBitmapFromMemoryDisk(CacheKey.Key key) {
        Bitmap value = getFromMemory(key);
        if (value == null) {
            value = getBitmapFromDisk(key);
            if (value != null) {
                putToMemory(key, value);
            }
        }
        return value;
    }

    /**
     * Gets serializable from disk.
     *
     * @param key the key
     * @return the serializable from disk
     */
    public Object getSerializableFromDisk(String key) {
        try {
            return getDefaultDiskCache()
                    .get(key, RWDisk.getSerializableReaderWriterDisk());
        } catch (IOException e) {
            Lg.w(e);
        }
        return null;
    }

    /**
     * Gets serializable from disk.
     *
     * @param key the key
     * @return the serializable from disk
     */
    public Object getSerializableFromDisk(CacheKey.Key key) {
        try {
            return getDiskCache(key.getColumn())
                    .get(key.getKey(), RWDisk.getSerializableReaderWriterDisk());
        } catch (IOException e) {
            Lg.w(e);
        }
        return null;
    }

    /**
     * Gets serializable from memory disk.
     *
     * @param key the key
     * @return the serializable from memory disk
     */
    public Object getSerializableFromMemoryDisk(String key) {
        Object value = getFromMemory(key);
        if (value == null) {
            value = getSerializableFromDisk(key);
            if (value != null) {
                putToMemory(key, value);
            }
        }
        return value;
    }

    /**
     * Gets serializable from memory disk.
     *
     * @param key the key
     * @return the serializable from memory disk
     */
    public Object getSerializableFromMemoryDisk(CacheKey.Key key) {
        Object value = getFromMemory(key);
        if (value == null) {
            value = getSerializableFromDisk(key);
            if (value != null) {
                putToMemory(key, value);
            }
        }
        return value;
    }

    /**
     * Get bytes from disk byte [ ].
     *
     * @param key the key
     * @return the byte [ ]
     */
    public byte[] getBytesFromDisk(String key) {
        try {
            return getDefaultDiskCache()
                    .get(key, RWDisk.getBytesReaderWriterDisk());
        } catch (IOException e) {
            Lg.w(e);
        }
        return null;
    }

    /**
     * Get bytes from disk byte [ ].
     *
     * @param key the key
     * @return the byte [ ]
     */
    public byte[] getBytesFromDisk(CacheKey.Key key) {
        try {
            return getDiskCache(key.getColumn())
                    .get(key.getKey(), RWDisk.getBytesReaderWriterDisk());
        } catch (IOException e) {
            Lg.w(e);
        }
        return null;
    }

    /**
     * Get bytes from memory disk byte [ ].
     *
     * @param key the key
     * @return the byte [ ]
     */
    public byte[] getBytesFromMemoryDisk(String key) {
        byte[] value = getFromMemory(key);
        if (value == null) {
            value = getBytesFromDisk(key);
            if (value != null) {
                putToMemory(key, value);
            }
        }
        return value;
    }

    /**
     * Get bytes from memory disk byte [ ].
     *
     * @param key the key
     * @return the byte [ ]
     */
    public byte[] getBytesFromMemoryDisk(CacheKey.Key key) {
        byte[] value = getFromMemory(key);
        if (value == null) {
            value = getBytesFromDisk(key);
            if (value != null) {
                putToMemory(key, value);
            }
        }
        return value;
    }

    /**
     * Gets input stream from disk.
     *
     * @param key the key
     * @return the input stream from disk
     */
    public InputStream getInputStreamFromDisk(String key) {
        try {
            return getDefaultDiskCache()
                    .get(key, RWDisk.getInputStreamReaderWriterDisk());
        } catch (IOException e) {
            Lg.w(e);
        }
        return null;
    }

    /**
     * Gets input stream from disk.
     *
     * @param key the key
     * @return the input stream from disk
     */
    public InputStream getInputStreamFromDisk(CacheKey.Key key) {
        try {
            return getDiskCache(key.getColumn())
                    .get(key.getKey(), RWDisk.getInputStreamReaderWriterDisk());
        } catch (IOException e) {
            Lg.w(e);
        }
        return null;
    }

    /**
     * Gets input stream from memory disk.
     *
     * @param key the key
     * @return the input stream from memory disk
     */
    public InputStream getInputStreamFromMemoryDisk(String key) {
        InputStream value = getFromMemory(key);
        if (value == null) {
            value = getInputStreamFromDisk(key);
            if (value != null) {
                putToMemory(key, value);
            }
        }
        return value;
    }

    /**
     * Gets input stream from memory disk.
     *
     * @param key the key
     * @return the input stream from memory disk
     */
    public InputStream getInputStreamFromMemoryDisk(CacheKey.Key key) {
        InputStream value = getFromMemory(key);
        if (value == null) {
            value = getInputStreamFromDisk(key);
            if (value != null) {
                putToMemory(key, value);
            }
        }
        return value;
    }

    /**
     * Put to memory.
     *
     * @param <T>   the type parameter
     * @param key   the key
     * @param value the value
     */
    public <T> void putToMemory(String key, T value) {
        getMemoryCache().put(key, value);
    }

    /**
     * Put to memory.
     *
     * @param <T>   the type parameter
     * @param key   the key
     * @param value the value
     */
    public <T> void putToMemory(CacheKey.Key key, T value) {
        putToMemory(key.getColumn() + ":" + key.getKey(), value);
    }

    /**
     * Put string to disk.
     *
     * @param key   the key
     * @param value the value
     */
    public void putStringToDisk(String key, String value) {
        try {
            getDefaultDiskCache()
                    .put(key, value, RWDisk.getStringReaderWriterDisk());
        } catch (IOException e) {
            Lg.w(e);
        }
    }

    /**
     * Put string to disk.
     *
     * @param key   the key
     * @param value the value
     */
    public void putStringToDisk(CacheKey.Key key, String value) {
        try {
            getDiskCache(key.getColumn())
                    .put(key.getKey(), value, RWDisk.getStringReaderWriterDisk());
        } catch (IOException e) {
            Lg.w(e);
        }
    }

    /**
     * Put string to memory disk.
     *
     * @param key   the key
     * @param value the value
     */
    public void putStringToMemoryDisk(String key, String value) {
        putToMemory(key, value);
        putStringToDisk(key, value);
    }

    /**
     * Put string to memory disk.
     *
     * @param key   the key
     * @param value the value
     */
    public void putStringToMemoryDisk(CacheKey.Key key, String value) {
        putToMemory(key, value);
        putStringToDisk(key, value);
    }

    /**
     * Put bitmap to disk.
     *
     * @param key   the key
     * @param value the value
     */
    public void putBitmapToDisk(String key, Bitmap value) {
        try {
            getDefaultDiskCache()
                    .put(key, value, RWDisk.getBitmapReaderWriterDisk());
        } catch (IOException e) {
            Lg.w(e);
        }
    }

    /**
     * Put bitmap to disk.
     *
     * @param key   the key
     * @param value the value
     */
    public void putBitmapToDisk(CacheKey.Key key, Bitmap value) {
        try {
            getDiskCache(key.getColumn())
                    .put(key.getKey(), value, RWDisk.getBitmapReaderWriterDisk());
        } catch (IOException e) {
            Lg.w(e);
        }
    }

    /**
     * Put bitmap to memory disk.
     *
     * @param key   the key
     * @param value the value
     */
    public void putBitmapToMemoryDisk(String key, Bitmap value) {
        putToMemory(key, value);
        putBitmapToDisk(key, value);
    }

    /**
     * Put bitmap to memory disk.
     *
     * @param key   the key
     * @param value the value
     */
    public void putBitmapToMemoryDisk(CacheKey.Key key, Bitmap value) {
        putToMemory(key, value);
        putBitmapToDisk(key, value);
    }

    /**
     * Put serializable to disk.
     *
     * @param key   the key
     * @param value the value
     */
    public void putSerializableToDisk(String key, Object value) {
        try {
            getDefaultDiskCache()
                    .put(key, value, RWDisk.getSerializableReaderWriterDisk());
        } catch (IOException e) {
            Lg.w(e);
        }
    }

    /**
     * Put serializable to disk.
     *
     * @param key   the key
     * @param value the value
     */
    public void putSerializableToDisk(CacheKey.Key key, Object value) {
        try {
            getDiskCache(key.getColumn())
                    .put(key.getKey(), value, RWDisk.getSerializableReaderWriterDisk());
        } catch (IOException e) {
            Lg.w(e);
        }
    }

    /**
     * Put serializable to memory disk.
     *
     * @param key   the key
     * @param value the value
     */
    public void putSerializableToMemoryDisk(String key, Object value) {
        putToMemory(key, value);
        putSerializableToDisk(key, value);
    }

    /**
     * Put serializable to memory disk.
     *
     * @param key   the key
     * @param value the value
     */
    public void putSerializableToMemoryDisk(CacheKey.Key key, Object value) {
        putToMemory(key, value);
        putSerializableToDisk(key, value);
    }

    /**
     * Put bytes to disk.
     *
     * @param key   the key
     * @param value the value
     */
    public void putBytesToDisk(String key, byte[] value) {
        try {
            getDefaultDiskCache()
                    .put(key, value, RWDisk.getBytesReaderWriterDisk());
        } catch (IOException e) {
            Lg.w(e);
        }
    }

    /**
     * Put bytes to disk.
     *
     * @param key   the key
     * @param value the value
     */
    public void putBytesToDisk(CacheKey.Key key, byte[] value) {
        try {
            getDiskCache(key.getColumn())
                    .put(key.getKey(), value, RWDisk.getBytesReaderWriterDisk());
        } catch (IOException e) {
            Lg.w(e);
        }
    }

    /**
     * Put bytes to memory disk.
     *
     * @param key   the key
     * @param value the value
     */
    public void putBytesToMemoryDisk(String key, byte[] value) {
        putToMemory(key, value);
        putBytesToDisk(key, value);
    }

    /**
     * Put bytes to memory disk.
     *
     * @param key   the key
     * @param value the value
     */
    public void putBytesToMemoryDisk(CacheKey.Key key, byte[] value) {
        putToMemory(key, value);
        putBytesToDisk(key, value);
    }

    /**
     * Put input stream to disk.
     *
     * @param key   the key
     * @param value the value
     */
    public void putInputStreamToDisk(String key, InputStream value) {
        try {
            getDefaultDiskCache()
                    .put(key, value, RWDisk.getInputStreamReaderWriterDisk());
        } catch (IOException e) {
            Lg.w(e);
        }
    }

    /**
     * Put input stream to disk.
     *
     * @param key   the key
     * @param value the value
     */
    public void putInputStreamToDisk(CacheKey.Key key, InputStream value) {
        try {
            getDiskCache(key.getColumn())
                    .put(key.getKey(), value, RWDisk.getInputStreamReaderWriterDisk());
        } catch (IOException e) {
            Lg.w(e);
        }
    }

    /**
     * Put input stream to memory disk.
     *
     * @param key   the key
     * @param value the value
     */
    public void putInputStreamToMemoryDisk(String key, InputStream value) {
        putToMemory(key, value);
        putInputStreamToDisk(key, value);
    }

    /**
     * Put input stream to memory disk.
     *
     * @param key   the key
     * @param value the value
     */
    public void putInputStreamToMemoryDisk(CacheKey.Key key, InputStream value) {
        putToMemory(key, value);
        putInputStreamToDisk(key, value);
    }
}
