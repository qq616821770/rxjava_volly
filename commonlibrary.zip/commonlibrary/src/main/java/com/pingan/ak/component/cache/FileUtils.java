package com.pingan.ak.component.cache;

import android.text.TextUtils;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.StringReader;

import cn.core.net.Lg;

public class FileUtils {

    private static final String TAG = "FileUtils";
    private static final int BUFFER_SIZE = 8192;

    public static boolean fileIsExist(String filePath) {
        if (filePath == null || filePath.length() < 1) {
            return false;
        }

        File f = new File(filePath);
        if (!f.exists()) {
            return false;
        }
        return true;
    }

    public static InputStream readFile(String filePath) {
        InputStream is = null;
        if (fileIsExist(filePath)) {
            File f = new File(filePath);
            try {
                is = new FileInputStream(f);
            } catch (FileNotFoundException e) {
                Lg.w(e);
            }
        } else {
            return null;
        }
        return is;
    }

    public static byte[] readBytes(String filePath) {
        InputStream inputstream = readFile(filePath);
        if (inputstream == null) {
            return null;
        }
        BufferedInputStream in = null;
        ByteArrayOutputStream outStream = null;
        byte[] buffer = new byte[BUFFER_SIZE];
        int len = 0;
        byte[] data = null;
        try {
            outStream =new ByteArrayOutputStream();
           in = new BufferedInputStream(inputstream);
            while ((len = in.read(buffer)) != -1) {
                outStream.write(buffer, 0, len);
            }
            data = outStream.toByteArray();
        } catch (IOException e) {
            Lg.w(e);
            return null;
        } finally {
            closeSafely(in);
            closeSafely(outStream);
        }
        // 把outStream里的数据写入内存
        return data;
    }

    public static void writeByteFile(String filePath, byte[] bytes) {
        File distFile = new File(filePath);
        if (!distFile.getParentFile().exists()) {
            distFile.getParentFile().mkdirs();
        }
        BufferedOutputStream bos = null;
        FileOutputStream fileOutputStream = null;
        try {
            fileOutputStream = new FileOutputStream(filePath);
            bos = new BufferedOutputStream(fileOutputStream, BUFFER_SIZE);
            bos.write(bytes);
        } catch (Exception e) {
            Lg.e("save " + filePath + " failed!", e);
        } finally {
            closeSafely(bos);
            closeSafely(fileOutputStream);
        }
    }

    public static void writeTextFile(String data, String filePath) {
        File distFile = new File(filePath);
        if (!distFile.getParentFile().exists()) {
            distFile.getParentFile().mkdirs();
        }
        BufferedReader bufferedReader = null;
        BufferedWriter bufferedWriter = null;
        FileWriter fileWriter = null;
        try {
            bufferedReader = new BufferedReader(new StringReader(data));
            fileWriter = new FileWriter(distFile);
            bufferedWriter = new BufferedWriter(fileWriter);
            int len = -1;
            char buf[] = new char[BUFFER_SIZE];
            while ((len = bufferedReader.read(buf)) != -1) {
                bufferedWriter.write(buf, 0, len);
            }
            bufferedWriter.flush();
        } catch (IOException e) {
            Lg.e("write " + filePath + " data failed!", e);
        } finally {
            if (bufferedReader != null) {
                try {
                    bufferedReader.close();
                } catch (IOException e) {
                }
            }
            if (bufferedWriter != null) {
                try {
                    bufferedWriter.close();
                } catch (IOException e) {
                }
            }
            if(null != fileWriter){
                try {
                    fileWriter.close();
                } catch (IOException e) {
                }
            }
        }
    }

    public static String readTextFile(String filePath) {
        File file = new File(filePath);
        BufferedReader reader = null;
        StringBuilder sb = new StringBuilder();
        FileReader fileReader = null;
        try {
            fileReader = new FileReader(file);
            reader = new BufferedReader(fileReader);
            char[] buffer = new char[1024];
            int len = 0;
            while ((len = reader.read(buffer)) != -1) {
                sb.append(buffer, 0, len);
            }
            // reader.close();
        } catch (IOException e) {
            Lg.e("readTextFile " + filePath + " failed!", e);
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e1) {
                }
            }
            if (fileReader != null){
                try {
                    fileReader.close();
                } catch (IOException e2) {
                    Lg.e(e2);
                }
            }
        }
        return sb.toString();
    }

    public static void serialize(String filePath, Object obj) {
        File distFile = new File(filePath);
        if (distFile.getParentFile() != null && !distFile.getParentFile().exists()) {
            distFile.getParentFile().mkdirs();
        }
        ObjectOutputStream out = null;
        try {
            out = new ObjectOutputStream(new FileOutputStream(filePath));
            out.writeObject(obj);
        } catch (Exception e) {
            Lg.w(e);
            if (distFile.exists()) {
                distFile.delete();
            }
        } finally {
            closeSafely(out);
        }
    }

    public static Object deserialize(String filePath) {

        ObjectInputStream in = null;
        FileInputStream fileInputStream = null;
        try {
            fileInputStream = new FileInputStream(filePath);
            in = new ObjectInputStream(fileInputStream);
            return in.readObject();
        } catch (Exception e) {
            Lg.e("deserialize " + filePath + " failed!", e);
        } finally {
            closeSafely(in);
            closeSafely(fileInputStream);
        }
        return null;
    }

    public static Object deserialize(InputStream is) {
        ObjectInputStream in = null;
        try {
            in = new ObjectInputStream(is);
            return in.readObject();
        } catch (Exception e) {
            Lg.w(e);
        } finally {
            if (in != null) {
                try {
                    in.close();
                } catch (IOException e) {
                    Lg.w(e);
                }
            }
        }
        return null;
    }

    /**
     * 如果不存在就创建
     */
    public static boolean createIfNoExists(String path) {
        File file = new File(path);
        boolean mk = false;
        if (!file.exists()) {
            mk = file.mkdirs();
        } else {
            if (!file.isDirectory()) {// 如果不是文件夹路径 删除重新创建
                file.delete();
                mk = file.mkdirs();
            } else {
                mk = true;
            }
        }
        return mk;
    }

    public static void deleteFiles(File dirFile) {
        // try {

        if (dirFile != null && dirFile.exists()) {
            File file[] = dirFile.listFiles();
            for (int i = 0; i < file.length; i++) {
                if (file[i].isDirectory()) {
                    deleteFiles(file[i]);
                } else {
                    file[i].delete();
                }
            }
        }
        // }
        // catch (Exception e) {
        //   Lg.w(e);
        // }
    }


    public static void deleteFile(String filePath) {
        if (!TextUtils.isEmpty(filePath)) {
            File file = new File(filePath);
            if (file.exists()) {
                file.delete();
            }
        }
    }

    private static void closeSafely(Closeable c) {
        if (c != null) {
            try {
                c.close();
            } catch (IOException e) {
                Lg.w(e);
            }
        }
    }
}
