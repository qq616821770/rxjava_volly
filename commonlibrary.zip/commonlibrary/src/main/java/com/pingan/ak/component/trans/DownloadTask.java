package com.pingan.ak.component.trans;

import com.pingan.ak.component.net.http.OkHttpUtils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import cn.core.net.Lg;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Headers;
import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

/**
 * Created by hexiaohong on 16/8/22.
 */
class DownloadTask extends TransTask {

    public DownloadTask(TransNode transNode, TransCallback transCallback) {
        this.transNode = transNode;
        this.transCallback = transCallback;
    }

    @Override
    public boolean checkTask() {
        final File file = new File(transNode.localPath);
        if (file.exists() && file.isFile()) {
            transNode.completeSize = file.length();
            transNode.totalSize = transNode.completeSize;
            transNode.transStatus = TransNode.TransStatus.Succeed;
            if (transCallback != null) {
                transCallback.onTrans(transNode);
            }
            return false;
        }
        return true;
    }

    @Override
    public synchronized void runTask() {
        if (transNode.transStatus == TransNode.TransStatus.Running) {
            return;
        }

        transNode.transStatus = TransNode.TransStatus.Running;
        transNode.completeSize = 0L;
        transNode.totalSize = 0L;

        final File file = new File(transNode.localPath);
        final File tmpFile = new File(transNode.localPath + ".tmp");
        long startPosition = 0L;

        Request.Builder builder = new Request.Builder();

        // url
        builder.url(transNode.url);

        // tag
        builder.tag(transNode.id);

        // file
        if (file.exists() && file.isFile()) {
            transNode.completeSize = file.length();
            transNode.totalSize = transNode.completeSize;
            transNode.transStatus = TransNode.TransStatus.Succeed;
            if (transCallback != null) {
                transCallback.onTrans(transNode);
            }
            return;
        }

        if (tmpFile.exists() && tmpFile.isFile()) {
            if (transNode.supportBreakpoint) {
                startPosition = tmpFile.length();
                transNode.completeSize = tmpFile.length();
                transNode.totalSize = transNode.completeSize;

                transNode.headers.put("RANGE", "bytes=" + startPosition + "-");
            } else {
                tmpFile.delete();
            }
        } else {
            try {
                File tmpParentFile = tmpFile.getParentFile();
                if (!tmpParentFile.exists()) {
                    tmpParentFile.mkdirs();
                }
            } catch (Exception e) {
                Lg.w(e);
            }
        }

        // header
        builder.headers(Headers.of(transNode.headers));

        // call
        try {
            Request request = builder.build();

            OkHttpClient client = OkHttpUtils.getClient();

            final long bytesBase = startPosition;
            final OkHttpUtils.ProgressListener progressListener = new OkHttpUtils.ProgressListener() {
                @Override
                public void update(long bytesRead, long contentLength, boolean done) {
                    transNode.completeSize = bytesBase + bytesRead;
                    transNode.totalSize = bytesBase + contentLength;
                    if (transCallback != null) {
                        transCallback.onTrans(transNode);
                    }
                }
            };

            client = client.newBuilder()
                    .addNetworkInterceptor(new Interceptor() {
                        @Override
                        public Response intercept(Chain chain) throws IOException {
                            Response originalResponse = chain.proceed(chain.request());
                            return originalResponse.newBuilder()
                                    .body(new OkHttpUtils.ProgressResponseBody(originalResponse.body(), progressListener))
                                    .build();
                        }
                    }).build();

            // must async, support cancel
            client.newCall(request).enqueue(new Callback() {
                @Override
                public void onFailure(Call call, IOException e) {
                    Lg.w(e);
                    maybeFailed();
                }

                @Override
                public void onResponse(Call call, Response response) {
                    if (!response.isSuccessful()) {
                        maybeFailed();
                        return;
                    }

                    // save
                    try {
                        copyStream(response.body().byteStream(), new FileOutputStream(tmpFile, transNode.supportBreakpoint),
                                new CopyListener() {
                                    @Override
                                    public boolean isInterrupted() {
                                        return transNode.transStatus != TransNode.TransStatus.Running;
                                    }
                                }, transNode.bufferSize);

                        if (transNode.transStatus == TransNode.TransStatus.Running) {
                            if (transNode.totalSize == tmpFile.length()) {
                                if (!tmpFile.renameTo(file)) {
                                    copyStream(new FileInputStream(tmpFile), new FileOutputStream(file), null, 10 * 1024);
                                    tmpFile.delete();
                                }
                                transNode.transStatus = TransNode.TransStatus.Succeed;
                            }
                        }
                        if (transCallback != null) {
                            transCallback.onTrans(transNode);
                        }
                    } catch (Exception e) {
                        Lg.w(e);
                        maybeFailed();
                    }
                }
            });

        } catch (Exception e) {
            Lg.w(e);
            maybeFailed();
        }
    }

    @Override
    public void hangupTask() {
        transNode.transStatus = TransNode.TransStatus.Pending;
        OkHttpUtils.cancel(transNode.id);
    }

    @Override
    public void pauseTask() {
        transNode.transStatus = TransNode.TransStatus.Paused;
        OkHttpUtils.cancel(transNode.id);
    }

    @Override
    public void cancelTask() {
        transNode.transStatus = TransNode.TransStatus.Canceled;
        OkHttpUtils.cancel(transNode.id);
    }

    private void maybeFailed() {
        if (transNode.transStatus != TransNode.TransStatus.Pending
                && transNode.transStatus != TransNode.TransStatus.Paused
                && transNode.transStatus != TransNode.TransStatus.Canceled) {

            transNode.transStatus = TransNode.TransStatus.Failed;
        }
        if (transCallback != null) {
            transCallback.onTrans(transNode);
        }
    }
}
