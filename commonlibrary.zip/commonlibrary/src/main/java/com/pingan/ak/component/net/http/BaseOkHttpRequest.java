package com.pingan.ak.component.net.http;

import android.util.Log;

import com.google.gson.Gson;

import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Field;
import java.util.Iterator;
import java.util.Map;

import cn.core.net.Lg;
import okhttp3.FormBody;
import okhttp3.Headers;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;


public abstract class BaseOkHttpRequest<T> extends BaseRequest<T> {

    private okhttp3.Call mCall;

    public BaseOkHttpRequest(Class<T> clazz, IRequestCallBack<T> callback) {
        super(clazz, callback);
    }

    @Override
    protected void doExec() {
        try {
            Request request;

            if (mMethod.equalsIgnoreCase(GET)) {
                request = new Request.Builder()
                        .headers(Headers.of(mHeaders))
                        .url(mUrl)
                        .tag(mTag)
                        .build();

            } else if (mMethod.equalsIgnoreCase(POST)) {
                RequestBody requestBody;

                if (isMultipart()) {
                    MultipartBody.Builder multipartBuilder = new MultipartBody.Builder();

                    multipartBuilder.setType(MultipartBody.FORM);

                    Iterator<Part> iteratorPart = mParts.iterator();
                    while (iteratorPart.hasNext()) {
                        Part part = iteratorPart.next();
                        multipartBuilder.addFormDataPart(part.name, part.value);
                    }

                    Iterator<FilePart> iteratorFilePart = mFileParts.iterator();
                    while (iteratorFilePart.hasNext()) {
                        FilePart filePart = iteratorFilePart.next();
                        multipartBuilder.addFormDataPart(filePart.name, filePart.filename,
                                RequestBody.create(MediaType.parse(filePart.mime), filePart.file));
                    }

                    requestBody = multipartBuilder.build();
                } else {
                    FormBody.Builder formBuilder = new FormBody.Builder();

                    Iterator<Map.Entry<String, String>> iterator = mFields.entrySet().iterator();
                    while (iterator.hasNext()) {
                        Map.Entry<String, String> entry = iterator.next();
                        formBuilder.add(entry.getKey(), entry.getValue());
                    }

                    requestBody = formBuilder.build();
                }

                request = new Request.Builder()
                        .headers(Headers.of(mHeaders))
                        .url(mUrl)
                        .post(requestBody)
                        .tag(mTag)
                        .build();
            } else {
                throw new IllegalArgumentException("req method not support");
            }

            mCall = OkHttpUtils.getClient().newCall(request);

            Response response = mCall.execute();

            if (response.isSuccessful()) {
                if (DEBUG) {
                    Headers responseHeaders = response.headers();

                    Log.d(TAG, "response sequence[" + mSequence + "], "
                            + "tag:" + mTag + ", "
                            + "headers:" + responseHeaders.toString());
                }

                if (mCallBack != null) {
                    String body = response.body().string();

                    if (DEBUG) {
                        try {
                            JSONObject jsonObject = new JSONObject(body);
//                            Log.d(TAG, "response sequence[" + mSequence + "], "
//                                    + "tag:" + mTag + ", "
//                                    + "data:" + jsonObject.toString(2));

                            showLog(jsonObject);
                        } catch (Exception e) {
                            Log.e(TAG, "log response data exception occurs");
                        }
                    }

                    T t = new Gson().fromJson(body, mClazz);
                    setHiddenBody(t, body);
                    mCallBack.onResponse(new BaseStatus(response.code(), response.message(), null), t);
                }
            } else {
                if (DEBUG) {
                    Log.w(TAG, "exec exception occurs, " + response.code());
                }

                if (mCallBack != null) {
                    mCallBack.onResponse(new BaseStatus(response.code(), response.message(), new ErrorCodeException(response.code())), null);
                }
            }
        } catch (Exception e) {
            if (DEBUG) {
                Log.w(TAG, "exec exception occurs, " + e.getMessage());
            }

            if (mCallBack != null) {
                mCallBack.onResponse(new BaseStatus(-1, e.getMessage(), e), null);
            }
        }
    }


    /**
     * topOne接口一次打印不全，截取分开打印，测试完毕后删除
     * @param jsonObject
     */
    public void showLog(JSONObject jsonObject) {
        String str = null;
        try {
            str = jsonObject.toString(2);
        } catch (JSONException e) {
            Lg.w(e);
        }
        int index = 0;
        int maxLength = 3000;
        String finalString = null;

        int time = str.length() / maxLength;
        if (time > 0) {
            for (int i = 0; i < time; i++) {
                if ((i + 1) * maxLength > str.length()) {
                    finalString = str.substring(i * maxLength, str.length());
                } else {
                    finalString = str.substring(i * maxLength, (i + 1) * maxLength);
                }

                Log.d(TAG, "response sequence[" + mSequence + "], "
                        + "tag:" + mTag + ", "
                        + "data:" + finalString);
            }
        } else {
            finalString = str.substring(index);
            Log.d(TAG, "response sequence[" + mSequence + "], "
                    + "tag:" + mTag + ", "
                    + "data:" + finalString);
        }

    }

    @Override
    public void doCancel() {
        if (mCall != null) {
            mCall.cancel();
        }
    }

    private void setHiddenBody(T t, String body) {
        Field field;
        try {
            // 暂定方案：仅在需要原始body数据时，才通过反射成员变量赋值
            field = t.getClass().getField("hiddenBody");
            field.setAccessible(true);
            field.set(t, body);
        } catch (Exception e) {

        }
    }
}
