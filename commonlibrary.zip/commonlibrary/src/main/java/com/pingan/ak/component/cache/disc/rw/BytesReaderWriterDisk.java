package com.pingan.ak.component.cache.disc.rw;

import com.pingan.ak.util.IoUtil;

import java.io.File;
import java.io.FileInputStream;
import java.io.OutputStream;

import cn.core.net.Lg;

/**
 * Created by hexiaohong on 16/8/10.
 */
public class BytesReaderWriterDisk extends ReaderWriterDisk<byte[]> {

    @Override
    public byte[] get(File file) {
        try {
            return IoUtil.readAllBytesAndClose(new FileInputStream(file));
        } catch (Exception e) {
            Lg.w(e);
        }
        return null;
    }

    @Override
    public boolean put(OutputStream os, byte[] bytes) {
        try {
            os.write(bytes);
            os.flush();
            return true;
        } catch (Exception e) {
            Lg.w(e);
        } finally {
            IoUtil.safeClose(os);
        }
        return false;
    }
}
