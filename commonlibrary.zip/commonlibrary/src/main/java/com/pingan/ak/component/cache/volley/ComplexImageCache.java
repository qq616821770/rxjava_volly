package com.pingan.ak.component.cache.volley;

import android.graphics.Bitmap;
import android.text.TextUtils;

import com.android.volley.toolbox.ImageLoader.ImageCache;

public class ComplexImageCache implements ImageCache {

	private ImageCache mRAMImageCache;
	private ImageCache mDiskImageCache;
	private static final String URL_FLAG = "#W0#H0";

	public ComplexImageCache(int maxSize, String path) {
		mRAMImageCache = new BitmapLruImageCache(maxSize);
		mDiskImageCache = new DiskCache(path);
	}

	@Override
	public Bitmap getBitmap(String url) {
		if (TextUtils.isEmpty(url)) {
			return null;
		}
		
		url = url.replaceFirst(URL_FLAG, "");
		Bitmap bitmap = null;
		if (mRAMImageCache != null) {
			bitmap = mRAMImageCache.getBitmap(url);
		}
		if (bitmap == null && mDiskImageCache != null) {
			bitmap = mDiskImageCache.getBitmap(url);
			if (bitmap != null && mRAMImageCache != null) {
				mRAMImageCache.putBitmap(url, bitmap);
			}
		}
		return bitmap;
	}

	@Override
	public void putBitmap(String url, Bitmap bitmap) {
		if (TextUtils.isEmpty(url)) {
			return;
		}
		
		url = url.replaceFirst(URL_FLAG, "");
		if (mRAMImageCache != null) {
			mRAMImageCache.putBitmap(url, bitmap);
		}

		if (mDiskImageCache != null) {
			mDiskImageCache.putBitmap(url, bitmap);
		}
	}
}
