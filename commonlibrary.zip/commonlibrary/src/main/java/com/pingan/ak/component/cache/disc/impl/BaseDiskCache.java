package com.pingan.ak.component.cache.disc.impl;

import com.pingan.ak.component.cache.disc.DiskCache;
import com.pingan.ak.component.cache.disc.naming.FileNameGenerator;
import com.pingan.ak.component.cache.disc.naming.Md5FileNameGenerator;
import com.pingan.ak.component.cache.disc.rw.ReaderWriterDisk;

import java.io.File;
import java.io.FileOutputStream;

import cn.core.net.Lg;

/**
 * Created by hexiaohong on 16/8/10.
 */
public class BaseDiskCache implements DiskCache {

    private File cacheDir;
    private File reserveCacheDir;
    private FileNameGenerator fileNameGenerator;

    public BaseDiskCache(File cacheDir) {
        this(cacheDir, null);
    }

    public BaseDiskCache(File cacheDir, File reserveCacheDir) {
        this(cacheDir, reserveCacheDir, new Md5FileNameGenerator());
    }

    public BaseDiskCache(File cacheDir, File reserveCacheDir, FileNameGenerator fileNameGenerator) {
        if (cacheDir == null) {
            throw new IllegalArgumentException("cacheDir is null");
        }
        if (fileNameGenerator == null) {
            throw new IllegalArgumentException("fileNameGenerator is null");
        }

        this.cacheDir = cacheDir;
        this.reserveCacheDir = reserveCacheDir;
        this.fileNameGenerator = fileNameGenerator;
    }

    @Override
    public <T> boolean put(String key, T t, ReaderWriterDisk<T> rw) {
        File file = getFile(key);
        File tmpFile = new File(file.getAbsolutePath() + ".tmp");
        boolean loaded = false;
        try {
            try {
                loaded = rw.put(new FileOutputStream(tmpFile), t);
            } catch (Exception e) {
                Lg.w(e);
            }
        } finally {
            if (loaded && !tmpFile.renameTo(file)) {
                loaded = false;
            }
            if (!loaded) {
                tmpFile.delete();
            }
        }
        return loaded;
    }

    @Override
    public <T> T get(String key, ReaderWriterDisk<T> rw) {
        File file = getFile(key);
        if (file == null || !file.exists()) {
            return null;
        }
        return rw.get(file);
    }

    @Override
    public boolean remove(String key) {
        return getFile(key).delete();
    }

    @Override
    public void clear() {
        File[] files = cacheDir.listFiles();
        if (files != null) {
            for (File f : files) {
                f.delete();
            }
        }
    }

    protected File getFile(String key) {
        String fileName = fileNameGenerator.generate(key);
        File dir = cacheDir;
        if (!cacheDir.exists() && !cacheDir.mkdirs()) {
            if (reserveCacheDir != null && (reserveCacheDir.exists() || reserveCacheDir.mkdirs())) {
                dir = reserveCacheDir;
            }
        }
        return new File(dir, fileName);
    }
}
