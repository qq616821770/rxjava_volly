package com.pingan.ak.component.ui;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.res.ColorStateList;
import android.content.res.XmlResourceParser;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.pingan.commonlibrary.R;


/**
 * 通用对话框
 * 
 * @author EX-YANGZHIHONG001 E-mail:EX-YANGZHIHONG001@pingan.com.cn
 * @version 1.1.0
 */
public class SpecialDialog extends Dialog implements View.OnClickListener{

    private TextView messageView;
    private TextView titleView;
    private Button positiveButton;
    private Button negativeButton;
    private ImageView close;
    private View devider;
    private CheckBox rb_no_notify;
    private LinearLayout view_container;
    private OnClickListener clickListener;
    private RelativeLayout title_view;
    private Context context;
    public static final int TYPE_PWD = 1;
    public static final int TYPE_NORMAL = 2;

    public SpecialDialog(Context context) {
        super(context, R.style.ss_loading_dialog);
        this.context = context;
        initView(TYPE_NORMAL);
    }

    public SpecialDialog(Context context, int type) {
        super(context, R.style.ss_loading_soft_input_dialog);
        initView(type);
    }

    public void setNoTitle() {
        title_view.setVisibility(View.GONE);
    }

    private void initView(int type) {
        getWindow().requestFeature(Window.FEATURE_NO_TITLE);
        setCancelable(true);
        setCanceledOnTouchOutside(false);
        int layoutId = R.layout.ss_special_dialog;
        setContentView(layoutId);
        rb_no_notify=(CheckBox) findViewById(R.id.radiobutton_udpnotify);
        titleView = (TextView) findViewById(R.id.title);
        title_view = (RelativeLayout) findViewById(R.id.tl_title);
        messageView = (TextView) findViewById(R.id.message);
        positiveButton = (Button) findViewById(R.id.ok);
        positiveButton.setOnClickListener(this);
        negativeButton = (Button) findViewById(R.id.cancel);
        close = (ImageView) findViewById(R.id.close);
        negativeButton.setOnClickListener(this);
        view_container = (LinearLayout) findViewById(R.id.view_container);
        devider = findViewById(R.id.devider);
        close.setVisibility(View.VISIBLE);
        close.setOnClickListener(this);
    }

    public void setTitle(int resId) {
        titleView.setText(resId);
    }

    public void setMsgDrawable(int rid) {
        messageView.setCompoundDrawables(context.getResources().getDrawable(rid), null, null, null);
    }

    public void addContainerView(View view) {
        messageView.setVisibility(View.GONE);
        view_container.addView(view);
    }

    public void setTitle(CharSequence text) {
        titleView.setText(text);
    }


    public void showPositiveButton(boolean isShow) {
        if (isShow) {
            devider.setVisibility(View.VISIBLE);
            positiveButton.setVisibility(View.VISIBLE);
        } else {
            devider.setVisibility(View.GONE);
            positiveButton.setVisibility(View.GONE);
        }
    }

    public void showOneButton(boolean isShow) {
        negativeButton.setVisibility(View.GONE);
    }

    public void setPositiveButton(CharSequence text) {
        positiveButton.setText(text);
    }


    public void setPositiveButtonTextColor(Context context, int color) {
        XmlResourceParser xrp = context.getResources().getXml(color);
        try {
            ColorStateList csl = ColorStateList.createFromXml(context.getResources(), xrp);
            positiveButton.setTextColor(csl);
        } catch (Exception e) {  }
    }

    public void setPositiveButtonEnable(boolean isEnable) {
        positiveButton.setEnabled(isEnable);
    }

    public void showNegitiveButton(boolean isShow) {
        if (isShow) {
            devider.setVisibility(View.VISIBLE);
            negativeButton.setVisibility(View.VISIBLE);
        } else {
            devider.setVisibility(View.GONE);
            negativeButton.setVisibility(View.GONE);
        }
    }

    public void setNegativeButton(CharSequence text) {
        negativeButton.setText(text);
    }

    public void setNegativeButtonTextColor(Context context, int color) {

        XmlResourceParser xrp = context.getResources().getXml(color);
        try {
            ColorStateList csl = ColorStateList.createFromXml(context.getResources(), xrp);
            negativeButton.setTextColor(csl);
        } catch (Exception e) {  }
    }


    public void setMessage(int resId) {
        messageView.setText(resId);
    }

    public void setMessage(CharSequence text) {
        messageView.setText(text);
    }

    public void setCloseButtonInvisible() {
        close.setVisibility(View.INVISIBLE);
    }

    public void setPadding(int left, int top, int right, int bottom) {
        messageView.setPadding(left, top, right, bottom);
    }

    public void setMessageGravity(int gravity) {
        messageView.setGravity(gravity);
    }

    public void setRadioBtnVisibty(boolean visibty){
        if (rb_no_notify!=null){
            rb_no_notify.setVisibility(View.VISIBLE);
        }
    }

    public boolean getRadioBtnIsChecked(){
        boolean isChecked=false;
        if (rb_no_notify!=null){
            isChecked=rb_no_notify.isChecked();
        }
        return isChecked;
    }

    public void setOnClickListener(OnClickListener listener) {
        this.clickListener = listener;
    }

    @Override
    public void onClick(View v) {
        if (clickListener != null) {
            int which = DialogInterface.BUTTON_POSITIVE;

            if (v.getId()==R.id.ok){
                which= DialogInterface.BUTTON_POSITIVE;
            }if(v.getId()==R.id.cancel){
                which= DialogInterface.BUTTON_NEGATIVE;
            }if(v.getId()==R.id.close){
                which= DialogInterface.BUTTON_NEGATIVE;
            }
            clickListener.onClick(this, which);
        }
        dismiss();
    }

}