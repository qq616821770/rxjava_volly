package com.pingan.ak.component.cache.any;

import android.content.Context;

import com.pingan.ak.component.cache.StorageUtils;
import com.pingan.ak.component.cache.disc.DiskCache;
import com.pingan.ak.component.cache.disc.impl.BaseDiskCache;
import com.pingan.ak.component.cache.disc.naming.BaseFileNameGenerator;
import com.pingan.ak.component.cache.memory.MemoryCache;
import com.pingan.ak.component.cache.memory.impl.WeakMemoryCache;

import java.io.File;
import java.io.IOException;

/**
 * Fix Cache.
 * <p/>
 * Disk Cache storage on /sdcard/Android/data/com.x.y.z/cache OR /data/data/com.x.y.z/cache.
 * <p/>
 * Created by hexiaohong on 16/8/10.
 */
public class FixCache extends BaseCache {

    @Override
    protected MemoryCache createMemoryCache() {
        return new WeakMemoryCache();
    }

    @Override
    protected DiskCache createDiskCache(Context context, String column) throws IOException {
        if (column == null) column = "";
        File rootDir = StorageUtils.getCacheDirectory(context);
        File cacheDir = new File(rootDir.getAbsolutePath() + column);
        return new BaseDiskCache(cacheDir, null, new BaseFileNameGenerator());
    }
}
