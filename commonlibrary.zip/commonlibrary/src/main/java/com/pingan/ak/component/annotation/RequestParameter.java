package com.pingan.ak.component.annotation;

import android.support.annotation.Keep;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Created by yueang on 16/8/29.
 */
@Keep
@Target(ElementType.FIELD)
@Retention(RetentionPolicy.RUNTIME)
public @interface RequestParameter {
    @Keep enum METHOD {POST, GET}

    @Keep METHOD method() default METHOD.POST;
    @Keep String name() default "";
}
