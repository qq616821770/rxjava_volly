package com.pingan.ak.component.cache.disc.naming;

import com.pingan.ak.util.MD5;

/**
 * Created by hexiaohong on 16/8/10.
 */
public class Md5FileNameGenerator implements FileNameGenerator {

    @Override
    public String generate(String key) {
        return MD5.hexDigest(key);
    }
}
