package com.pingan.ak.framework.app;

import android.os.Bundle;
import android.support.v4.app.Fragment;

import com.pingan.ak.component.bus.RxBus;

import cn.core.net.Lg;
import rx.Subscription;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.subscriptions.CompositeSubscription;

/**
 * Created by hexiaohong on 16/8/1.
 */
public class BaseRxFragment extends Fragment {

    private CompositeSubscription compositeSubscription;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        compositeSubscription = new CompositeSubscription();

        registerRxBus();
    }

    @Override
    public void onDestroy() {
        unsubscribeAll();
        super.onDestroy();
    }

    protected void subscribe(Subscription subscription) {
        if (subscription != null) {
            if (compositeSubscription != null) {
                compositeSubscription.add(subscription);
            }
        }
    }

    protected void unsubscribeAll() {
        if (compositeSubscription != null) {
            compositeSubscription.unsubscribe();
            compositeSubscription = null;
        }
    }

    private void registerRxBus() {
        Class<?>[] cs = focusRxBus();
        if (cs != null) {
            if (cs.length == 0) {
                registerRxBusWithAll();
            } else {
                for (Class<?> c : cs) {
                    registerRxBusWithClass(c);
                }
            }
        }
    }

    private void registerRxBusWithAll() {
        subscribe(RxBus.getInstance()
                .toObservable()
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Action1<Object>() {
                    @Override
                    public void call(Object event) {
                        try {
                            onRxBus(event);
                        } catch (Exception e) {
                            Lg.w(e);
                        }
                    }
                }, new Action1<Throwable>() {
                    @Override
                    public void call(Throwable t) {
                        Lg.w(t);
                        registerRxBusWithAll();
                    }
                }));
    }

    private void registerRxBusWithClass(final Class<?> cls) {
        subscribe(RxBus.getInstance()
                .toObservable(cls)
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Action1<Object>() {
                    @Override
                    public void call(Object event) {
                        try {
                            onRxBus(event);
                        } catch (Exception e) {
                            Lg.w(e);
                        }
                    }
                }, new Action1<Throwable>() {
                    @Override
                    public void call(Throwable t) {
                        Lg.w(t);
                        registerRxBusWithClass(cls);
                    }
                }));
    }

    protected Class<?>[] focusRxBus() {
        return null;
    }

    protected void onRxBus(Object event) {

    }

    protected void sendRxEvent(Object event) {
        if (RxBus.getInstance().hasObservers()) {
            RxBus.getInstance().send(event);
        }
    }
}
