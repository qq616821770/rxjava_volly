package com.pingan.ak.component.cache.disc.impl.lru;

import com.pingan.ak.component.cache.disc.DiskCache;
import com.pingan.ak.component.cache.disc.naming.FileNameGenerator;
import com.pingan.ak.component.cache.disc.rw.ReaderWriterDisk;

import java.io.File;
import java.io.IOException;

import cn.core.net.Lg;

/**
 * Created by hexiaohong on 16/8/10.
 */
public class LruDiskCache implements DiskCache {

    private static final String ERROR_ARG_NULL = " argument must be not null";
    private static final String ERROR_ARG_NEGATIVE = " argument must be positive number";

    protected DiskLruCache cache;
    private File reserveCacheDir;
    private FileNameGenerator fileNameGenerator;

    public LruDiskCache(File cacheDir, File reserveCacheDir,
                        FileNameGenerator fileNameGenerator,
                        long cacheMaxSize,
                        int cacheMaxFileCount) throws IOException {
        if (cacheDir == null) {
            throw new IllegalArgumentException("cacheDir" + ERROR_ARG_NULL);
        }
        if (cacheMaxSize < 0) {
            throw new IllegalArgumentException("cacheMaxSize"
                    + ERROR_ARG_NEGATIVE);
        }
        if (cacheMaxFileCount < 0) {
            throw new IllegalArgumentException("cacheMaxFileCount"
                    + ERROR_ARG_NEGATIVE);
        }
        if (fileNameGenerator == null) {
            throw new IllegalArgumentException("fileNameGenerator"
                    + ERROR_ARG_NULL);
        }

        if (cacheMaxSize == 0) {
            cacheMaxSize = Long.MAX_VALUE;
        }
        if (cacheMaxFileCount == 0) {
            cacheMaxFileCount = Integer.MAX_VALUE;
        }

        this.reserveCacheDir = reserveCacheDir;
        this.fileNameGenerator = fileNameGenerator;
        initCache(cacheDir, reserveCacheDir, cacheMaxSize, cacheMaxFileCount);
    }

    private void initCache(File cacheDir, File reserveCacheDir, long cacheMaxSize, int cacheMaxFileCount) throws IOException {
        try {
            cache = DiskLruCache.open(cacheDir, 1, 1, cacheMaxSize, cacheMaxFileCount);
        } catch (IOException e) {
            if (reserveCacheDir != null) {
                initCache(reserveCacheDir, null, cacheMaxSize, cacheMaxFileCount);
            }
            if (cache == null) {
                throw e;
            }
        }
    }

    protected File getFile(String key) {
        DiskLruCache.Snapshot snapshot = null;
        try {
            snapshot = cache.get(getKey(key));
            return snapshot == null ? null : snapshot.getFile(0);
        } catch (IOException e) {
            return null;
        } finally {
            if (snapshot != null) {
                snapshot.close();
            }
        }
    }

    @Override
    public <V> V get(String key, ReaderWriterDisk<V> readFromDisk) {
        File file = getFile(key);
        if (file == null || !file.exists()) {
            return null;
        }
        return readFromDisk.get(file);
    }

    @Override
    public <V> boolean put(String key, V value, ReaderWriterDisk<V> writeIn) {
        boolean savedSuccessfully = false;
        try {
            DiskLruCache.Editor editor = cache.edit(getKey(key));
            if (editor == null) {
                return false;
            }
            if (writeIn != null) {
                savedSuccessfully = writeIn.put(editor.newOutputStream(0), value);
            }
            if (savedSuccessfully) {
                editor.commit();
            } else {
                editor.abort();
            }
        } catch (Exception e) {
            Lg.w(e);
        }
        return savedSuccessfully;
    }

    @Override
    public boolean remove(String key) {
        try {
            return cache.remove(getKey(key));
        } catch (IOException e) {
            return false;
        }
    }

    @Override
    public void clear() {
        try {
            cache.delete();
        } catch (IOException e) {

        }
        try {
            initCache(cache.getDirectory(), reserveCacheDir, cache.getMaxSize(), cache.getMaxFileCount());
        } catch (IOException e) {

        }
    }

    private String getKey(String key) {
        return fileNameGenerator.generate(key);
    }

}
