package com.pingan.ak.util;

import android.text.TextUtils;

import java.math.BigDecimal;
import java.security.SecureRandom;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

public class StringUtil {

    public static boolean isEmpty(String str) {
        return str == null || str.trim().equals("");
    }

    public static int length(CharSequence str) {
        return str == null ? 0 : str.length();
    }

    public static String dateSimpleJoin(String... array) {
        if (array == null) {
            return "";
        }
        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < array.length; i++) {
            builder.append(i == 2 ? "-" : array[i]);
        }
        return builder.toString();
    }
    /**
     * 对象转化为Double类型
     *
     * @param value
     * @param defaultValue
     * @return Double
     */
    public final static double convertToDouble(Object value, double defaultValue) {
        if (value == null || "".equals(value.toString().trim())) {
            return defaultValue;
        }
        try {
            return Double.valueOf(value.toString());
        } catch (NumberFormatException e) {
            return defaultValue;
        }
    }


    /**
     * 格式还原
     *
     * @param str
     * @return
     */
    public static String reductionNumber(String str) {
        if (TextUtils.isEmpty(str)) {
            return str;
        }
        StringBuffer sb = new StringBuffer();
        String[] strings = str.split(" ");
        for (int i = 0; i < strings.length; i++) {
            sb.append(strings[i]);
        }
        return sb.toString();
    }

    /**
     * 是否为数字
     *
     * @param obj
     * @return
     */
    public static boolean isNumeric(Object obj) {
        if (obj == null) {
            return false;
        }
        String str = obj.toString();
        int sz = str.length();
        for (int i = 0; i < sz; i++) {
            if (!Character.isDigit(str.charAt(i))) {
                return false;
            }
        }
        return true;
    }

    /**
     * 手机号简单正则
     * @param mobiles
     * @return
     */
    public static boolean isMobileNO(String mobiles) {
        Pattern p = Pattern.compile("^1[34578]\\d{9}$");
        Matcher m = p.matcher(mobiles);
        return m.matches();
    }

    public static boolean isEqual(String a, String b) {
        if (a == null) {
            return a == b;
        } else {
            return a.equals(b);
        }
    }

    /**
     * 如果两个Ssid去掉双引号后相等的话,则返回 true
     *
     * @return
     */
    public static boolean convertToEquals(String param1, String param2) {
        return param1.replaceAll("\"", "").equals(param2.replaceAll("\"", ""));
    }

    public static String replaceAll(String ssid) {
        return ssid.trim().replaceAll("\"", "");
    }

    public static boolean isEmpty(Object str) {
        return str == null || str.equals("");
    }

    public static int nextInt(final int min, final int max) {
        SecureRandom rand = new SecureRandom();
        int tmp = Math.abs(rand.nextInt());
        return tmp % (max - min + 1) + min;
    }

    /**
     * 过滤特殊字符
     *
     * @param str
     * @return
     * @throws PatternSyntaxException
     */
    public static String doFilter(String str) throws PatternSyntaxException {
        if (!isEmpty(str)) {
            // 清除掉部分特殊字符
            String regEx = "[`~!@#$%^&*()+=|':;',.<>/?~！@#￥%……&*——‘；：”“’。，、？]";
            Pattern pattern = Pattern.compile(regEx);
            Matcher matcher = pattern.matcher(str);
            str = matcher.replaceAll(" ").trim();
        }
        return str;
    }


    public static String filterEmpty(String str) {
        return str == null ? "" : str;
    }


//    /**
//     * 格式化字符串
//     * @param str
//     * @param dotNum 小数点（0-2）位
//     * @return
//     */
//    public static String stringFormat(String str, int dotNum) {
//        DecimalFormat df = (DecimalFormat) NumberFormat.getInstance();
//        String result = "";
//        switch (dotNum) {
//            case 1:
//                if(!TextUtils.isEmpty(str)) {
//                    df.applyPattern("0.0");
//                    result = df.format(Float.parseFloat(str));
//                } else {
//                    result = "0.0";
//                }
//                break;
//            case 2:
//                if(!TextUtils.isEmpty(str)) {
//                    df.applyPattern("0.00");
//                    result = df.format(Float.parseFloat(str));
//                } else {
//                    result = "0.00";
//                }
//                break;
//            default:
//                if(!TextUtils.isEmpty(str)) {
//                    df.applyPattern("0");
//                    result = df.format(Float.parseFloat(str));
//                } else {
//                    result = "0";
//                }
//                break;
//        }
//        return result;
//    }

    /**
     * 格式化显示剩余流量数据
     *
     * @param value
     * @return
     */
    public static String[] formatFlowValue(float value) {
        String[] values = new String[2];
        if(value == 0) {
            values[0] = "0";
            values[1] = "MB";
        } else if(value < 1024) {
            values[0] = StringUtil.stringFormat(value + "", 1);
            values[1] = "MB";
        } else {
            values[0] = StringUtil.stringFormat(value / 1024.0f + "", 2);
            values[1] = "GB";
        }
        return values;
    }

    /**
     * 向下保留小数点后几位
     *
     * @param value  数字
     * @param dotNum 保留几位
     * @return
     */
    public static String stringFormat(String value, int dotNum) {
        if(TextUtils.isEmpty(value)) {
            value = "0";
        }
        BigDecimal bd = new BigDecimal(value);
        BigDecimal strOut = bd.setScale(dotNum, BigDecimal.ROUND_DOWN);
        return strOut.toString();
    }

}
