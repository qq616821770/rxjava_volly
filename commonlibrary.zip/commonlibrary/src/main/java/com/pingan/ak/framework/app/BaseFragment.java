package com.pingan.ak.framework.app;

import android.app.Activity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import cn.core.net.Lg;

public class BaseFragment extends BaseRxFragment{

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        Lg.d(this + " onAttach");
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Lg.d(this + " onCreate");
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        Lg.d(this + " onCreateView");
        return super.onCreateView(inflater, container, savedInstanceState);
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        Lg.d(this + " onActivityCreated has savedInstanceState " + (savedInstanceState != null));
    }

    @Override
    public void onStart() {
        super.onStart();
        Lg.d(this + " onStart");
    }

    @Override
    public void onResume() {
        super.onResume();
        Lg.d(this + " onResume");
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        Lg.d(this + " onSaveInstanceState");
    }

    @Override
    public void onHiddenChanged(boolean hidden) {
        super.onHiddenChanged(hidden);
        Lg.d(this + " onHiddenChanged " + hidden);
    }

    @Override
    public void onPause() {
        super.onPause();
        Lg.d(this + " onPause");
    }

    @Override
    public void onStop() {
        super.onStop();
        Lg.d(this + " onStop");
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        Lg.d(this + " onDestroyView");
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Lg.d(this + " onDestroy");
    }

    @Override
    public void onDetach() {
        super.onDetach();
        Lg.d(this + " onDetach");
    }
}  