package com.pingan.ak.component.trans;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.atomic.AtomicInteger;

import cn.core.net.Lg;

/**
 * Created by hexiaohong on 16/8/22.
 */
abstract class TransTask {

    public AtomicInteger retryTimes = new AtomicInteger(3);

    public TransNode transNode;

    public TransCallback transCallback;

    public abstract boolean checkTask();

    public abstract void runTask();

    public abstract void hangupTask();

    public abstract void pauseTask();

    public abstract void cancelTask();

    public boolean retryTask() {
        if (this.retryTimes.getAndDecrement() > 0) {
            Timer timer = new Timer();
            timer.schedule(new TimerTask() {
                public void run() {
                    if (transNode.transStatus == TransNode.TransStatus.Running) {
                        runTask();
                    }
                }
            }, 2000L);

            return true;
        }
        this.retryTimes.set(3);
        return false;
    }

    protected static boolean copyStream(InputStream is, OutputStream os, CopyListener listener, int bufferSize) throws IOException {
        try {
            int current = 0;
            final byte[] bytes = new byte[bufferSize];
            int count;
            if (isInterrupted(listener)) return false;
            while ((count = is.read(bytes, 0, bufferSize)) != -1) {
                os.write(bytes, 0, count);
                current += count;
                if (isInterrupted(listener)) return false;
            }
            os.flush();
            return true;
        } finally {
            try {
                if (is != null) {
                    is.close();
                }
            } catch (Exception e) {
                Lg.w(e);
            }
            try {
                if (os != null) {
                    os.close();
                }
            } catch (Exception e) {
                Lg.w(e);
            }
        }
    }

    private static boolean isInterrupted(CopyListener listener) {
        if (listener != null) {
            return listener.isInterrupted();
        }
        return false;
    }

    protected interface CopyListener {
        boolean isInterrupted();
    }
}
