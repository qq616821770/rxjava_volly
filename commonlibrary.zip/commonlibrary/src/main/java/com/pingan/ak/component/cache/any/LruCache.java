package com.pingan.ak.component.cache.any;

import android.content.Context;

import com.pingan.ak.component.cache.StorageUtils;
import com.pingan.ak.component.cache.disc.DiskCache;
import com.pingan.ak.component.cache.disc.impl.lru.LruDiskCache;
import com.pingan.ak.component.cache.disc.naming.Md5FileNameGenerator;
import com.pingan.ak.component.cache.memory.MemoryCache;
import com.pingan.ak.component.cache.memory.impl.LruMemoryCache;

import java.io.File;
import java.io.IOException;

/**
 * Lru Cache.
 * <p/>
 * Disk Cache storage on /sdcard/Android/data/com.x.y.z/cache OR /data/data/com.x.y.z/cache.
 * <p/>
 * Created by hexiaohong on 16/8/10.
 */
public class LruCache extends BaseCache {

    protected MemoryCache createMemoryCache() {
        return new LruMemoryCache(10 * 1024 * 1024);
    }

    protected DiskCache createDiskCache(Context context, String column) throws IOException {
        if (column == null) column = "";
        File rootDir = StorageUtils.getCacheDirectory(context);
        File cacheDir = new File(rootDir.getAbsolutePath() + column);
        return new LruDiskCache(cacheDir, null, new Md5FileNameGenerator(), 10 * 1024 * 1024, 200);
    }
}
