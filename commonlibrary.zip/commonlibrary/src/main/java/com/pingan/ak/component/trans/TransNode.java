package com.pingan.ak.component.trans;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by hexiaohong on 16/8/22.
 */
public class TransNode {

    private static final String DefaultMime = "application/octet-stream";
    private static final TransType DefaultTransType = TransType.Download;
    private static final TransNetwork DefaultTransNetwork = TransNetwork.Any;
    private static final int DefaultBufferSize = 32 * 1024;

    public enum TransType {
        Upload, Download;
    }

    public enum TransStatus {
        Waiting, Running, Pending, Paused, Succeed, Canceled, Failed;
    }

    public enum TransNetwork {
        Any, OnlyWifi;
    }

    String id;
    public String url;
    public String localPath;
    public String mime = DefaultMime;

    public Map<String, String> headers = new HashMap<String, String>();

    public TransType transType = DefaultTransType;
    public TransNetwork transNetwork = DefaultTransNetwork;
    public boolean supportBreakpoint = false;
    public int bufferSize = DefaultBufferSize;

    long totalSize;
    long completeSize;

    TransStatus transStatus = TransStatus.Waiting;

    public String getId() {
        return id;
    }

    public long getTotalSize() {
        return totalSize;
    }

    public long getCompleteSize() {
        return completeSize;
    }

    public TransStatus getTransStatus() {
        return transStatus;
    }

    public static class Builder {

        String url;
        String localPath;
        String mime = DefaultMime;

        Map<String, String> headers = new HashMap<String, String>();

        TransType transType = DefaultTransType;
        TransNetwork transNetwork = DefaultTransNetwork;
        boolean supportBreakpoint;
        int bufferSize = DefaultBufferSize;

        public Builder url(String url) {
            this.url = url;
            return this;
        }

        public Builder local(String localPath) {
            this.localPath = localPath;
            return this;
        }

        public Builder mime(String mime) {
            this.mime = mime;
            return this;
        }

        public Builder header(String name, String value) {
            headers.put(name, value);
            return this;
        }

        public Builder download() {
            this.transType = TransType.Download;
            return this;
        }

        public Builder upload() {
            this.transType = TransType.Upload;
            return this;
        }

        public Builder onlyWifi() {
            this.transNetwork = TransNetwork.OnlyWifi;
            return this;
        }

        public Builder supportBreakpoint() {
            this.supportBreakpoint = true;
            return this;
        }

        public Builder bufferSize(int bufferSize) {
            this.bufferSize = bufferSize;
            return this;
        }

        public TransNode build() {
            TransNode node = new TransNode();

            node.url = this.url;
            node.localPath = this.localPath;
            node.headers.putAll(this.headers);
            node.transType = this.transType;
            node.transNetwork = this.transNetwork;
            node.supportBreakpoint = this.supportBreakpoint;
            node.bufferSize = this.bufferSize;

            return node;
        }
    }
}
