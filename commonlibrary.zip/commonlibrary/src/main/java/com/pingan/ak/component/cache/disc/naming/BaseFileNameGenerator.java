package com.pingan.ak.component.cache.disc.naming;

/**
 * Created by hexiaohong on 16/8/10.
 */
public class BaseFileNameGenerator implements FileNameGenerator {

    @Override
    public String generate(String key) {
        return key;
    }
}
