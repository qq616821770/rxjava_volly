package com.pingan.ak.component.cache;


import com.pingan.ak.util.MD5;

public class FileCache {
    public static final String TAG = "FileCache";

    public enum CacheType {
        NO_EXPIRED(""), DEFAULT(".cache"), IMAGE_COVER(".image_cover"), IMAGE_USER(".image_user"), FIND_LIST(
                ".find_list"), FIND_DETAIL_LIST(".find_detail_list"), CACHE_RESULT(".result_cache"), GIF(".gif");

        public final String extension;

        private CacheType(String extension) {
            this.extension = extension;
        }

    }

    public enum CacheTime {
        DEFAULT_WIFI(60), DEFAULT_MOBILE(6 * 60), NO_EXPIRED_ALL(365 * 24 * 60);
        public final long value;
        public static final int MINUE = 1000 * 60;

        private CacheTime(long s) {
            this.value = s * MINUE;
        }
    }

    public static String decodeKey(String url) {
        if (url != null) {
            return MD5.hexDigest(url);
        }
        return null;
    }

}
