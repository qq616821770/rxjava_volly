package com.pingan.ak.component.cache.disc.rw;

import java.io.File;
import java.io.OutputStream;

/**
 * Created by hexiaohong on 16/8/10.
 */
public abstract class ReaderWriterDisk<T> {

    public abstract T get(File file);

    public abstract boolean put(OutputStream os, T t);
}
