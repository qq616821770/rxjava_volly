package com.pingan.ak.component.net.http;

public interface IRequestCallBack<T> {

    void onResponse(BaseStatus status, T response);
}
