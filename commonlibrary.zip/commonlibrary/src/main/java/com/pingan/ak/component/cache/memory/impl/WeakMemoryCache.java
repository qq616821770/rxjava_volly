package com.pingan.ak.component.cache.memory.impl;

import com.pingan.ak.component.cache.memory.MemoryCache;

import java.lang.ref.Reference;
import java.lang.ref.WeakReference;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import cn.core.net.Lg;

/**
 * Created by hexiaohong on 16/9/9.
 */
public class WeakMemoryCache implements MemoryCache {

    private Map<String, Reference<Object>> referenceMap;

    public WeakMemoryCache() {
        referenceMap = Collections.synchronizedMap(new HashMap<String, Reference<Object>>());
    }

    @Override
    public <T> boolean put(String key, T t) {
        if (referenceMap != null) {
            referenceMap.put(key, new WeakReference<Object>(t));
            return true;
        }
        return false;
    }

    @Override
    public <T> T get(String key) {
        if (key == null) {
            throw new NullPointerException("key == null");
        }
        if (referenceMap != null) {
            T value = null;
            try {
                Reference<Object> reference = referenceMap.get(key);
                if (reference != null) {
                    value = (T) reference.get();
                }
            } catch (Exception e) {
                Lg.w(e);
            }
            return value;
        }
        return null;
    }

    @Override
    public boolean remove(String key) {
        if (referenceMap != null && referenceMap.remove(key) != null) {
            return true;
        }
        return false;
    }

    @Override
    public void clear() {
        if (referenceMap != null) {
            referenceMap.clear();
        }
    }
}
