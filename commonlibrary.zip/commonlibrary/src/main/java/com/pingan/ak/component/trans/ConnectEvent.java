package com.pingan.ak.component.trans;

/**
 * Created by hexiaohong on 16/8/3.
 */
public class ConnectEvent {

    public boolean isWifiConnected;

    public boolean isMobileConnected;

    public ConnectEvent(boolean isWifiConnected, boolean isMobileConnected) {
        this.isWifiConnected = isWifiConnected;
        this.isMobileConnected = isMobileConnected;
    }
}
