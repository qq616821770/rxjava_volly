package com.pingan.ak.component.cache.disc.rw;

import com.pingan.ak.util.IoUtil;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;

import cn.core.net.Lg;

/**
 * Created by hexiaohong on 16/8/10.
 */
public class StringReaderWriterDisk extends ReaderWriterDisk<String> {

    @Override
    public String get(File file) {
        try {
            return IoUtil.readAllCharsAndClose(
                    new BufferedReader(
                            new InputStreamReader(
                                    new FileInputStream(file), "utf-8")));
        } catch (Exception e) {
            Lg.w(e);
        }
        return null;
    }

    @Override
    public boolean put(OutputStream os, String s) {
        try {
            IoUtil.writeAllCharsAndClose(new OutputStreamWriter(os, "utf-8"), s);
            return true;
        } catch (Exception e) {
            Lg.w(e);
        }
        return false;
    }
}
