package com.pingan.ak.component.preference;

import android.content.Context;
import android.content.SharedPreferences;
import android.text.TextUtils;


import com.pingan.pingandata.secure.WiFiSecure;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Map;

/**
 * Base Preferences.
 * <p/>
 * Created by hexiaohong on 16/8/5.
 *
 * 此类的所有非抽象子类必须在应用启动时调用initialize方法初始化
 */
public abstract class BasePreferences {
    private Context context;
    private SharedPreferences sharedPreferences;

    protected abstract String getName();

    /**
     * 所有子类必须在应用启动时调用此方法初始化，此方法仅仅保存context，禁止做其他操作
     * @param context
     */
    public final void initialize(Context context) {
        this.context = context.getApplicationContext();
    }

    private SharedPreferences getPreferences() {
        if (sharedPreferences == null) {
            sharedPreferences = context.getSharedPreferences(getName(), Context.MODE_PRIVATE);
        }
        return sharedPreferences;
    }

    protected void put(SharedPreferences.Editor editor, String key, Object value) {
        if (value == null) {
            editor.putString(key, null);
        } else if (value instanceof String) {
            editor.putString(key, (String) value);
        } else if (value instanceof Integer) {
            editor.putInt(key, (Integer) value);
        } else if (value instanceof Boolean) {
            editor.putBoolean(key, (Boolean) value);
        } else if (value instanceof Float) {
            editor.putFloat(key, (Float) value);
        } else if (value instanceof Long) {
            editor.putLong(key, (Long) value);
        } else {
            editor.putString(key, value.toString());
        }
    }

    public SharedPreferences getSP(String fileName) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(fileName, Context.MODE_PRIVATE);
        return sharedPreferences;
    }

    public String get(String file, String key, String defaultValue) {
        return getSP(file).getString(key, defaultValue);
    }

    public void put(String file, String key, Object value) {
        SharedPreferences.Editor editor = getSP(file).edit();
        put(editor, key, value);
        BasePreferences.SharedPreferencesCompat.apply(editor);
    }



    public void put(String key, Object value) {
        SharedPreferences.Editor editor = getPreferences().edit();
        put(editor, key, value);
        SharedPreferencesCompat.apply(editor);
    }

    public void put(Map<String, Object> map) {
        if (null != map && !map.isEmpty()) {
            SharedPreferences.Editor editor = getPreferences().edit();
            for (Map.Entry<String, Object> entry : map.entrySet()) {
                //Log.d("put", "Key = " + entry.getKey() + ", Value = " + entry.getValue());
                if (null == entry.getKey()) {
                    continue;
                }
                put(editor, entry.getKey(), entry.getValue());
            }
            SharedPreferencesCompat.apply(editor);
        }
    }

    public void put(String key, Object value, Object... moreKeyOrValue) {
        SharedPreferences.Editor editor = getPreferences().edit();
        put(editor, key, value);

        boolean isKey = true;
        String moreKey = null;
        Object moreValue = null;
        for (Object keyOrValue : moreKeyOrValue) {
            if (isKey) {
                if (keyOrValue instanceof String) {
                    moreKey = (String) keyOrValue;
                    isKey = false;
                } else {
                    break;
                }
            } else {
                moreValue = keyOrValue;
                isKey = true;
                put(editor, moreKey, moreValue);
            }
        }

        SharedPreferencesCompat.apply(editor);
    }

    public String get(String key, String defaultValue) {
        return getPreferences().getString(key, defaultValue);
    }

    public int get(String key, int defaultValue) {
        return getPreferences().getInt(key, defaultValue);
    }

    public boolean get(String key, boolean defaultValue) {
        return getPreferences().getBoolean(key, defaultValue);
    }

    public float get(String key, float defaultValue) {
        return getPreferences().getFloat(key, defaultValue);
    }

    public long get(String key, long defaultValue) {
        return getPreferences().getLong(key, defaultValue);
    }

    /**
     * 存储加密数据，目前仅支持String类型
     * @param key
     * @param value
     */
    public void putIntoEncrypt(String key, String value) {
        String encrypted = WiFiSecure.getInstance().des3Encode(WiFiSecure.Des3KeyType.APP_CACHE, value);
        put(key, encrypted);
    }

    /**
     * 获取加密的数据，解密后返回
     * @param key
     * @return
     */
    public String getFromEncrypt(String key, String defaultValue) {
        String encrypted = get(key, "");
        if (TextUtils.isEmpty(encrypted)) {
            return defaultValue;
        }

        String value = WiFiSecure.getInstance().des3Decode(WiFiSecure.Des3KeyType.APP_CACHE, encrypted);
        if (TextUtils.isEmpty(value)) {
            return defaultValue;
        }

        return value;
    }

    public void remove(String key) {
        SharedPreferences.Editor editor = getPreferences().edit();
        editor.remove(key);
        SharedPreferencesCompat.apply(editor);
    }

    public void clear() {
        sharedPreferences = context.getSharedPreferences(getName(), Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.clear();
        SharedPreferencesCompat.apply(editor);
    }

    public boolean contains(String key) {
        return getPreferences().contains(key);
    }

    public Map<String, ?> getAll() {
        return getPreferences().getAll();
    }

    private static class SharedPreferencesCompat {
        private static final Method applyMethod = findApplyMethod();

        private static Method findApplyMethod() {
            try {
                Class<?> clazz = SharedPreferences.Editor.class;
                return clazz.getMethod("apply");
            } catch (NoSuchMethodException ignored) {
            }
            return null;
        }

        public static void apply(SharedPreferences.Editor editor) {
            try {
                if (applyMethod != null) {
                    applyMethod.invoke(editor);
                    return;
                }
            } catch (IllegalArgumentException
                    | IllegalAccessException
                    | InvocationTargetException ignored) {
            }
            editor.commit();
        }
    }
}
