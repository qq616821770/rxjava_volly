package com.pingan.ak.component.trans;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

import com.pingan.ak.component.bus.RxBus;

import java.util.concurrent.TimeUnit;

import cn.core.net.Lg;
import rx.android.schedulers.AndroidSchedulers;
import rx.functions.Action1;
import rx.subjects.PublishSubject;

/**
 * Created by hexiaohong on 16/8/5.
 */
public class ConnectReceiver extends BroadcastReceiver {

    private static PublishSubject<Object> subject;

    public ConnectReceiver() {
        if (subject == null) {
            subject = PublishSubject.create();

            // 网络切换，可能会收到多个广播消息
            // 利用throttleWithTimeout机制，仅发出该时间段内最新的事件
            subject.throttleWithTimeout(1500, TimeUnit.MILLISECONDS)
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(new Action1<Object>() {
                        @Override
                        public void call(Object event) {
                            RxBus.getInstance().send(event);
                        }
                    });
        }
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        try {
            String action = intent.getAction();
            if (action.equals(ConnectivityManager.CONNECTIVITY_ACTION)) {
                ConnectivityManager manager = (ConnectivityManager)
                        context.getSystemService(Context.CONNECTIVITY_SERVICE);

                final NetworkInfo mobileInfo = manager
                        .getNetworkInfo(ConnectivityManager.TYPE_MOBILE);

                final NetworkInfo wifiInfo = manager
                        .getNetworkInfo(ConnectivityManager.TYPE_WIFI);

                subject.onNext(new ConnectEvent(
                        wifiInfo.isConnected(), mobileInfo.isConnected()));

//                Log.d("ConnReceiver", "wifi:" + wifiInfo.isConnected()
//                        + ", mobile:" + mobileInfo.isConnected());
            }
        } catch (Exception e) {
            Lg.w(e);
        }
    }
}
