package com.pingan.pinganwifi.data;

public class DataAction {

    private int actionId;
    private int processId;
    private int level = 0;
    private String actionInfo;

    public int getActionId() {
        return actionId;
    }

    public void setActionId(int actionId) {
        this.actionId = actionId;
    }

    public int getProcessId() {
        return processId;
    }

    public void setProcessId(int processId) {
        this.processId = processId;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public String getActionInfo() {
        return actionInfo;
    }

    public void setActionInfo(String actionInfo) {
        this.actionInfo = actionInfo;
    }

    @Override
    public String toString() {
        return "DataAction [actionId=" + actionId + ", processId=" + processId + ", level=" + level + ", actionInfo="
                + actionInfo + ", ]";
    }

}
