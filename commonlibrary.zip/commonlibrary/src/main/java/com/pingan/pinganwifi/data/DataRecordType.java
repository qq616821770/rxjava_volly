package com.pingan.pinganwifi.data;

public class DataRecordType {

    public static String LABEL_OK = "OK";

    public static String LABEL_SUCCESS = "SUCCESS";

    public static String LABEL_FAILED = "FAIL";

    /**
     * logger upload level <dd>top upload in real time</dd>
     */
    public static int levelTop = 1;
    /**
     * logger upload level <dd>mid upload delay 15 minutes in wifi</dd>
     */
    public static int levelMid = 0;
    /**
     * logger upload level <dd>low upload delay 15 minutes in wifi</dd>
     */
    public static int levelLow = -1;

    public enum datatype {
        APP, REGISTER, WIFI, MORE, SELF, NEARBY, ACTION
    }

    /**
     * define enum for action
     */
    public enum Actions {

        /**
         * 发送push
         */
        SEND_LOCAL_PUSH(10001, 1, levelTop),
        /**
         * 停止push，相当于已经注册了
         */
        STOP_LOCAL_PUSH(10001, 2, levelTop),
        /**
         * 点击push
         */
        CLICK_LOCAL_PUSH(10001, 3, levelTop),
        /**
         * 触发本地消息推送
         */
        TRIGGER_NOTIFY_PUSH(10001, 8, levelTop),
        /**
         * 点击本地消息推送
         */
        CLICK_NOTIFY_PUSH(10001, 9, levelTop),
        /**
         * wifi列表为空
         */
        WIFI_LIST_EMPTY(10001, 10, levelMid),

        /**
         * 安全SDK埋点，登录成功
         */
        SAFE_LOGIN_SUCCESS(10001, 15, levelMid),

        /**
         * 安全SDK埋点，注册成功
         */
        SAFE_REGISTER_SUCCESS(10001, 16, levelMid),

        /**
         * 浮动通知-点击立即去连接
         */
        FLOAT_NOTICE_BTN_CLICK_CONNECT(10001, 23, levelMid),

        /**
         * 浮动通知-立即体检
         */
        FLOAT_NOTICE_BTN_CLICK_SECURITY(10001, 24, levelMid),

        /**
         * 浮动通知-测速
         */
        FLOAT_NOTICE_BTN_CLICK_SPEED_TEST(10001, 25, levelMid),



        /**
         * 点击应用推荐
         */
        APP_RECOMMEND(20000, 1, levelTop),

        /**
         * 点击进入连接主页
         */
        CLICK_MAIN_TAB(20000, 0, levelTop),

        /**
         * 点击“我"
         */
        CLICK_SELF_TAB(50000, 0, levelTop),

        /**
         * 点击“Vx会员（成长值）/会员俱乐部"-金融用户/普通用户
         */
        CLICK_MEMBER_CLUB(50000, 1, levelMid),

        /**
         * 点击VIP直通
         */
        CLICK_VIP_TRAIN(50000, 2, levelMid),

        /**
         * VIP有效期已到弹窗出现
         */
        VIP_TIME_OUT_SHOW_POPUP(50000, 3, levelMid),

        /**
         * VIP有效期弹窗--土豪升级
         */
        VIP_TIME_OUT_UPGRADE(50000, 4, levelMid),

        /**
         * vip升级提醒弹窗出现（金融用户/普通用户）
         */
        VIP_POPUP_NOTICE(50000, 5, levelMid),

        /**
         * VIP升级提醒（金融用户/普通用户）--炫耀一下
         */
        VIP_POPUP_NOTICE_FLAUNTING(50000, 6, levelMid),

        /**
         * 普通用户升级提醒弹窗出现
         */
        NORMAL_USER_UPGRADE(50000, 7, levelMid),

        /**
         * 普通用户升级提--知道啦
         */
        NORMAL_USER_UPGRADE_KNOW(50000, 8, levelMid),

        /**
         * 点击分享
         */
        WIFI_SHARE(20001, 1, levelMid),
        /**
         * 取消分享
         */
        WIFI_SHARE_CANCEL(20001, 2, levelMid),
        /**
         * 分享到
         */
        WIFI_SHARE_TO(20001, 3, levelMid),
        /**
         * 分享结果
         */
        WIFI_SHARE_RESULT(20001, 4, levelMid),
        /**
         * 三步连接界面 - 点击分享
         */
        WIFI_CONNECT_SHARE_CLICK(20001, 5, levelMid),
        /**
         * 点击活动气泡
         */
        WIFI_CLICK_ACTION_BUBBLE(20002, 1, levelMid),
        /**
         * 关闭活动气泡
         */
        WIFI_CLOSE_ACTION_BUBBLE(20002, 2, levelMid),
        /**
         * 点击注册送红包气泡
         */
        WIFI_CLICK_REGISTER_RED_PACKET_BUBBLE(20002, 3, levelMid),
        /**
         * 关闭注册送红包气泡
         */
        WIFI_CLOSE_REGISTER_RED_PACKET_BUBBLE(20002, 4, levelMid),
        /**
         * 领取1000金币气泡
         */
        WIFI_RECEIVE_GOLD_BUUBLE(20002, 5, levelMid),
        /**
         * 首页抓精灵气泡出现
         */
        HOME_CATCH_SPIRIT_SHOW(20002, 10, levelMid),
        /**
         * 点击首页抓精灵气泡关闭
         */
        HOME_CATCH_SPIRIT_CLICK_CLOSE(20002, 11, levelMid),
        /**
         * 点击首页抓精灵气泡内容
         */
        HOME_CATCH_SPIRIT_CLICK_CONTENT(20002, 12, levelMid),
        /**
         * 首页每天首次开启VPN成功后送流量弹窗出现
         */
        HOME_SPIRIT_POP_SHOW(20002, 13, levelMid),
        /**
         * 首页每天首次开启VPN成功后送流量弹窗被点击
         */
        HOME_SPIRIT_POP_CLICK_CONTENT(20002, 14, levelMid),
        /**
         * 首页banner点击
         */
        MAIN_FRAGMENT_BANNER_CLICK(20002, 6, levelMid),
        /**
         * 免费上网剩余60分钟时长展现
         */
        VIP_REMAIN_TIME_SHOW(20003, 40, levelMid),
        /**
         * 点击了解会员特权
         */
        VIP_REMAIN_TIME_CLICK(20003, 41, levelMid),
        /**
         * 时长用完提示弹窗--不，谢谢
         */
        VIP_NO_TIME_NEGATIVE(20003, 42, levelMid),
        /**
         * 时长用完提示弹窗--获取vip会员
         */
        VIP_NO_TIME_POSITIVE(20003, 43, levelMid),
        /**
         * 开始取卡
         */
        WIFI_CONNECT_WIFI_START_GET_CARD(20009, 0, levelTop),
        /**
         * 拿卡成功
         */
        WIFI_CONNECT_WIFI_GET_CARD_SUCCESS(20009, 1, levelTop),
        /**
         * 拿卡失败
         */
        WIFI_CONNECT_WIFI_GET_CARD_FAIL(20009, 2, levelTop),
        /**
         * 拿卡失败,用户点击重试
         */
        WIFI_CONNECT_WIFI_GET_CARD_FAIL_TRY_AGAIN(20009, 3, levelTop),
        /**
         * 连接WIFI成功
         */
        WIFI_CONNECT_WIFI_SUCCESS(20009, 4, levelTop),
        /**
         * 连接WIFI失败
         */
        WIFI_CONNECT_WIFI_FAIL(20009, 5, levelTop),
        /**
         * 连接WIFI失败,用户点击重试
         */
        WIFI_CONNECT_WIFI_FAIL_TRY_AGAIN(20009, 6, levelTop),
        /**
         * 登陆运营商成功(鉴权成功)
         */
        WIFI_CONNECT_WIFI_LOGIN_SUCCESS(20009, 7, levelTop),
        /**
         * 登陆运营商失败(鉴权失败)
         */
        WIFI_CONNECT_WIFI_LOGIN_FAIL(20009, 8, levelTop),
        /**
         * 登陆运营商失败(鉴权成功),用户点击重试
         */
        WIFI_CONNECT_WIFI_LOGIN_FAIL_TRY_AGAIN(20009, 9, levelTop),
        /**
         * 网络检测成功
         */
        WIFI_CONNECT_WIFI_CHECK_NET_SUCCESS(20009, 10, levelTop),
        /**
         * 网络检测失败
         */
        WIFI_CONNECT_WIFI_CHECK_NET_FAIL(20009, 11, levelTop),
        /**
         * 返回
         */
        WIFI_CONNECT_BACK(20009, 12, levelTop),
        /**
         * 后台服务
         */
        WIFI_CONNECT_BACKSTAGSERVICE(20009, 13, levelTop),
        /**
         * 杀进程断开并忽略CMCC-WEB
         */
        WIFI_CONNECT_IGNORE_CMCC_WEB(20009, 14, levelTop),
        /**
         * 热点时长已用完,拒绝服务
         */
        WIFI_CONNECT_REFUSE_SERVICE_AUTHENT(20009, 20, levelTop),
        /**
         * 隐藏热点信息
         */
        WIFI_CONNECT_HIDE_HOT_SPOT(20009, 22, levelTop),
        /**
         * 请求用户等级动态配置信息成功
         */
        WIFI_REQUEST_USERGARED_INFO_SUCCESS(20009, 23, levelMid),
        /**
         * 请求用户等级动态配置信息失败
         */
        WIFI_REQUEST_USERGARED_INFO_FAIL(20009, 24, levelMid),
        /**
         * 自动连接显示
         */
        AUTO_CONNECT_SHOW(20009, 25, levelMid),
        /**
         * 自动连接点击
         */
        AUTO_CONNECT_CLICK(20009, 26, levelMid),
        /**
         * 自动连接结果
         */
        AUTO_CONNECT_RESULT(20009, 27, levelMid),
        /**
         * 新注册用户连接WiFi得奖励
         */
        NEW_USER_CONNECT_REWARD(20009, 28, levelMid),
        /**
         * 获取上网凭证失败，点击进入设置
         */
        GET_CARD_FAIL_GO2_SETTING(20009, 29, levelMid),

        /**
         * 关闭WiFi开关指引
         */
        WIFI_CLOSE_WIFI_CONFIG(20004, 0, levelMid),
        /**
         * 连接成功-开始上网
         */
        WIFI_CONNECT_START_NETWORK(20004, 1, levelTop),
        /**
         * 连接成功-断开网络
         */
        WIFI_CONNECT_DISCONNECT_NETWORK(20004, 2, levelTop),
        /**
         * 活动广告
         */
        WIFI_CONNECT_ACTION_AD_CLICK(20004, 3, levelTop),
        /**
         * 移动联盟广告
         */
        WIFI_CONNECT_MA_AD_CLICK(20004, 4, levelTop),
        /**
         * 暂不连接
         */
        WIFI_CONNECT_NOT_CONNECT(20004, 5, levelMid),
        /**
         * 试一下
         */
        WIFI_CONNECT_TO_TRY(20004, 6, levelMid),
        /**
         * 放弃连接-取消
         */
        WIFI_CONNECT_ABANDON_CANCEL(20004, 7, levelMid),
        /**
         * 放弃连接-确定
         */
        WIFI_CONNECT_ABANDON_CONFIRM(20004, 8, levelMid),
        /**
         * 点击商户AD
         */
        WIFI_CONNECT_CLICK_BUSINESSES_AD(20004, 9, levelMid),
        /**
         * 记录调用下线成功
         */

        RECORD_OPERAT_LOGOUT_SUCCESS(20004, 11, levelMid),
        /**
         * 记录调用下线失败
         */
        RECORD_OPERAT_LOGOUT_FAIL(20004, 12, levelMid),
        /**
         * 点击商户电话
         */
        WIFI_CONNECT_CLICK_BUSINESSES_TELE(20004, 13, levelMid),

        /**
         * 已连接wifi
         */
        WIFI_LAUNCH_CONNECTED(20004, 14, levelMid),
        /**
         * 无密码-连接成功页-portal登录
         */
        WIFI_NO_PASSWORD_PORTAL_LOGIN(20004, 15, levelMid),
        /**
         * 无密码wifi-打开portal页
         */
        WIFI_NO_PASSWORD_OPEN_PORTAL(20004, 16, levelMid),
        /**
         * 稍后再说
         */
        WIFI_SWITCH_CANCEL(20004, 22, levelMid),
        /**
         * 确认切换
         */
        WIFI_SWITCH_CONFIRM(20004, 23, levelMid),
         /**
         * 购买流量套餐出现
         */
        DATA_BUY_SHOW(20004, 24, levelMid),
         /**
         * 购买流量套餐点击
         */
        DATA_BUY_CLICK(20004, 25, levelMid),
        /**
         * 地图刷新点击
         */
        MAP_REFRESH_CLICK(20004, 26, levelMid),
        /**
         * 地图放大或缩小点击
         */
        MAP_LESS_OR_PLUS_CLICK(20004, 27, levelMid),
        /**
         * 我知道密码，共享WiFi获取成长值点击
         */
        KONW_WIFI_PASSWORD_CLICK(20004, 28, levelMid),
        /**
         * 点击共享WiFi获得1000成长值
         */
        SHARE_WIFI_CLICK(20004, 29, levelMid),
        /**
         * 点击 列表无免费WiFi Button
         */
        NO_WIFI_DATA_BUY_CLICK(20004, 30, levelMid),
        /**
         * 点击商户信息banner
         */
        CONNECT_SHANGHU_BANNER_CLICK(20004, 31, levelMid),
        /**
         * 点击商户信息马上领取优惠券
         */
        CONNECT_SHANGHU_RECEIVE_COUPON_CLICK(20004, 32, levelMid),
        /**
         * 点击商户信息优惠券去使用
         */
        CONNECT_SHANGHU_COUPON_TOUSE_CLICK(20004, 33, levelMid),
        /**
         * 商户信息优惠券弹窗消失
         */
        CONNECT_SHANGHU_COUPON_DIALOG_DISMISS(20004, 34, levelMid),
        /**
         * 点击商户信息优惠券弹窗中去使用
         */
        CONNECT_SHANGHU_COUPON_DIALOG_TOUSE_CLICK(20004, 35, levelMid),
        /**
         * 龙珠活动三步连接失败
         */
        CONNECT_WIFI_DRAGON_AD_FAIL(20004, 36, levelMid),
        /**
         * 龙珠活动三步连接成功
         */
        CONNECT_WIFI_DRAGON_AD_SUCCESS(20004, 37, levelMid),
        /**
         * 开启WiFi
         */
        WIFI_OPEN_WIFI(20005, 0, levelMid),
        /**
         * 点击测速
         */
        WIFI_SPEED_TEST_CLICK(20005, 1, levelMid),
        /**
         * 测速结果
         */
        WIFI_SPEED_TEST_RESULT(20005, 2, levelMid),
        /**
         * 分享一下
         */
        WIFI_SPEED_TEST_SHARE(20005, 3, levelMid),
        /**
         * 重新测速
         */
        WIFI_SPEED_TEST_RETRY(20005, 4, levelMid),
        /**
         * 测速失败
         */
        WIFI_SPEED_TEST_FAIL(20005, 5, levelMid),
        /**
         * 点击取消测速
         */
        WIFI_SPEED_TEST_CANCEL(20005, 6, levelMid),
        /**
         * 点击开始测速
         */
        WIFI_SPEED_TEST_START(20005, 7, levelMid),
        /**
         * 点击安全检测
         */
        WIFI_SECURITY_TEST_CLICK(20005, 8, levelMid),
        /**
         * 检测结果
         */
        WIFI_SECURITY_TEST_RESULT(20005, 9, levelMid),
        /**
         * 重新检测
         */
        WIFI_SECURITY_TEST_RETRY(20005, 10, levelMid),
        /**
         * 反馈一下
         */
        WIFI_FEEDBACK_CLICK(20005, 11, levelMid),
        /**
         * 提交
         */
        WIFI_FEEDBACK_SUBMIT(20005, 13, levelMid),
        /**
         * 网络异常断开重新连接--返回首页
         */
        WIFI_RECONNECT(20005, 14, levelMid),

        /**
         * 关闭WiFi
         */
        WIFI_CLOSE_WIFI(20006, 0, levelMid),
        /**
         * 刷新WiFi
         */
        WIFI_REFRESH_WIFI(20007, 0, levelMid),
        /**
         * 进入app推荐页面
         */
        NOT_SUPPORT_WIFI(20007, 1, levelTop),
        /**
         * 奖励弹窗出现
         */
        FREEDATA_SHOW(20007, 2, levelTop),
        /**
         * 流量多不想领
         */
        FREEDATA_CANCEL(20007, 3, levelTop),
        /**
         * 现在去领流量
         */
        FREEDATA_CONFIRM(20007, 4, levelTop),
//        /**
//         * 系统自动刷新WiFi,记录数据,
//         */
//        SYSTEM_WIFI_REFRESH_WIFI(20007, 5, levelMid),
        /**
         * 系统检测无任何热点
         */
        CHECK_NOT_SYSTEM_SCANRESULT_WIFI (20007, 6, levelMid),
        /**
         * 没有平安支持的免费热点
         */
        NO_PAFREE_WIFI(20007, 7, levelMid),
        /**
         * 展示广告页失败
         */
        AD_SHOW_FAIL(20008, 1, levelMid),

        /**
         * 未配置
         */
        AD_SHOW_EMPTYURL(20008, 2, levelMid),

        /**
         * 广告展示成功
         */
        AD_SHOW_SUCCESS(20008, 3, levelMid),

        /**
         * 广告位点击
         */
        AD_SHOW_CLICK(20008, 4, levelMid),

        /**
         * 展现广告页成功
         */
        AD_SHOW_SUCCESS_LAUNCH(20008, 5, levelMid),

        /**
         * 展现广告页失败
         */
        AD_SHOW_FAIL_LAUNCH(20008, 6, levelMid),
        /**
         * 开屏广告位点击
         */
        AD_SHOW_CLICK_LAUNCH(20008, 7, levelMid),
        /**
         * 点击跳过
         */
        AD_SHOW_SKIP_LAUNCH(20008, 8, levelMid),
        /**
         * 插屏广告展示成功
         */
        AD_GENERAL_SHOW_SUCCESS(20008, 9, levelMid),
        /**
         * 插屏广告展示失败
         */
        AD_GENERAL_SHOW_FAIL(20008, 10, levelMid),
        /**
         * 点击插屏广告
         */
        AD_GENERAL_CLICK(20008, 11, levelMid),
        /**
         * 关闭插屏广告
         */
        AD_GENERAL_CLOSE(20008, 12, levelMid),
        /**
         * 有道下载成功
         */
        AD_YOUDAO_DOWNLOAD_SUCCESS(20008, 13, levelMid),
        /**
         * 有道点击安装
         */
        AD_YOUDAO_CLICK_INSTALL(20008, 14, levelMid),
        /**
         * 有道广告展示成功
         */
        AD_YOUDAO_SHOW_SUCCESS(20008, 15, levelMid),
        /**
         * 点击有道广告
         */
        AD_YOUDAO_CLICK(20008, 16, levelMid),
        /**
         * 点击有道确认下载
         */
        AD_YOUDAO_CONFIRM_DOWNLOAD(20008, 17, levelMid),
        /**
         * 取消有道下载
         */
        AD_YOUDAO_CANCEL_DOWNLOAD(20008, 18, levelMid),

        /**
         * 活动频道TAB点击
         */
        EVENTS_CHANNEL_CLICK(20008, 20, levelMid),

        /**
         * 活动频道活动被点击
         */
        EVENTS_ITEM_CLICK(20008, 21, levelMid),

        /**
         * 请输入密码
         */
        OTHER_WIFI_INPUT_PWD(12001, 1, levelMid),
        /**
         * 明文
         */
        OTHER_WIFI_INPUT_SHOW_PWD(12001, 2, levelMid),
        /**
         * 试试手气
         */
        OTHER_WIFI_INPUT_ATTEMPT(12001, 3, levelMid),
        /**
         * 立即连接
         */
        OTHER_WIFI_CONNECT(12001, 4, levelMid),
        /**
         * 暂不连接
         */
        OTHER_WIFI_CANCEL_CONNECT(12001, 5, levelMid),
        /**
         * 密码错误
         */
        OTHER_WIFI_PWD_ERROR(12001, 6, levelMid),


        /**
         * 蒙版可免费链接网友共享wifi,知道啦
         */
        KNOW_FREE_CONNECT_CLICK(12001, 7, levelMid),

        /**
         * 有密码WiFi(未共享)-WIFI登陆弹窗(私人/商户WiFi)-服务声明
         */
        WIFI_PASSWORD_SHARE_DIALOG_STATEMENT(12001, 8, levelMid),
        /**
         * 正在连接
         */
        OTHER_WIFI_CONNECTING(12002, 1, levelTop),
        /**
         * 正在进行身份验证
         */
        OTHER_WIFI_VERIFY_IDENTITY(12002, 2, levelTop),
        /**
         * 已上网
         */
        OTHER_WIFI_CONNECTED(12002, 3, levelTop),
        /**
         * 重试
         */
        OTHER_WIFI_TRY_AGAIN(12002, 4, levelTop),
        /**
         * 取消
         */
        OTHER_WIFI_CANCEL(12002, 5, levelTop),
        /**
         * 请输入用户名
         */
        OTHER_BUSINESS_WIFI_INPUT_USERNAME(12003, 1, levelMid),
        /**
         * 请输入密码
         */
        OTHER_BUSINESS_WIFI_INPUT_PWD(12003, 2, levelMid),
        /**
         * 明文
         */
        OTHER_BUSINESS_WIFI_SHOW_PWD(12003, 3, levelMid),
        /**
         * 立即连接
         */
        OTHER_BUSINESS_WIFI_CONNECT(12003, 4, levelMid),
        /**
         * 暂不连接
         */
        OTHER_BUSINESS_WIFI_CANCEL_CONNECT(12003, 5, levelMid),
        /**
         * 用户名或密码错误
         */
        OTHER_BUSINESS_WIFI_ERROR_USERNAME_OR_PWD(12003, 6, levelMid),
        /**
         * 立即连接按钮
         */
        SHARE_WIFI_CONNECT_NOT_SHARE(12003, 19, levelMid),
        /**
         * 点击连接ssid
         */
        WIFI_LIST_CLICK(12003, 20, levelMid),
        /**
         * wifi列表点击连接并分享按钮
         */
        SHARE_WIFI_CONNECT_REWORD(12003, 21, levelTop),
        /**
         * 共享wifi功能服务说明
         */
        SHARE_WIFI_ANNOUNCEMENT(12003, 22, levelMid),
        /**
         * 私人热点连接成功后点击分享button
         */
        SHARE_WIFI_CONNECT_SUCC_SHARE_BTN(12003, 23, levelMid),
        /**
         * 三步连接页面连接并分享按钮
         */
        SHARE_WIFI_CONNECT_AND_SHARE_IN_CONNECT_ACTIVITY(12003, 24, levelTop),
        /**
         * 共享成功
         */
        SHARE_WIFI_SHARE_SUCC(12003, 25, levelTop),
        /**
         * 共享失败（密码对未上传成/密码错）
         */
        SHARE_WIFI_SHARE_FAIL(12003, 26, levelTop),
        /**
         * 共享wifi弹窗--取消
         */
        SHARE_WIFI_CONNECT_CANCEL(12003, 27, levelMid),
        /**
         * 连接成功页--认领wifi
         */
        SHARE_WIFI_CLAIM_MINE(12003, 28, levelMid),
        /**
         * 马上下载
         */
        SHARE_WIFI_DOWNLOAD_SHOUYIBAO(12003, 29, levelMid),
        /**
         * 填写反馈
         */
        SHARE_WIFI_FEEDBACK(12003, 30, levelMid),
        /**
         * wifi列表弹窗--出现
         */
        SHARE_WIFI_DIALOG_SHOW(12003, 31, levelMid),
        /**
         * wifi列表弹框--关闭
         */
        SHARE_WIFI_DIALOG_CLOSE(12003, 32, levelMid),
        /**
         * WIFI密码错误，从外部点击进入
         */
        SHARE_WIFI_DIALOG_WRONG_PWD(12003, 33, levelTop),
        /**
         * 三步连接页面弹框出现
         */
        SHARE_WIFI_CONNECT_DIALOG_SHOW(12003, 34, levelMid),
        /**
         * 三步连接页面弹框关闭
         */
        SHARE_WIFI_CONNECT_DIALOG_CLOSE(12003, 35, levelMid),
        /**
         * 三步连接分享弹窗--密码错误
         */
        SHARE_WIFI_CONNECT_DIALOG_PWD_WRONG(12003, 37, levelTop),
        /**
         * 点击"连接并共享WIFI,得奖励" 按钮连接Wifi成功
         */
        SHARE_WIFI_CONNECT_AP_SUCCESS(12003, 40, levelTop),
        /**
         * 点击"连接并共享WIFI,得奖励" 按钮连接Wifi超时
         */
        SHARE_WIFI_CONNECT_AP_TIMEOUT(12003, 41, levelTop),
        /**
         * 三步连接页面，第二步失败时，点击推荐的热点
         */
        WIFI_RECOMMEND_STEP2_FAIL_CLICK(12003, 50, levelMid),
        /**
         * 三步连接页面，第三步鉴权失败时，点击推荐的热点
         */
        WIFI_RECOMMEND_STEP3_FAIL_CLICK(12003, 51, levelMid),
        /**
         * checkAp后预取密码库密码的埋点
         */
        SHARED_WIFI_PREPARATION_GET_PWD(12003, 53, levelMid),

        /**
         * 开始尝试连接
         */
        EXCAVATE_WIFI_START_CONNECT(12004, 1, levelMid),
        /**
         * 检查失败
         */
        EXCAVATE_WIFI_CHECK_FAIL(12004, 2, levelMid),
        /**
         * 检查成功
         */
        EXCAVATE_WIFI_CHECK_SUCCESS(12004, 3, levelMid),
        /**
         * 连接失败
         */
        EXCAVATE_WIFI_CONNECT_FAIL(12004, 4, levelMid),
        /**
         * 连接成功
         */
        EXCAVATE_WIFI_CONNECT_SUCCESS(12004, 5, levelMid),
        /**
         * 重试
         */
        EXCAVATE_WIFI_TYE_AGAIN(12004, 6, levelMid),
        /**
         * 返回
         */
        EXCAVATE_WIFI_BACK(12004, 7, levelMid),
        /**
         * 附近热点
         */
        NEARBY_AP_LIST(30001, 0, levelMid),
        /**
         * 点击免费流量tab
         */
        FREE_DATA_TAB_CLICKED(40001, 0, levelMid),
        /**
         * 点击活动
         */
        ACTIONS(40001, 1, levelMid),
        /**
         * 开始加载
         */
        ACTIONS_START_PAGE(40001, 2, levelMid),
        /**
         * 加载完成
         */
        ACTIONS_END_PAGE(40001, 3, levelMid),
        /**
         * 加载失败
         */
        ACTIONS_ERROR_PAGE(40001, 4, levelMid),
        /**
         * 天气--点击选择地理位置
         */
        WEATHER_CITY_SELECT_CLICK(40001, 5, levelMid),
        /**
         * 搜索--点击搜索框
         */
        SEARCH_VIEW_CLICK(40001, 6, levelMid),
        /**
         * 搜索--点击搜索内容
         */
        SEARCH_VIEW_CLICK_CONTENT(40001, 7, levelMid),
        /**
         * 搜索--返回
         */
        SEARCH_VIEW_BACK(40001, 8, levelMid),
        /**
         * 活动推荐位展示成功(天气)
         */
        WEATHER_AD_SHOW_SUCCESS(40001, 9, levelMid),
        /**
         * 点击活动推荐位(天气)
         */
        WEATHER_AD_CLICK(40001, 10, levelMid),
        /**
         * 频道-通用页面框架-关闭
         */
        CHANNEL_PAGE_CLICK_CLOSE(40003, 2, levelMid),
        /**
         * 频道入口(更多)
         */
        CHANNEL_DISC_MORE(40005, 0, levelMid),
        /**
         * 频道入口(下拉刷新)
         */
        CHANNEL_DISC_PULL_REFRESH(40005, 1, levelMid),
        /**
         * 频道入口(娱乐)
         */
        CHANNEL_DISC_ENT(40005, 2, levelMid),
        /**
         * 频道入口(体育)
         */
        CHANNEL_DISC_SPORT(40005, 3, levelMid),
        /**
         * 资讯页面
         */
        NEWS_1(40006, 1, levelMid),
        /**
         * 资讯页面
         */
        NEWS_MORE(40006, 0, levelMid),
        /**
         * 点击设置
         */
        SELF_SETTING(50001, 0, levelMid),
        /**
         * 登录
         */
        SELF_LOGIN(50002, 0, levelMid),
        /**
         * 注册平安wifi验证手机号弹窗-不，谢谢
         */
        REGISTERED_DIALOG_CANCEL(50002, 7, levelMid),
        /**
         * 注册平安wifi验证手机号弹窗-去登录
         */
        REGISTERED_DIALOG_GOTO_LOGIN(50002, 8, levelMid),
        /**
         * 我-帐户设置页-其他登录方式绑定/解绑
         */
        SETTING_ACCOUNT_BIND_UNBIND(50002, 9, levelMid),
        /**
         * 金币
         */
        SELF_SCORE(50003, 0, levelMid),
        /**
         * 签到
         */
        SELF_SIGN(50004, 0, levelMid),
        /**
         * 兑换中心
         */
        SELF_EXCHANGE(50005, 0, levelMid),
        /**
         * 做任务
         */
        SELF_DO_TASK(50006, 0, levelMid),
        /**
         * 更多
         */
        SELF_MORE(50007, 0, levelMid),
        /**
         * 滑动热点扫描通知
         */
        SELF_MORE_WIFI_NOTIFY_CONFIG(50008, 0, levelMid),
        /**
         * 关于我们
         */
        SELF_MORE_ABOUT_US(50009, 0, levelMid),
        /**
         * 检查版本
         */
        SELF_MORE_CHECK_VERSION(50010, 0, levelMid),
        /**
         * 常见问题
         */
        SELF_MORE_QA(50011, 0, levelMid),
        /**
         * 意见反馈
         */
        SELF_MORE_FEEDBACK(50012, 0, levelMid),
        /**
         * 我的反馈
         */
        SELF_MORE_MY_FEEDBACK(50013, 0, levelMid),
        /**
         * 点击微信公众号
         */
        SELF_MORE_WX_PUBLIC_NUMBER(50014, 0, levelMid),
        /**
         * 点击微博公众号
         */
        SELF_MORE_WEIBO_PUBLIC_NUMBER(50015, 0, levelMid),
        /**
         * 点击QQ群号
         */
        SELF_MORE_QQ_GROUP(50016, 0, levelMid),
        /**
         * 点击个人中心--消息
         */
        MSG_CENTER_CLICK(50030, 0, levelMid),
        /**
         * 返回
         */
        MSG_CENTER_BACK(50031, 0, levelMid),
        /**
         * 点击消息中心-内容
         */
        MSG_CENTER_CLICK_ITEM_TITLE(50032, 0, levelMid),
        /**
         * 点击内容--查看详情
         */
        MSG_CENTER_CLICK_ITEM_CONTENT(50033, 0, levelMid),
        /**
         * 点击卡包
         */
        CP_CLICK_CARD_PACKAGE(50040, 0, levelMid),
        /**
         * 点击删除优惠券垃圾箱
         */
        CP_CLICK_CLICK_DUSTBIN(50040, 1, levelMid),
        /**
         * 删除优惠券弹窗--删除
         */
        CP_CLICK_POP_DEL(50040, 2, levelMid),
        /**
         * 删除优惠券弹窗--取消
         */
        CP_CLICK_POP_CANCEL(50040, 3, levelMid),
        /**
         * 点击优惠券
         */
        CP_CLICK_CARD_ITEM(50040, 4, levelMid),
        /**
         * 点击右上角button
         */
        CP_CLICK_CARD_MENU(50040, 5, levelMid),
        /**
         * 浮窗--删除
         */
        CP_CLICK_CARD_DEL(50040, 6, levelMid),
        /**
         * 浮窗--取消
         */
        CP_CLICK_CARD_CANCEL(50040, 7, levelMid),
        /**
         * 你确定要删除吗--关闭
         */
        CP_CLICK_CARD_DIALOG_CLOSE(50040, 8, levelMid),
        /**
         * 你确定要删除吗--确定
         */
        CP_CLICK_CARD_DIALOG_CONFIRM(50040, 9, levelMid),
        /**
         * 点击立即使用
         */
        CP_CLICK_TOP_UP(50040, 10, levelMid),
        /**
         * 确定充值吗--关闭
         */
        CP_CLICK_TOP_UP_POP_CLOSE(50040, 11, levelMid),
        /**
         * 确定充值吗--充值
         */
        CP_CLICK_TOP_UP_POP_CONFIRM(50040, 12, levelMid),
        /**
         * 充值成功
         */
        CP_TOP_UP_SUCCESS(50040, 13, levelMid),
        /**
         * 充值失败
         */
        CP_TOP_UP_FAIL(50040, 14, levelMid),
        /**
         * 充值失败--关闭
         */
        CP_TOP_UP_FAIL_CLOSE(50040, 15, levelMid),
        /**
         * 充值失败--重试
         */
        CP_TOP_UP_FAIL_RETRY(50040, 16, levelMid),
        /**
         * 点击返回
         */
        CP_CLICK_BACK(50040, 17, levelMid),
        /**
         * 输入手机号
         */
        REGISTER_INPUT_PHONE_NUM(60001, 1, levelMid),
        /**
         * 获取验证码
         */
        REGISTER_GET_VERIFY_CODE(60001, 2, levelMid),
        /**
         * 收到验证码
         */
        REGISTER_RECEIVER_VERIFY_CODE(60001, 3, levelMid),
        /**
         * 下一步
         */
        REGISTER_CLICK_NEXT(60001, 4, levelMid),
        /**
         * 点击关闭
         */
        REGISTER_CLICK_CLOSE(60001, 5, levelMid),
        /**
         * 取消同意复选框
         */
        REGISTER_CANCEL_USER_AGREEMENT(60001, 6, levelMid),
        /**
         * 点击软件使用协议
         */
        REGISTER_CLICK_USER_AGREEMENT(60001, 7, levelMid),
        /**
         * 点击登录
         */
        REGISTER_CLICK_LOGIN(60001, 8, levelMid),
        /**
         * 设置密码
         */
        REGISTER_SETTING_PWD(60002, 1, levelMid),
        /**
         * 显示密码
         */
        REGISTER_SHOW_PWD(60002, 2, levelMid),
        /**
         * 立即注册
         */
        REGISTER_CLICK_SUBMIT(60002, 3, levelMid),
        /**
         * 注册界面点击返回
         */
        REGISTER_CLICK_BACK(60002, 4, levelMid),
        /**
         * 输入手机号或用户名
         */
        LOGIN_INPUT_PHONE_OR_USERNAME(70001, 1, levelMid),
        /**
         * 输入密码
         */
        LOGIN_INPUT_PWD(70001, 2, levelMid),
        /**
         * 立即登录
         */
        LOGIN_CLICK_SUBMIT(70001, 3, levelMid),
        /**
         * 显示密码
         */
        LOGIN_SHOW_PWD(70001, 4, levelMid),
        /**
         * 点击关闭
         */
        LOGIN_CLICK_CLOSE(70001, 5, levelMid),
        /**
         * 跳转注册
         */
        LOGIN_GO_REGISTER(70001, 6, levelMid),
        /**
         * 找回密码
         */
        LOGIN_FOUND_PWD(70001, 7, levelMid),
        /**
         * 输入手机号码
         */
        RETRIEVE_PWD_VERIFY_PHONE_INPUT_PHONE(70002, 1, levelMid),
        /**
         * 获取验证码
         */
        RETRIEVE_PWD_VERIFY_PHONE_GET_VERIFY_CODE(70002, 2, levelMid),
        /**
         * 下一步
         */
        RETRIEVE_PWD_VERIFY_PHONE_CLICK_NEXT(70002, 3, levelMid),
        /**
         * 返回
         */
        RETRIEVE_PWD_VERIFY_PHONE_CLICK_BACK(70002, 4, levelMid),
        /**
         * 输入密码
         */
        RETRIEVE_PWD_SET_PWD_INPUT_PWD(70003, 1, levelMid),
        /**
         * 提交设置
         */
        RETRIEVE_PWD_SET_PWD_SUBMIT(70003, 2, levelMid),
        /**
         * 显示密码
         */
        RETRIEVE_PWD_SET_PWD_SHOW_PWD(70003, 3, levelMid),
        /**
         * 返回
         */
        RETRIEVE_PWD_SET_PWD_CLICK_BACK(70003, 4, levelMid),
        /**
         * 输入安全问题答案
         */
        RETRIEVE_PWD_VERIFY_SAFE_INPUT_QUESTION(70004, 1, levelMid),
        /**
         * 返回
         */
        RETRIEVE_PWD_VERIFY_SAFE_QUESTION_BACK(70004, 2, levelMid),
        /**
         * 下一步
         */
        RETRIEVE_PWD_VERIFY_SAFE_QUESTION_SUBMIT(70004, 3, levelMid),
        /**
         * 头像设置
         */
        SETTING_SET_HEAD_SET_PHOTO(80001, 1, levelMid),
        /**
         * 点击拍照
         */
        SETTING_SET_HEAD_CLICK_TAKE_PICTURE(80001, 2, levelMid),
        /**
         * 点击相册
         */
        SETTING_SET_HEAD_CLICK_PHOTOGRAPH(80001, 3, levelMid),
        /**
         * 点击取消
         */
        SETTING_SET_HEAD_CLICK_CANCEL(80001, 4, levelMid),
        /**
         * 设置用户名
         */
        SETTING_USER_NAME(80002, 0, levelMid),
        /**
         * 修改手机号
         */
        SETTING_MODIFY_PHONE_NUMBER(80003, 0, levelMid),
        /**
         * 输入安全问题答案
         */
        SETTING_MODIFY_PHONE_NUMBER_SAFE_QUESTION_INPUT_SAFE_QUESTION(80004, 1, levelMid),
        /**
         * 下一步
         */
        SETTING_MODIFY_PHONE_NUMBER_SAFE_QUESTION_CLICK_NEXT(80004, 2, levelMid),
        /**
         * 返回
         */
        SETTING_MODIFY_PHONE_NUMBER_SAFE_QUESTION_CLICK_BACK(80004, 3, levelMid),
        /**
         * 输入新手机号
         */
        SETTING_MODIFY_PHONE_NUMBER_VERIFY_PHONE_INPUT_NEW_PHONE_NUM(80004, 4, levelMid),
        /**
         * 确认
         */
        SETTING_MODIFY_PHONE_NUMBER_VERIFY_PHONE_CLICK_SUBMIT(80004, 5, levelMid),
        /**
         * 返回
         */
        SETTING_MODIFY_PHONE_NUMBER_VERIFY_PHONE_CLICK_BACK(80004, 6, levelMid),
        /**
         * 获取验证码
         */
        SETTING_MODIFY_PHONE_NUMBER_VERIFY_PHONE_GET_VERIFY_CODE(80004, 7, levelMid),
        /**
         * 设置性别
         */
        SETTING_SET_SEX(80005, 0, levelMid),
        /**
         * 设置生日
         */
        SETTING_SET_BIRTHDAY(80006, 0, levelMid),
        /**
         * 修改登录密码
         */
        SETTING_MODIFY_PWD(80007, 0, levelMid),
        /**
         * 修改安全问题
         */
        SETTING_MODIFY_SAFE_QUESTION(80008, 0, levelMid),
        /**
         * 退出登录
         */
        SETTING_LOGIN_OUT(80009, 0, levelMid),
        /**
         * 左滑动
         */
        GUIDE_SLIDE_LEFT(90001, 0, levelMid),
        /**
         * 右滑动
         */
        GUIDE_SLIDE_RIGTH(90002, 0, levelMid),
        /**
         * 立即体验
         */
        GUIDE_CLICK_IMMEDIATELY_TAST(90003, 0, levelMid),
        /**
         * 注册、登录
         */
        GUIDE_CLICK_REGISTER(90003, 1, levelMid),
        /**
         * 开始持续登录
         */
        PERSIST_LOGIN(11001, 0, levelTop),
        /**
         * 持续登录失败
         */
        PERSIST_LOGIN_FAILED(11002, 0, levelTop),
        /**
         * 持续登录成功
         */
        PERSIST_LOGIN_SUCCESS(11003, 0, levelTop),
        /**
         * 点击内容
         */
        CONTENT_CLICK_LABEL(14001, 1, levelMid),
        /**
         * 返回
         */
        CONTENT_CLICK_BACK(14001, 2, levelMid),
        /**
         * 引导语出现
         */
        WELCOMES_APPEAR_TYPE(14001, 6, levelMid),
        /**
         * 点击引导语button
         */
        CLICK_WELCOMES_BTN(14001, 7, levelMid),
        /**
         * 清除用户数据
         */
        CLEAN_USER_DATA(11007, 0, levelTop),
        /**
         * 保存用户数据
         */
        SAVE_USER_DATA(11008, 0, levelTop),


        /**
         * 我要发送
         */
        FS_I_WANT_SEND(15002, 1, levelMid),
        /**
         * 选择文件，点击发送
         */
        FS_CHOOSE_FILE_TO_SEND(15002, 7, levelMid),
        /**
         * 对方是IOS
         */
        FS_TO_IOS(15002, 30, levelMid),
        /**
         * 帮助
         */
        FS_IOS_HELP(15002, 31, levelMid),
        /**
         * 选择接收者
         */
        FS_SELECT_RECEIVER(15002, 8, levelMid),
        /**
         * 发送成功
         */
        FS_SEND_SUCCESS(15002, 11, levelMid),
        /**
         * 发送失败
         */
        FS_SEND_FAIL(15002, 12, levelMid),
        /**
         * 退出快传
         */
        FS_TRANSFER_CANCEL(15002, 16, levelMid),
        /**
         * 继续选择文件
         */
        FS_CONTINUE_CHOOSE_FILE(15002, 32, levelMid),
        /**
         * 发送取消
         */
        FS_SEND_CANCEL(15002, 34, levelMid),
        /**
         * 组网成功
         */
        FS_SHAKE_SUCCESS(15002, 35, levelMid),
        /**
         * 组网失败
         */
        FS_SHAKE_FAIL(15002, 36, levelMid),

        /**
         * 我要接收
         */
        FS_I_WANT_RECEIVE(15003, 1, levelMid),
        /**
         * 退出连接
         */
        FS_LINK_CANCEL(15003, 2, levelMid),
        /**
         * 选择发送者
         */
        FS_SELECT_SENDER(15003, 3, levelMid),
        /**
         * 下载文件
         */
        FS_DOWNLOAD_FILE(15003, 20, levelMid),
        /**
         * 取消文件
         */
        @Deprecated
        FS_CANCEL_FILE(15003, 21, levelMid),
        /**
         * 接收成功
         */
        FS_RECEIVE_SUCCESS(15003, 22, levelMid),
        /**
         * 接收失败
         */
        FS_RECEIVE_FAIL(15003, 23, levelMid),
        /**
         * 接收取消
         */
        FS_RECEIVE_CANCEL(15003, 33, levelMid),

        /**
         * 分享
         */
        FS_SHARE(15004, 1, levelMid),
        /**
         * 分享被扫描下载
         */
        FS_SHARE_SCAN(15004, 2, levelMid),

        /**
         * 传输记录
         */
        FS_HISTORY(15005, 1, levelMid),
        /**
         * 传输历史
         */
        FS_HISTORY_TRANSFER(15005, 10, levelMid),
        /**
         * 已接收文件
         */
        FS_HISTORY_FILE(15005, 11, levelMid),

        /**
         * 设置
         */
        FS_SETTING(15006, 1, levelMid),
        /**
         * 自动接收开启
         */
        FS_SETTING_FILE_AUTO_RECEIVE_ON(15006, 2, levelMid),
        /**
         * 自动接收关闭
         */
        FS_SETTING_FILE_AUTO_RECEIVE_OFF(15006, 3, levelMid),
        /**
         * 数据保护开启
         */
        FS_SETTING_MOBILE_DATA_PROTECT_ON(15006, 4, levelMid),
        /**
         * 数据保护关闭
         */
        FS_SETTING_MOBILE_DATA_PROTECT_OFF(15006, 5, levelMid),

        /**
         * 点击国际wifi
         */
        INTERNATIONAL_WIFI_ENTER(18010, 1, levelTop),
        /**
         * 国际wifi页--返回
         */
        INTERNATIONAL_WIFI_BACK(18010, 2, levelMid),
        /**
         * 购买VIP结果
         */
        BUY_VIP(18002, 16, levelMid),
        /**
         * 弹窗出现
         */
        INTERNATIONAL_WIFI_POPUP_SHOW(16001, 1, levelMid),

        /**
         * 立即激活--页面跳转
         */
        INTERNATIONAL_WIFI_ACTIVATE_ENTRY(16001, 2, levelMid),

        /**
         * 不再提醒--弹窗消失
         */
        INTERNATIONAL_WIFI_DO_NOT_SHOW_AGAIN(16001, 3, levelMid),

        /**
         * 关闭--弹窗消失
         */
        INTERNATIONAL_WIFI_POPUP_CLOSE(16001, 4, levelMid),
        /**
         * 点击流量险
         */
        CLICK_LLX(50041, 0, levelTop),
        /**
         * 选择运营商
         */
        CHECK_OPERATOR(50041, 1, levelTop),
        /**
         * 点击免费验证
         */
        CLICK_FLOW_SMS_YANZHENG(50041, 2, levelTop),
        /**
         * 免费验证成功
         */
        SMS_TAOCAN_YANZHENG_SUCCESS(50041, 3, levelTop),
        /**
         * 点击去看看
         */
        CLICK_GO_SEE(50041, 4, levelTop),
        /**
         * 点击领取50M流量卡
         */
        CLICK_GET_FLOW_CARD(50041, 5, levelMid),
        /**
         * 流量状态改变
         */
        FLOW_STAUS_CHANGE(50041, 6, levelMid),
        /**
         * 点击流量险使用规则
         */
        CLICK_FLOW_RULE(50041, 7, levelMid),
        /**
         * 点击剩余天数
         */
        CLICK_LAST_DAY(50041, 8, levelMid),
        /**
         * 流量查询短信失败
         */
        FLOW_SMS_SEND_FAIL(50041, 9, levelTop),
        /**
         * 短信读取失败
         */
        FLOW_SMS_READ_FAIL(50041, 10, levelTop),
        /**
         * 免费验证失败--短信验证
         */
        FLOW_SMS_VERIFY_FAIL(50041, 11, levelTop),
        /**
         * 重新发送查询流量短信
         */
        FLOW_SMS_RETRY_SEND(50041, 12, levelMid),
        /**
         * 短信读取失败后重新选择运营商
         */
        FLOW_SMS_READ_FAIL_CLICK_RETRY(50041, 13, levelMid),
        /**
         * 短信验证失败后重新选择运营商
         */
        FLOW_SMS_YANZHENG_FAIL_CLICK_RETRY(50041, 14, levelMid),
        /**
         * 流量险页面点击返回
         */
        FLOW_PAGE_CLICK_BACK(50041, 15, levelMid),
        /**
         * 点击使用流量卡
         */
        CLICK_USE_FLOW_CARD(50041, 16, levelTop),
        /**
         * 出现时间校验弹窗
         */
        SHOW_TIME_ERROR_DIALOG(50041, 17, levelMid),
        /**
         * 点击先看看
         */
        CLICK_WATCH_AROUND(50041, 18, levelMid),
        /**
         * 点击马上修改
         */
        CLICK_MODIFY_RIGHT_NOW(50041, 19, levelMid),
        /**
         * 视频—热门推荐
         */
        VIDEO_HOT_RECOMMEND(40004, 1, levelMid),
        /**
         * 视频—平安影院
         */
        VIDEO_PINGAN_CENIMA(40004, 2, levelMid),
        /**
         * 免流量——鉴权
         */
        FREE_FLOW_AUTH(20003, 60, levelMid),
        /**
         * 免流量——鉴权成功
         */
        FREE_FLOW_AUTH_SUCCESS(20003, 61, levelMid),
        /**
         * 免流量——鉴权失败
         */
        FREE_FLOW_AUTH_FAIL(20003, 62, levelMid),
        /**
         * vpn免流量——鉴权
         */
        FREE_FLOW_AUTH_VPN(20003, 65, levelMid),

        /**
         * vpn免流量——鉴权失败
         */
        FREE_FLOW_AUTH_FAIL_VPN(20003, 68, levelMid),
        /**
         * 免流量——SDK开启
         */
        FREE_SDK_START(20003, 63, levelMid),
        /**
         * 免流量——SDK开启成功
         */
        FREE_SDK_START_SUCCESS(20003, 44, levelMid),
        /**
         * 免流量——SDK开启失败
         */
        FREE_SDK_START_FAIL(20003, 45, levelMid),
        /**
         * 免流量——切换节点
         */
        FREE_SWITCH_NODE(20003, 46, levelMid),
        /**
         * 免流量——切换节点成功
         */
        FREE_SWITCH_NODE_SUCCESS(20003, 47, levelMid),
        /**
         * 免流量——切换节点失败
         */
        FREE_SWITCH_NODE_FAIL(20003, 48, levelMid),
        /**
         * VPN免流量——切换节点
         */
        FREE_SWITCH_NODE_VPN(20003, 72, levelMid),

        /**
         * VPN免流量——切换节点失败
         */
        FREE_SWITCH_NODE_FAIL_VPN(20003, 74, levelMid),
        /**
         * 免流量——导流
         */
        FREE_GUIDE_FLOW(20003, 49, levelMid),
        /**
         * 免流量——导流成功
         */
        FREE_GUIDE_FLOW_SUCCESS(20003, 50, levelMid),
        /**
         * 免流量——导流失败
         */
        /**
         * vpn免流量——导流
         */
        FREE_GUIDE_FLOW_VPN(20003, 75, levelMid),

        /**
         * vpn免流量——导流失败
         */
        FREE_GUIDE_FLOW_FAIL_VPN(20003, 77, levelMid),
        /**
         * vpn免流量——预鉴权
         */
        FREE_GUIDE_FLOW_PRE_AUTH_FAIL_VPN(20003, 84, levelMid),
        /**
         * vpn免流量——开启数据流量对话框点击了取消
         */
        FREE_FLOW_DATAFLOW_OPEN_CANCLE(20003, 89, levelMid),
        /**
         * vpn免流量——开启数据流量对话框点击了确认
         */
        FREE_FLOW_DATAFLOW_OPEN_SUBMIT(20003, 90, levelMid),
        /**
         * vpn免流量——节点异常
         */
        FREE_GUIDE_FLOW_NODE_ERR_VPN(20003, 85, levelMid),
        /**
         * 免流量——button条出现
         */
        FREE_FLOW_VIEW_VISIBLE(20003, 56, levelMid),
        /**
         * 免流量——button点击
         */
        FREE_FLOW_VIEW_CLICK(20003, 57, levelMid),
        /**
         * 免流量——button登陆按钮点击
         */
        FREE_FLOW_VIEW_LOGIN(20003, 58, levelMid),
        /**
         * 免流量——去激活
         */
        FREE_FLOW_ACTIVE(20003, 59, levelMid),
        /**
         * 切换vpn
         */
        SWITCH_VPN(20003, 81, levelMid),
        /**
         * 重试切换vpn
         */
        SWITCH_VPN_RETRY(20003, 82, levelMid),
        /**
         * 钱包开户——入口
         */
        FUND_OPEN_ACCOUNT_DOOR(50007, 1, levelMid),
        /**
         * 钱包开户——立即存钱
         */
        FUND_OPEN_ACCOUNT_SAVE(50007, 2, levelMid),
        /**
         * 钱包开户——立即存钱--转入
         */
        FUND_OPEN_ACCOUNT_TURN_IN(50007, 3, levelMid),
        /**
         * 钱包开户——下一步--填写银行卡信息
         */
        FUND_OPEN_ACCOUNT_TO_BANK(50007, 4, levelMid),
        /**
         * 钱包开户——下一步--设置交易密码
         */
        FUND_OPEN_ACCOUNT_TO_PASSWORD(50007, 5, levelMid),
        /**
         * 钱包开户——获取验证码
         */
        FUND_OPEN_ACCOUNT_GET_VERIFY(50007, 6, levelMid),
        /**
         * 钱包开户——获取验证码--成功
         */
        FUND_OPEN_GET_VERIFY_SUCCESS(50007, 7, levelMid),
        /**
         * 钱包开户——获取验证码--失败
         */
        FUND_OPEN_GET_VERIFY_FAIL(50007, 8, levelMid),
        /**
         * 钱包开户——获取验证码--确认
         */
        FUND_OPEN_ACCOUNT_COMMIT(50007, 9, levelMid),
        /**
         * 钱包开户——获取验证码--完成
         */
        FUND_OPEN_ACCOUNT_FINISH(50007, 10, levelMid),
        /**
         * 钱包开户——返回
         */
        FUND_OPEN_ACCOUNT_BACK(50007, 11, levelMid),
        /**
         * 钱包首页——昨日收益
         */
        FUND_FIRST_PAGE_YESTERDAY(50007, 12, levelMid),
        /**
         * 钱包首页——买入
         */
        FUND_FIRST_PAGE_BUY(50007, 13, levelMid),
        /**
         * 钱包首页——取出
         */
        FUND_FIRST_PAGE_TAKE(50007, 14, levelMid),
        /**
         * 钱包首页——右上角功能菜单按钮
         */
        FUND_FIRST_PAGE_TITLE_RIGHT(50007, 15, levelMid),
        /**
         * 钱包首页——功能菜单--查询交易
         */
        FUND_FIRST_PAGE_TITLE_QUERY(50007, 16, levelMid),
        /**
         * 钱包首页——功能菜单--修改密码
         */
        FUND_FIRST_TITLE_MODIFY(50007, 17, levelMid),
        /**
         * 钱包首页——功能菜单--忘记密码
         */
        FUND_FIRST_TITLE_FORGET_PWD(50007, 18, levelMid),
        /**
         * 钱包首页——返回
         */
        FUND_FIRST_PAGE_BACK(50007, 19, levelMid),
        /**
         * 钱包二次转入--确认转入
         */
        FUND_TURN_IN_COMMIT(50007, 20, levelMid),
        /**
         * 钱包二次转入--完成
         */
        FUND_TURN_IN_FINISH(50007, 21, levelMid),
        /**
         * 钱包二次转入--返回
         */
        FUND_TURN_IN_BACK(50007, 22, levelMid),
        /**
         * 钱包转出--普通转出
         */
        FUND_TURN_OUT_COMMON(50007, 23, levelMid),
        /**
         * 钱包转出--确认转出
         */
        FUND_TURN_OUT_CONFIRM(50007, 25, levelMid),
        /**
         * 钱包转出--快速转出
         */
        FUND_TURN_OUT_QUICKLY(50007, 24, levelMid),
        /**
         * 钱包转出--转出完成
         */
        FUND_TURN_OUT_FINISH(50007, 26, levelMid),
        /**
         * 钱包修改交易密码--修改交易密码--下一步
         */
        FUND_MODIFY_PASSWORD_NEXT(50007, 27, levelMid),
        /**
         * 钱包修改交易密码--修改交易密码--确认
         */
        FUND_MODIFY_PASSWORD_CONFIRM(50007, 28, levelMid),
        /**
         * 钱包忘记交易密码--忘记交易密码--下一步
         */
        FUND_FORGET_PWD_NEXT(50007, 29, levelMid),
        /**
         * 钱包忘记交易密码--忘记交易密码--获取验证码
         */
        FUND_FORGET_PWD_VERIFY(50007, 30, levelMid),
        /**
         * 钱包忘记交易密码--获取验证码成功
         */
        FUND_FORGET_PWD_VERIFY_SUCCESSS(50007, 31, levelMid),
        /**
         * 钱包忘记交易密码--获取验证码成功
         */
        FUND_FORGET_PWD_VERIFY_FAIL(50007, 32, levelMid),
        /**
         * 钱包忘记交易密码--确认
         */
        FUND_FORGET_PWD_VERIFY_CONFIRM(50007, 33, levelMid),
        /**
         * 钱包忘记交易密码--输入新支付密码--确认
         */
        FUND_RESET_NEW_PWD_CONFIRM(50007, 34, levelMid),
        /**
         * 钱包首次转入
         */
        FUND_TURN_IN_FIRST(50007, 40, levelMid),
        /**
         * 钱包转入
         */
        FUND_TURN_IN(50007, 41, levelMid),
        /**
         * 钱包转出
         */
        FUND_TURN_OUT(50007, 42, levelMid),
        /**
         * 小歪钱包-首页菜单入口-我的银行卡
         */
        CLICK_MENU_FUND_MY_BANK(50007, 45, levelMid),
        /**
         * 银行卡列表页-我的银行卡-已绑定银行卡的点击量
         */
        CLICK_MY_BANK(50007, 46, levelMid),
        /**
         * 添加银行卡-转入-选择支付方式（入口1）
         */
        CLICK_ADD_BANK_FOR_TURN_IN(50007, 47, levelMid),
        /**
         * 添加银行卡-银行卡列表页（入口2）
         */
        CLICK_ADD_BANK_FOR_MY_BANK(50007, 48, levelMid),
        /**
         * 添加银行卡-更换银行卡（入口3）
         */
        CLICK_ADD_BANK_FOR_CHANGE_BANK(50007, 49, levelMid),
        /**
         * 添加银行卡-卡号录入（持卡人，卡号）-下一步
         */
        CLICK_NEXT_GET_BANK_INFO(50007, 50, levelMid),
        /**
         * 添加银行卡-卡信息录入（卡类型，手机号）-下一步
         */
        CLICK_NEXT_SMS_IN_ADD_BANK(50007, 51, levelMid),
        /**
         * 添加银行卡-验证码校验-获取验证码
         */
        SEND_SMS_IN_ADD_BANK(50007, 52, levelMid),
        /**
         * 添加银行卡-验证码校验-确认
         */
        CLICK_OK_SEND_SMS_IN_ADD_BANK(50007, 53, levelMid),
        /**
         * 银行卡详情页-右上角菜单-解绑
         */
        CLICK_BC_DETAIL_UNBIND(50007, 54, levelMid),
        /**
         * 银行卡详情页-右上角菜单-设置默认卡
         */
        CLICK_SETTING_DEFAULT_BANK(50007, 55, levelMid),
        /**
         * 新用户开户支付-订单支付页-添加银行卡支付
         */
        CLICK_ADD_BANK_AND_PAY(50007, 57, levelMid),
        /**
         * 新用户开户支付-设置交易密码页-完成
         */
        ADD_BANK_AND_PAY_SET_PWD(50007, 58, levelMid),
        /**
         * 银行卡详情页-右上角菜单-设置默认卡
         */
        CLICK_CHANGE_BANK(50007, 56, levelMid),
        /**
         * 钱包重置密码--结果
         */
        FUND_RESTE_PWD_RESULT(50007, 35, levelMid),
        /**
         * 个人中心－小歪爱贷
         */
        FUND_ENTRANCE_SELF_CENTER(50008,1,levelMid),
        /**
         *收银台（余额不足）－去充值
         */
        FUND_GO_RECHARGE(50008,2,levelMid),
        /**
         *收银台（未开户）－去开通
         */
        FUND_GO_OPEN_ACCOUNT(50008,3,levelMid),
        /**
         *收银台短信验证码确认
         */
        FUND_SMS_CONFIRM(50008,4,levelMid),
        /**
         * 平安wifi登陆页--微信登录按钮点击
         */
        LOGIN_WECHAT(50002, 1, levelMid),
        /**
         * 平安wifi登陆页--微信登录页面返回
         */
        LOGIN_RETURN_FROM_WECHAT(50002, 2, levelMid),
        /**
         * 帐户绑定页--绑定已有平安WiFi账号
         */
        BIND_EXIST_ACCOUNT(50002, 3, levelMid),
        /**
         * 帐户绑定页--立即注册进入平安wifi
         */
        BIND_REGISTER_ACCOUNT(50002, 4, levelMid),
        /**
         * 平安wifi登陆页--一账通登录按钮点击
         */
        LOGIN_YZT(50002, 13, levelMid),
        /**
         * 登录账号绑定或解绑结果
         */
        //RESULT_BIND_UNBIND_ACCOUNT(50002, 12, levelMid),
        /**
         * 一账通登录页面--一账通登录结果(成功)
         */
        LOGIN_YZT_SUCCESS(50002, 15, levelMid),
        /**
         * 一账通返回确认弹窗--显示
         */
        YZT_BACK_DIALOG_SHOW(50002, 17, levelMid),
        /**
         * 一账通返回确认弹窗--点击留下来吧
         */
        YZT_KEEP_STAY(50002, 18, levelMid),
        /**
         * 一账通返回确认弹窗--点击去意已决
         */
        YZT_KEEP_LEAVE(50002, 19, levelMid),
        /**
         * 一帐通授权成功后自动登陆平安WiFi成功
         */
        YZT_AUTO_LOGIN_SUCCESS(50002, 20, levelMid),
        /**
         * 微信授权成功
         */
        WECHAT_AUTH_SUCCESS(50002, 21, levelMid),
        /**
         * 微信授权成功后自动登陆平安WiFi成功
         */
        WECHAT_AUTO_LOGIN_SUCCESS(50002, 22, levelMid),
        /**
         * 悬浮窗设置界面开关有效切换
         */
        FLOATWINDOW_SETTING_SWITCH(20003, 78, levelMid),
        /**
         * 悬浮窗小窗状态切换(未免流、免流中)
         */
        FLOATWINDOW_SMALL_VIEW_STATE_CHANGE(20003, 79, levelMid),
        /**
         * 悬浮窗小窗点击事件(未免流点击、免流中点击)
         */
        FLOATWINDOW_SMALL_VIEW_CLICK(20003, 80, levelMid),
        /**
         * 悬浮窗大窗点击进入平安WIFI
         */
        FLOATWINDOW_BIG_VIEW_ACCESS_WIFI(20003, 81, levelMid),
        /**
         * 悬浮窗大窗点击关闭按钮
         */
        FLOATWINDOW_BIG_VIEW_CLOSE_BTN(20003, 82, levelMid),

        /**
         * “帮我连网”Button隐藏
         */
        HELP_ME_SURF_INTERNET_BTN_HIDE(20004, 3, levelMid),
        /**
         * “帮我连网”Button显示
         */
        HELP_ME_SURF_INTERNET_BTN_SHOW(20004, 4, levelMid),
        /**
         * “帮我连网”Button点击
         */
        HELP_ME_SURF_INTERNET_BTN_CLICK(20004, 5, levelMid),
        /**
         * 首页PV，UV
         */
        DATA_FLOW_CARD_MainFragment(20010, 0, levelMid),
        /*
         * 展示流量卡片成功
         */
        DATA_FLOW_CARD_SHOWING(20010, 1, levelMid),
        /*
         * 点击进入注册页
         */
        DATA_FLOW_CARD_TOREGISTER(20010, 2, levelMid),
        /*
         * 点击右上角广告位
         */
        DATA_FLOW_CARD_RIGHT_AD(20010, 3, levelMid),
        /*
         * 点击中间广告位
         */
        DATA_FLOW_CARD_MID_AD(20010, 4, levelMid),

        /*
         * 点击大冲流量开关
         */
        DATA_FLOW_CARD_SWITCH(20010, 5, levelMid),
        /*
         * 点击手机流量文字广告位
         */
        DATA_FLOW_CARD_PHONE_AD(20010, 6, levelMid),
        /*
         * 手机流量点击进入二级界面区域
         */
        DATA_ALLFLOW_CARD_VPN_H5(20010, 7, levelMid),

        /*
         * 点击手机流量去购买
         */
        DATA_FLOW_CARD_PHONE_TOBUY(20010, 8, levelMid),
        /*
         * 点击手机流量去购买
         */
        DATA_FLOW_CARD_APP_AD(20010, 9, levelMid),

        /*
         * 应用流量点击进入二级界面区域
         */
        DATA_APPFLOW_CARD_VPN_H5(20010, 10, levelMid),

        /*
         * 点击应用流量去购买
         */
        DATA_FLOW_CARD_APP_TOBUY(20010, 11, levelMid),
        /**
         * 刷新余量
         */
        DATA_FLOW_CARD_REFRESH_DATA(20010, 12, levelMid),
        /**
         * 设置
         */
        DATA_FLOW_CARD_SETTING(20010, 13, levelMid),
        /**
         * 帮助
         */
        DATA_FLOW_CARD_HELP(20010, 14, levelMid),
        /**
         * 反馈
         */
        DATA_FLOW_CARD_FEED_BACK(20010, 15, levelMid),
        /**
         * 分享
         */
        DATA_FLOW_CARD_SHARE(20010, 16, levelMid),
        /**
         * 订购
         */
        DATA_FLOW_CARD_ORDER(20010, 17, levelMid),

        /**
         * 卡片收起时标题去购买
         */
        DATA_FLOW_CARD_TITTLE_TOBUY(20010, 18, levelMid),

        /**
         * wifi卡片展现成功
         */
        SHOW_WIFI_CARD(20010, 19, levelMid),

        /**
         * 注册引导曝光
         */
        SHOW_REGISTER_GUIDE(20010, 20, levelMid),

        /**
         * 注册引导点击
         */
        REGISTER_GUIDE_CLICK(20010, 21, levelMid),

        /**
         * 开启wifi失败-wifi未开启场景
         */
        WIFI_DISABLED(20010, 23, levelMid),

        /**
         * 开启wifi失败-开启wifi失败场景
         */
        WIFI_OPEN_FAIL(20010, 24, levelMid),

        /**
         * 开启wifi失败-点"去设置"按钮
         */
        WIFI_OPEN_FAIL_GOTO_SETTING(20010, 25, levelMid),

        /**
         * 附近无wifi场景
         */
        WIFI_LIST_EMPTY_NEW(20010, 26, levelMid),

        /**
         * 开启流量弹窗-取消
         */
        DATA_FLOW_OPEN_FLOW_OK(20010, 27, levelMid),
        /**
         * 开启流量弹窗-切换
         */
        DATA_FLOW_OPEN_FLOW_CANCLE(20010, 28, levelMid),

        /**
         * 开启WiFi弹窗-开启
         */
        DATA_FLOW_OPEN_WIFI_OK(20010, 29, levelMid),

        /**
         * 开启WiFi弹窗-取消
         */
        DATA_FLOW_OPEN_WIFI_CANCLE(20010, 30, levelMid),

        /**
         * 开启WiFi重试弹窗-取消
         */
        DATA_FLOW_OPEN_WIFI_AGAIN_OK(20010, 31, levelMid),

        /**
         * 开启WiFi重试弹窗-重试
         */
        DATA_FLOW_OPEN_WIFI_AGAIN_CANCLE(20010, 32, levelMid),

        /**
         * UDP弹框
         */
        UDP_DIALOG(20010, 33, levelMid),

        /**
         * 附近没有免费WiFi，点击“已帮您充值20M大冲流量，去查看>>”
         */
        NO_FREE_WIFI_CLICK_TO_CHECK(20010, 52, levelMid),

        /**
         * 附近没有免费WiFi，点击“本月累计赠送XXMM大冲流量>>””
         */
        NO_FREE_WIFI_CLICK_TO_SHOW_CARD(20010, 53, levelMid),

        /**
         * 附近没有免费WiFi，领取流量成功
         */
        NO_FREE_WIFI_RECEIVE_FLOW_SUC(20010, 54, levelMid),

        /**
         * 注册送流量2分钟到账点击
         */
        FLOW_ARRIVE_TWO_MINUTE(20010, 63, levelMid),

        /**
         * 注册送流量失败，点击重新充值
         */
        REOBTAIN_FLOW_WHEN_FAILED(20010, 64, levelMid),

        /**
         * 点击首页注册必看使用须知
         */
        HOME_FREE_TO_LINE(20010, 65, levelMid),
        /**
         * 一键连接--平安支持
         */
        ONCLICK_CONNECT_PA(20010, 71, levelMid),
        /**
         * 一键连接--非平安支持
         */
        ONCLICK_CONNECT_NONE_PA(20010, 72, levelMid),
        /**
         * 断开--平安WiFi
         */
        DISCONNECT_PA(20010, 74, levelMid),
        /**
         * 断开--非平安WiFi
         */
        DISCONNECT_NONE_PA(20010, 73, levelMid),
        /**
         * 点击分享
         */
        BTN_CLICK_SHARE_WIFI(20010,75,levelMid),
        /**
         * 首页下拉菜单出现
         */
        HOME_MENU_POP_SHOW(20010,76,levelMid),
        /**
         * 点击首页菜单流量获取记录
         */
        HOME_MENU_FLOW_OBATIN_CLICK(20010,77,levelMid),
        /**
         * 点击首页菜单流量使用记录
         */
        HOME_MENU_FLOW_USED_CLICK(20010,78,levelMid),
        /**
         * 点击首页菜单使用教程
         */
        HOME_MENU_FLOW_HOW_TO_USE_CLICK(20010,79,levelMid),
        /**
         * 未搜索到免费WiFi时，引导用户使用大冲流量
         * ap列表, 点击“地图查看更多免费WiFi”
         */
        DATA_BUY_CLICK_NO_FREE_WIFI(20010,80,levelMid),
        /**
         * 点击流量卡片使用须知
         */
        HOME_MENU_FLOW_USE_NOTES_CLICK(20010,83,levelMid),
        /**
         * 点击大冲流量二级页面H5设置
         */
        FLOW_H5_SETTING_CLICK(20010,84,levelMid),
        /**
         * 首页开启大冲流量开关结果
         */
        HOME_OPEN_VPN_SWITCH_RESULT(20010,85,levelMid),
        /**
         * 推荐频道发起大冲流量请求
         */
        SERVICE_CHANNEL_GET_FLOW(20010, 86, levelMid),
        /**
         * 服务TAB曝光率
         */
        SERVICE_TAB_SHOW(30001, 1, levelMid),

        /**
         * 服务banner被点击
         */
        SERVICE_TAB_BANNER_CLICK(30001, 2, levelMid),

        /**
         * 平安服务被点击
         */
        PA_SERVICE_CLICK(30001, 3, levelMid),

        /**
         * 启动APP
         */
        SYSTEM_START_APP(19000, 1, levelTop),
        /**
         * 退出APP
         */
        SYSTEM_EXIT_APP(19000, 2, levelTop),
        /**
         * APP进入后台
         */
        SYSTEM_RUN_BACKGROUD(19000, 3, levelTop),

        /**
         * 返回App
         */
        SYSTEM_BACK_APP(19000, 4, levelTop),

        /**
         * 开屏广告展示
         */
        LUNCH_AD_SHOW(19001, 5, levelMid),

        /**
         * 开屏广告点击跳过
         */
        LUNCH_AD_CLICK_JUMP(19001, 6, levelMid),

        /**
         * 开屏广告点击广告
         */
        LUNCH_AD_CLICK_AD(19001, 7, levelMid),

        /**
         * 插屏广告点击广告
         */
        INSERT_AD_CLICK_AD(19001, 8, levelMid),

        /**
         * 插屏广告点击关闭
         */
        INSERT_AD_CLICK_CLOSE(19001, 9, levelMid),

        /**
         * 上网TAB显示
         */
        HOME_TAB_SHOW(19002, 1, levelMid),

        /**
         * 点击上网TAB流量仓库
         */
        HOME_TAB_STORE_HOUSE_CLICK(19002, 2, levelMid),

        /**
         * 点击上网TAB消息中心
         */
        HOME_TAB_MSG_CENTER_CLICK(19002, 3, levelMid),

        /**
         * 点击上网TAB注册公告
         */
        HOME_TAB_TOP_UNLOGIN_CLICK(19002, 4, levelMid),


        /**
         * 点击上网TAB公告(登录)
         */
        HOME_TAB_TOP_LOGIN_CLICK(19002, 5, levelMid),


        /**
         * 点击上网TAB底部banner
         */
        HOME_TAB_BANNER_CLICK(19002, 6, levelMid),

        /**
         * 点击上网TAB使用须知
         */
        HOME_TAB_USE_NOTICE_CLICK(19002, 7, levelMid),

        /**
         * 点击上网TAB去购买
         */
        HOME_TAB_TOBUY_CLICK(19002, 11, levelMid),

        /**
         * 点击上网TAB刷新购买流量状态
         */
        HOME_TAB_REFRESH_BUTSTATE_CLICK(19002, 12, levelMid),

        /**
         * 点击上网TAB再试一次
         */
        HOME_TAB_RETRY_CLICK(19002, 13, levelMid),


        /**
         * 点击上网TAB联系客服
         */
        HOME_TAB_CONTACTCUSTOMER_CLICK(19002, 14, levelMid),


        /**
         * 点击上网TAB VPN开关
         */
        HOME_TAB_VPN_BTN_CLICK(19002, 15, levelMid),


        /**
         * 开启VPN失败原因
         */
        START_VPN_FAILED_RESULTCODE(19002, 16, levelTop),

        /**
         * vpn免流量——鉴权成功
         */
        FREE_FLOW_AUTH_SUCCESS_VPN(19002, 17, levelTop),

        /**
         * vpn免流量——导流成功
         */
        FREE_GUIDE_FLOW_SUCCESS_VPN(19002, 18, levelTop),

        /**
         * 已连上wifi弹窗点击取消
         */
        CLICK_WIFI_CONNECTED_POP_CANCLE(19002, 19, levelMid),

        /**
         * 已连上wifi弹窗点击好的
         */
        CLICK_WIFI_CONNECTED_POP_OK(19002, 20, levelMid),

        /**
         * wifi关闭失败弹窗点击去关闭
         */
        CLICK_WIFI_CLOSEFAILED_TO_CLOSE(19002, 21, levelMid),

        /**
         * 移动网络开启失败弹窗点击去打开
         */
        CLICK_NET_OPENFAILED_TO_OPEN(19002, 22, levelMid),

        /**
         * 网络接入点为WAP弹窗点击去修改
         */
        CLICK_IS_WAP_POP_CANCLE(19002, 23, levelMid),


        /**
         * 网络接入点为WAP弹窗点击去修改
         */
        CLICK_IS_WAP_POP_CHANGE(19002, 24, levelMid),


        /**
         * 点击去流量仓库弹窗取消
         */
        CLICK_TO_STOREHOUSE_CANCLE(19002, 25, levelMid),

        /**
         * 点击去流量仓库弹窗前往
         */
        CLICK_TO_STOREHOUSE_GO(19002, 26, levelMid),

        /**
         * 点击没有流量弹窗取消
         */
        CLICK_NO_FLOW_POP_CANCLE(19002, 27, levelMid),

        /**
         * 点击没有流量弹窗前往
         */
        CLICK_NO_FLOW_POP_GO(19002, 28, levelMid),

        /**
         * 使用流量异常
         */
        USE_VPN_ERR(19002, 29, levelMid),


        /**
         * VPN免流量——切换节点成功
         */
        FREE_SWITCH_NODE_SUCCESS_VPN(19002, 30, levelTop),

        /**
         * 点击赚流量频道
         */
        EARN_FLOW_TAB_SHOW(19002, 31, levelMid),

        /**
         * 仓库已有
         */
        FLOW_REMAIN_STORE(19002, 32, levelMid),

        /**
         * 如何赚取
         */
        EARN_FLOW_GUIDE(19002, 33, levelMid),

        /**
         * 赚流量公告位
         */
        EARN_FLOW_TOP_NOTICE(19002, 34, levelMid),

        /**
         * 新闻广告点击
         */
        EARN_FLOW_ITEM_CLICK(19002, 36, levelTop),


        /**
         * 已连上wifi弹窗点击知道了
         */
        CLICK_WIFI_CONNECTED_POP_KNOW(19002, 37, levelMid),

        /**
         * 已连上wifi弹窗点击去赚流量
         */
        CLICK_WIFI_CONNECTED_POP_TO_EARN(19002, 38, levelMid),

        /**
         * 赚流量条目加载失败
         */
        EARN_FLOW_ITEM_LOAD_FAILED(19002, 39, levelTop),

        /**
         * 我频道点击
         */
        SELF_TAB_SHOW(19003, 1, levelMid),

        /**
         * 点击个人中心的消息中心
         */
        CLICK_SELF_MSG_CENTER_GO(19003, 2, levelMid),

        /**
         * 点击个人中心的立刻注册
         */
        CLICK_SELF_IMMEDIATE_REGISTER(19003, 27, levelMid),

        /**
         * 点击个人中心的账号设置
         */
        CLICK_SELF_ACCOUNT_SETTING(19003, 28, levelMid),

        /**
         * 点击个人中心的流量仓库
         */
        CLICK_SELF_FLOW_STORAGE_GO(19003, 29, levelMid),

        /**
         * 点击个人中心流量商城
         */
        CLICK_SELF_FLOW_SHOP_GO(19003, 34, levelMid),

        /**
         * 点击个人中心的历史记录
         */
        CLICK_SELF_HISTORY_RECORD_GO(19003, 35, levelMid),

        /**
         * 点击个人中心的帮助与反馈
         */
        CLICK_SELF_HELP_CENTER_GO(19003, 36, levelMid),

        /**
         * 点击个人中心的我的订单
         */
        CLICK_SELF_ORDERS_GO(19003, 37, levelMid),

        /**
         * 点击个人中心的更多
         */
        CLICK_SELF_MORE_GO(19003, 38, levelMid),

        /**
         * 点击个人中心的邀请有礼
         */
        CLICK_SELF_INVITE_GIFT_GO(19003, 39, levelMid),


        // ===== add 2016.11.18 by hejinyi start
        /**
         * 进入登录页面,页面PV/UV
         */
        CLICK_PERSON_HOME_RECORD_LOGIN_HOME_GO(19003, 3, levelMid),
        /**
         * 进入登录页面,立刻登录
         */
        CLICK_PERSON_HOME_RECORD_LOGIN_NOW_GO(19003, 4, levelMid),
        /**
         * 进入登录页面,密码可见/不可见按钮
         */
        CLICK_PERSON_HOME_RECORD_LOGIN_PWD_VISIBLE_GO(19003, 5, levelMid),
        /**
         * 进入登录页面,忘记密码
         */
        CLICK_PERSON_HOME_RECORD_LOGIN_FORGET_GO(19003, 6, levelMid),
        /**
         * 进入登录页面,第三方登录
         */
        CLICK_PERSON_HOME_RECORD_LOGIN_THIRD_APP_GO(19003, 7, levelMid),
        /**
         * 进入登录页面,持续登录
         */
        CLICK_PERSON_HOME_RECORD_LOGIN_LONG_TIME_GO(19003, 8, levelMid),
        /**
         * 进入登录页面,快速注册
         */
        CLICK_PERSON_HOME_RECORD_LOGIN_REGISTER_GO(19003, 9, levelMid),
        /**
         * 进入注册流程页面,页面PV/UV
         */
        CLICK_PERSON_HOME_RECORD_REGISTER_HOME_GO(19003, 10, levelMid),
        /**
         * 进入注册流程页面,左上角返回按钮--输入手机号码页面
         */
        CLICK_PERSON_HOME_RECORD_REGISTER_BACK_STEP1_GO(19003, 11, levelMid),
        /**
         * 进入注册流程页面,用户服务协议
         */
        CLICK_PERSON_HOME_RECORD_REGISTER_SERVIE_TIPS_GO(19003, 12, levelMid),
        /**
         * 进入注册流程页面,已有账号？立刻登录
         */
        CLICK_PERSON_HOME_RECORD_REGISTER_GOTO_LOGIN_GO(19003, 13, levelMid),
        /**
         * 进入注册流程页面,获取验证码（效果等同下一步）
         */
        CLICK_PERSON_HOME_RECORD_REGISTER_BTN_CODE_NEXT_GO(19003, 14, levelMid),
        /**
         * 进入注册流程页面,左上角返回按钮--输入验证码页面
         */
        CLICK_PERSON_HOME_RECORD_REGISTER_BACK_STEP2_GO(19003, 15, levelMid),
        /**
         * 进入注册流程页面,自动发送验证码
         */
        CLICK_PERSON_HOME_RECORD_REGISTER_SEND_CODE_GO(19003, 16, levelMid),
        /**
         * 进入注册流程页面,重新获取验证码
         */
        CLICK_PERSON_HOME_RECORD_REGISTER_RE_SEND_CODE_GO(19003, 17, levelMid),
        /**
         * 进入注册流程页面,下一步
         */
        CLICK_PERSON_HOME_RECORD_REGISTER_BTN_NEXT_STEP2_GO(19003, 18, levelMid),
        /**
         * 进入注册流程页面,左上角返回按钮--设置密码页面
         */
        CLICK_PERSON_HOME_RECORD_REGISTER_BACK_STEP3_GO(19003, 19, levelMid),
        /**
         * 进入注册流程页面,完成
         */
        CLICK_PERSON_HOME_RECORD_REGISTER_BTN_FINISH_GO(19003, 20, levelMid),
        /**
         * 进入注册流程页面,密码可见/不可见按钮
         */
        CLICK_PERSON_HOME_RECORD_REGISTER_PWD_VISIBLE_GO(19003, 21, levelMid),
        /**
         * 进入找回密码,下一步
         */
        CLICK_PERSON_HOME_RECORD_FIND_PWD_NEXT_GO(19003, 22, levelMid),
        /**
         * 进入找回密码,提交设置
         */
        CLICK_PERSON_HOME_RECORD_FIND_PWD_FINISH_GO(19003, 23, levelMid),
        /**
         * 第三方登录--微信绑定手机号页面--输入手机号
         */
        CLICK_PERSON_HOME_RECORD_BIND_WRITE_PHONE_GO(19003, 24, levelMid),
        /**
         * 第三方登录--微信,绑定手机号页面--下一步
         */
        CLICK_PERSON_HOME_RECORD_BIND_BTN_NEXT_GO(19003, 25, levelMid),
        /**
         * 第三方登录--微信,绑定手机号页面--完成
         */
        CLICK_PERSON_HOME_RECORD_BIND_FINISH_GO(19003, 26, levelMid) ;
        // ===== add 2016.11.18 by hejinyi end



        public int actionId;
        public int processId;
        public int level;
        public String actionInfo;

        Actions(int actionId, int processId, int level) {
            this.actionId = actionId;
            this.processId = processId;
            this.level = level;
        }

        /**
         * get action id
         *
         * @return
         */
        public int getid() {
            return this.actionId;
        }

        /**
         * get data level
         *
         * @return
         */
        public int getLevel() {
            return this.level;
        }

        public int getActionId() {
            return actionId;
        }

        public void setActionId(int actionId) {
            this.actionId = actionId;
        }

        public int getProcessId() {
            return processId;
        }

        public void setProcessId(int processId) {
            this.processId = processId;
        }

        public String getActionInfo() {
            return actionInfo;
        }

        public void setActionInfo(String actionInfo) {
            this.actionInfo = actionInfo;
        }

        public void setLevel(int level) {
            this.level = level;
        }

        @Override
        public String toString() {
            return "[actionId=" + actionId + ", processId=" + processId + ",level=" + level + ",actionInfo="
                    + actionInfo + "]";
        }

    }

}