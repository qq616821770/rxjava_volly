package com.pingan.pinganwifi.wifi;

import android.app.Activity;
import android.content.Context;
import android.text.TextUtils;

import com.pingan.pingandata.PADataConfig;
import com.pingan.pingandata.common.CommonUtils;
import com.umeng.analytics.MobclickAgent;

import java.util.HashMap;

import cn.core.net.Lg;

public class PaTcAgent {

    public static final String EVENT_MAIN = "主页";
    public static final String EVENT_FEEDBACK = "意见反馈";
    public static final String EVENT_REGISTER = "注册页";
    public static final String EVENT_MENU = "菜单";
    public static final String EVENT_FLOW = "流程追踪";
    public static final String EVENT_SHARE = "分享页";
    public static final String EVENT_RECOMMEND = "推荐应用";
    public static final String EVENT_MORE = "更多";
    public static final String EVENT_AROUND = "附近";
    public static final String EVENT_NOTIFY = "通知栏";

    public static final String EVENT_ME = "我";
    public static final String EVENT_LOGIN = "登录";

    public static final String LABEL_U_LOGIN = "点击登录";
    public static final String LABEL_U_MORE = "点击更多";
    public static final String LABEL_U_JFMX = "登陆后_点击积分明细";
    public static final String LABEL_U_SIGN = "登陆后_点击每日签到";
    public static final String LABEL_U_EXCHANGE = "登陆后_点击兑换中心";
    public static final String LABEL_U_TASK = "登陆后_点击做任务换积分";
    public static final String LABEL_U_CANCEL = "登陆前_登陆提示弹窗_取消";
    public static final String LABEL_U_NOWLOGIN = "登陆前_登陆提示弹窗_立即登陆";
    public static final String LABEL_U_LING = "登陆后_签到换积分弹窗_现在去领";
    public static final String LABEL_U_AFTERLING = "登陆后_签到换积分弹窗_稍后再领";
    public static final String LABEL_U_SETTING = "登陆后_点击设置";

    public static final String LABEL_U_HUOQUSUCCESS = "修改手机号_获取验证码成功";
    public static final String LABEL_U_HUOQUFAIL = "修改手机号_获取验证码失败";
    public static final String LABEL_U_YANZHENGSUCCESS = "修改手机号_手机验证成功";
    public static final String LABEL_U_YANZHENGFAIL = "修改手机号_手机验证失败";


    public static final String LABEL_LOGIN_NOWLOGIN = "点击立即登陆";
    public static final String LABEL_LOGIN_FINDPASS = "点击找回密码";
    public static final String LABEL_LOGIN_REGISTER = "点击注册";
    public static final String LABEL_LOGIN_CANCEL = "点击取消";

    public static final String LABEL_LOGIN_ZHAOHUI_HUOQUSUCCESS = "找回密码_获取验证码成功";
    public static final String LABEL_LOGIN_ZHAOHUI_HUOQUFAIL = "找回密码_获取验证码失败";
    public static final String LABEL_LOGIN_ZHAOHUI_YANZHENGSUCCESS = "找回密码_手机验证成功";
    public static final String LABEL_LOGIN_ZHAOHUI_YANZHENGFAIL = "找回密码_手机验证失败";


    public static final String LABEL_REGISTER_LOGIN = "点击登陆";
    public static final String LABEL_REGISTER_CANCEL = "点击取消";
    public static final String LABEL_REGISTER_CODESUCCESS = "获取验证码成功";
    public static final String LABEL_REGISTER_CODEFAIL = "获取验证码失败";
    public static final String LABEL_REGISTER_CHOSECANCEL = "点击协议确认框";
    public static final String LABEL_REGISTER_CLICKXY = "点击协议";
    public static final String LABEL_REGISTER_NEXT = "点击下一步";
    public static final String LABEL_REGISTER_PHONE_CANCEL = "已注册手机号弹窗_取消";
    public static final String LABEL_REGISTER_PHONE_NOWLOGIN = "已注册手机号弹窗_立即登陆";
    public static final String LABEL_REGISTER_REGISTSUCESS = "设置密码_立即注册成功";
    public static final String LABEL_REGISTER_REGISTFAIL = "设置密码_立即注册失败";
    public static final String LABEL_REGISTER_YANZHENGSUCCESS = "手机验证成功";
    public static final String LABEL_REGISTER_YANZHENGFAIL = "手机验证失败";


    public static final String LABEL_HD_MORE = "点击活动更多";
    public static final String LABEL_HD_DETAIL = "点击活动详情";
    public static final String LABEL_TREASURE = "点击挖宝";
    public static final String LABEL_COMFORTACTION = "点击安抚奖励";

    public static final String LABEL_MORE_HOT_HD = "点击更多热门活动";

    public static final String LABEL_AUTO_CONNECT = "自动连接";
    public static final String LABEL_P_AUTO_CONNECT = "点击立即使用后自动连接";

    public static final String LABEL_RECOMMEND = "点击推荐应用";
    public static final String LABEL_MORE = "点击更多";
    public static final String LABEL_SHARE = "点击分享";
    public static final String LABEL_SHARE_CANCEL = "点击分享取消";

    public static final String LABEL_SHARE_WX = "点击微信好友";
    public static final String LABEL_SHARE_WXPYQ = "点击微信朋友圈";
    public static final String LABEL_SHARE_TXT = "点击天下通分享";
    public static final String LABEL_SHARE_TXTPYQ = "点击天下通朋友圈分享";
    public static final String LABEL_SHARE_QQ = "点击QQ分享";
    public static final String LABEL_SHARE_QQZONE = "点击QQ空间分享";
    public static final String LABEL_SHARE_SINA = "点击新浪微博分享";

    public static final String LABEL_MORE_Q = "点击常见问题";
    public static final String LABEL_MORE_N = "点击检测新版本";
    public static final String LABEL_MORE_F = "点击意见反馈";
    public static final String LABEL_MORE_MYF = "点击我的反馈";
    public static final String LABEL_MORE_A = "点击关于我们";

    public static final String LABEL_FEEDBACK_SELECT = "选中选择框";
    public static final String LABEL_FEEDBACK_INPUT = "点击输入框";
    public static final String LABEL_FEEDBACK_COMMIT_OK = "点击提交成功";
    public static final String LABEL_FEEDBACK_COMMIT_FAILED = "点击提交失败";

    public static final String LABEL_REGISTER_P = "点击协议";
    public static final String LABEL_REGISTER_P_C_SELECT = "选中协议确认框";
    public static final String LABEL_REGISTER_P_C_CANCEL = "取消协议确认框";
    public static final String LABEL_REGISTER_P_USE = "点击立即验证";

    public static final String LABEL_F_AUTO_LOGIN_OK = "03自动登录后台成功";
    public static final String LABEL_F_AUTO_LOGIN_NO = "03自动登录后台失败";
    public static final String LABEL_F_WIFI_OPEN_OK = "05开启WLAN成功";
    public static final String LABEL_F_WIFI_OPEN_NO = "05开启WLAN失败";
    public static final String LABEL_F_TRY_AGAIN = "07点击再试一次";
    public static final String LABEL_F_OPEN_3G_YES = "10打开蜂窝移动数据成功";
    public static final String LABEL_F_OPEN_3G_NO = "10打开蜂窝移动数据失败";
    public static final String LABEL_F_MESSAGE_CODE_OK = "11短信验证码发送成功";
    public static final String LABEL_F_MESSAGE_CODE_NO = "11短信验证码发送失败";
    public static final String LABEL_F_VALIDATE_CODE_YES = "12注册成功";
    public static final String LABEL_F_VALIDATE_CODE_NO = "12注册失败";
    public static final String LABEL_F_GETCARDINFO_BEGIN = "13获取上网账号开始";
    public static final String LABEL_F_AUTO_LOGIN2_OK = "16自动登录后台成功";
    public static final String LABEL_F_AUTO_LOGIN2_NO = "16自动登录后台失败";
    public static final String LABEL_F_LOGOUT_AP_EXCEPTION = "18异常断开";
    public static final String LABEL_F_CONNECT_OK_CHANGE = "22换一个";
    public static final String LABEL_F_FISH_OK_SAFETY = "24防钓鱼安全";
    public static final String LABEL_F_FISH_OK_DANGER = "24防钓鱼不安全";
    public static final String LABEL_F_FISH_FAILED = "24防钓鱼失败";
    public static final String LABEL_F_SELECT_SSID = "25界面选择SSID";
    public static final String LABEL_F_NO_REGISTER = "用户未注册";

    public static final String ERROR_NO_NETWORK = "没有网络";
    public static final String LABEL_MAIN_CONNECT_YES = "连接成功";
    public static final String LABEL_MAIN_CONNECT_YES_FISH_ISSAFETY = "连接成功_安全性";
    public static final String LABEL_MAIN_CONNECT_NO = "连接失败";
    public static final String LABEL_MAIN_CONNECT_NO_DETAIL = "连接失败_详细";
    public static final String LABEL_AROUND_AP_LIST = "AP列表";

    public static final String LABEL_N_SEND_FIND = "发送发现WiFi通知";
    public static final String LABEL_N_SEND_CONNECT = "发送已连接WIFI通知";
    public static final String LABEL_N_SEND_ENABLE = "发送可上网WIFI通知";
    public static final String LABEL_N_SEND_DISCONNECT = "发送已断开通知";
    public static final String LABEL_N_SEND_WAKE_UP = "发送沉睡用户唤醒通知";
    public static final String LABEL_N_CLICK_FIND = "点击发现WIFI";
    public static final String LABEL_N_CLICK_CONNECT = "点击已连接WIFI";
    public static final String LABEL_N_CLICK_DISCONNECT = "点击已断开通知";
    public static final String LABEL_N_CLICK_WAKE_UP = "点击沉睡用户唤醒通知";
    public static final String LABEL_N_RECONNECT = "重新连接";
    public static final String LABEL_N_IGNORE_WIFI = "忽略此WIFI";

    private static PaTcAgent instance = new PaTcAgent();
    private Context context;

    public void initialize(Context context) {
        this.context = context.getApplicationContext();
        MobclickAgent.UMAnalyticsConfig umAnalyticsConfig = new MobclickAgent.UMAnalyticsConfig(this.context,
                PADataConfig.getUmengAppKey(),
                CommonUtils.getChannelName(context),
                MobclickAgent.EScenarioType.E_UM_NORMAL);
        MobclickAgent.enableEncrypt(true);

        // 除了生产环境之外，埋点展示日志
        if (!PADataConfig.isPrd()) {
            MobclickAgent.setDebugMode(true);
        }

        try {
            MobclickAgent.startWithConfigure(umAnalyticsConfig);
        } catch (Exception e) {
            Lg.e("初始化统计组件异常", e);
        }
    }

    public static PaTcAgent getInstance() {
        return instance;
    }

    public static void onResume(Activity activity) {
        MobclickAgent.onResume(activity);
    }

    public static void onPause(Activity activity) {
        MobclickAgent.onPause(activity);
    }

    public static void trackUserId(String openid) {
        // TCAgent.onEvent(context, "_td_account", openid);
    }

    public static void onEvent(String eventId) {
        onEvent(eventId, null);
    }

    public static void onEvent(String eventId, String label) {
        onEvent(eventId, label, null);
    }

    public static void onEvent(String eventId, String label, String error) {
        onEvent(eventId, label, error, null, null);
    }

    public static void onEvent(String eventId, String label, String error, String ssid, String carr) {
        onEvent(eventId, label, error, ssid, carr, null);
    }

    public static void onEvent(String eventId, String label, String error, String ssid, String carr,
                               String card) {
        onEvent(eventId, label, error, ssid, carr, card, null, null, null);
    }

    public static void onEvent(String eventId, String label, String error, String ssid, String carr,
                               String card, String selectedContent, String exparm, String macAddress) {
        HashMap<String, String> maps = new HashMap<String, String>();
        if (!TextUtils.isEmpty(error)) {
            maps.put("失败原因", error);
        }
        if (!TextUtils.isEmpty(ssid)) {
            maps.put("SSID", ssid);
        }
        if (!TextUtils.isEmpty(carr)) {
            maps.put("供应商信息", carr);
        }
        if (!TextUtils.isEmpty(card)) {
            maps.put("供应商账号信息", card);
        }
        if (!TextUtils.isEmpty(selectedContent)) {
            maps.put("选择内容", selectedContent);
        }

        if (!TextUtils.isEmpty(exparm)) {
            maps.put("防钓鱼随机数", exparm);
        }
        if (!TextUtils.isEmpty(macAddress)) {
            maps.put("BSSID", macAddress);
        }

        // TCAgent.onEvent(context, eventId, label, maps);
    }
}