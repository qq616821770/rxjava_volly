package com.pingan.pinganwifi.data.umeng;

import android.content.Context;
import android.text.TextUtils;

import com.umeng.analytics.MobclickAgent;

/**
 * Created by yueang on 2016/11/22.
 */

public class UMengAnalysisWrapper {

    public static void onEvent(Context context, int actionId, int processId, String actionInfo) {
        if (TextUtils.isEmpty(actionInfo)) {
            MobclickAgent.onEvent(context, String.format("%d_%d", actionId, processId));
        } else {
            MobclickAgent.onEvent(context, String.format("%d_%d", actionId, processId), actionInfo);
        }
    }
}
