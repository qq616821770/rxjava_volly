package com.pingan.pinganwifi.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.paic.pdi.logger.protobuf.ActionV2ProtoBuf.ActionV2Message;
import com.pingan.pinganwifi.data.DataRecordType.Actions;
import com.pingan.pinganwifi.data.umeng.UMengAnalysisWrapper;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import cn.core.net.Lg;
import cn.core.net.secure.Base64;

/**
 * @author tangxun E-mail:tangxun@pingan.com.cn
 * @version 1.1.0 actions data table
 */
public class DataRecordSQL {

    private static final Object lock = new Object();
    DataRecordDBHelper dbHelper = null;
    private Context context;

    private static final String sTableName = DataRecordDBHelper.sTableName;

    public void setmUid(String mUid) {
        this.mUid = mUid;
    }

    private String mUid;

    public DataRecordSQL(Context context) {
        this.context = context.getApplicationContext();
        dbHelper = new DataRecordDBHelper(this.context);
    }

    protected void addActionList(List<Actions> actionList) {
        synchronized (lock) {
            SQLiteDatabase db = null;
            try {
                db = dbHelper.getWritableDatabase();
                for (Actions actions : actionList) {
                    doInsert(actions, db);
                }
            } catch (Exception e) {
                Lg.e(this + " addActoinList error ", e);
            }
        }
    }

    /**
     * delete data with id
     *
     * @param ids
     * @return
     */
    public boolean deletActionWithId(String[] ids) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        int result = 0;
        try {
            String idstr = "";
            for (int i = 0; i < ids.length; i++) {
                result += db.delete(sTableName, "_id=?", new String[]{ids[i]});
                idstr += ids[i] + " ";
            }
            Lg.i("deletActionWithId  id is [" + idstr + "]");
        } catch (Exception e) {
            Lg.e(this + " deletActionWithId ", e);
        }
        return result >= ids.length ? true : false;
    }

    /**
     * delete data with id
     *
     * @param ids
     * @return
     */
    public boolean deletActionWithId(List<Integer> ids) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        int result = 0;
        try {
            for (int i = 0; i < ids.size(); i++) {
                result += db.delete(sTableName, "_id=?", new String[]{String.valueOf(ids.get(i))});
            }
        } catch (Exception e) {
            Lg.e(this + " deletActionWithId ", e);
        }
        return result >= ids.size() ? true : false;
    }

    /**
     * get data row size
     *
     * @return
     */
    public int getRowCount() {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        String[] columns = {"_id"};
        int rowCount = 0;
        Cursor cursor = null;
        try {
            cursor = db.query(sTableName, columns, null, null, null, null, null);
            if (cursor != null) {
                rowCount = cursor.getCount();
            }
        } catch (Exception e) {
            Lg.e(this + " getRowCount ", e);
        } finally {
            try {
                if (cursor != null) {
                    cursor.close();
                }
            } catch (Exception e) {
                Lg.e("Ignore Exception close error ", e);
            }
        }
        return rowCount;
    }

    /**
     * get data row size
     *
     * @return
     */
    public int getRowCountWithLevel(int level) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        String[] columns = {"_id"};
        int rowCount = 0;
        Cursor cursor = null;
        try {
            String selection = "level=?";
            cursor = db.query(sTableName, columns, selection, new String[]{String.valueOf(level)}, null, null, null);
            rowCount = cursor.getCount();
        } catch (Exception e) {
            Lg.e(this + " getRowCount ", e);
        } finally {
            try {
                if (cursor != null) {
                    cursor.close();
                }
            } catch (Exception e) {
                Lg.e("Ignore Exception close error ", e);
            }
        }
        return rowCount;
    }

    public ActionV2Message getTopAction() {
        SQLiteDatabase db = null;
        Cursor cursor = null;
        ActionV2Message actionInfo = null;
        try {
            db = dbHelper.getWritableDatabase();
            String[] columns = {"actioninfo"};
            cursor = db.query(sTableName, columns, null, null, null, null, "_id desc", "1");
            while (cursor != null && cursor.moveToNext()) {
                String _actionInfo = cursor.getString(0);
                actionInfo = ActionV2Message.parseFrom(Base64.decode(_actionInfo));
            }
        } catch (Exception e) {
            Lg.e(this + " getTopActions error " + e.getMessage(), e);
        } finally {
            try {
                if (cursor != null) {
                    cursor.close();
                }
            } catch (Exception e) {
                Lg.e("Ignore Exception close error ", e);
            }
        }
        return actionInfo;
    }

    public Map<Integer, String> getTopActions(int count) {
        SQLiteDatabase db = null;
        Map<Integer, String> actionsMap = new HashMap<Integer, String>();
        Cursor cursor = null;
        try {
            String[] columns = {"_id", "actioninfo",};
            db = dbHelper.getReadableDatabase();
            cursor = db.query(sTableName, columns, null, null, null, null, null, String.valueOf(count));
            while (cursor != null && cursor.moveToNext()) {
                actionsMap.put(cursor.getInt(0), cursor.getString(1));
            }
        } catch (Exception e) {
            Lg.e(e);
        } finally {
            try {
                if (cursor != null) {
                    cursor.close();
                }
            } catch (Exception e) {
                Lg.e("Ignore Exception close error ", e);
            }
        }
        return actionsMap;
    }

    /**
     * getAction list with level
     *
     * @param level -1/0/1
     * @return
     */
    public Map<Integer, String> getTopActionWithLevel(int level, int count) {
        SQLiteDatabase db = null;
        Map<Integer, String> actionMap = new HashMap<Integer, String>();
        Cursor cursor = null;
        try {
            String[] columns = {"_id", "actioninfo"};
            String selection = "level=?";
            String[] selectionArgs = {String.valueOf(level)};
            db = dbHelper.getReadableDatabase();
            cursor = db.query(sTableName, columns, selection, selectionArgs, null, null, null, String.valueOf(count));
            while (cursor != null && cursor.moveToNext()) {
                actionMap.put(cursor.getInt(0), cursor.getString(1));
            }
        } catch (Exception e) {
            Lg.e(e);
        } finally {
            try {
                if (cursor != null) {
                    cursor.close();
                }
            } catch (Exception e) {
                Lg.e("Ignore Exception close error ", e);
            }
        }
        return actionMap;
    }

    public List<Integer> getTopIds(int count) {
        SQLiteDatabase db = null;
        List<Integer> idList = null;
        Cursor cursor = null;
        try {
            db = dbHelper.getWritableDatabase();
            String[] columns = {"_id"};
            String selection = "level<?";
            String[] selectionArgs = new String[]{String.valueOf(DataRecordType.levelTop)};
            cursor = db.query(sTableName, columns, selection, selectionArgs, null, null, null, String.valueOf(count));
            idList = new ArrayList<Integer>();

            while (cursor.moveToNext()) {
                idList.add(cursor.getInt(0));
            }
        } catch (Exception e) {
            Lg.e(this + " getTopActions error " + e.getMessage(), e);
        } finally {
            try {
                if (cursor != null) {
                    cursor.close();
                }
            } catch (Exception e) {
                Lg.e("Ignore Exception close error ", e);
            }
        }
        return idList;
    }

    protected void addAction(DataRecordType.Actions actions) {
        Lg.i(this + " addAction " + actions.name() + " " + actions.toString());
        SQLiteDatabase db = null;
        try {
            UMengAnalysisWrapper.onEvent(context, actions.actionId,
                    actions.processId, actions.actionInfo);
            db = dbHelper.getWritableDatabase();
            doInsert(actions, db);
        } catch (Exception e) {
            Lg.e(this + " addAction error ", e);
        }
    }

    protected void addAction(DataAction actions) {
        Lg.i(this + " addAction " + actions.toString());
        SQLiteDatabase db = null;
        try {
            UMengAnalysisWrapper.onEvent(context, actions.getActionId(),
                    actions.getProcessId(), actions.getActionInfo());
            db = dbHelper.getWritableDatabase();
            doInsert(actions, db);
        } catch (Exception e) {
            Lg.e(this + " addAction error ", e);
        }
    }

    /**
     * db insert
     *
     * @param actions
     * @param db
     */
    private void doInsert(DataRecordType.Actions actions, SQLiteDatabase db) {
        ContentValues values = new ContentValues();
        ActionV2Message.Builder builder = ActionV2Message.newBuilder();
        builder.setActionId(Integer.valueOf(actions.getActionId()));
        builder.setProcessId(Integer.valueOf(actions.getProcessId()));
        builder.setActionInfo(actions.getActionInfo());
        builder.setTimestamp(String.valueOf(System.currentTimeMillis()));
        builder.setPosition(AppInfo.getInstance().getLocation());
        builder.setUid(AppInfo.getInstance().getUid());
        String actionInfo = Base64.encode(builder.build().toByteArray());
        values.put("level", actions.level);
        values.put("actioninfo", actionInfo);
        db.insert(sTableName, null, values);
    }

    /**
     * db insert
     *
     * @param action
     * @param db
     */
    private void doInsert(DataAction action, SQLiteDatabase db) {
        ContentValues values = new ContentValues();
        ActionV2Message.Builder builder = ActionV2Message.newBuilder();
        builder.setActionId(action.getActionId());
        builder.setProcessId(action.getProcessId());
        builder.setActionInfo(action.getActionInfo());
        builder.setTimestamp(String.valueOf(System.currentTimeMillis()));
        builder.setPosition(AppInfo.getInstance().getLocation());
        builder.setUid(AppInfo.getInstance().getUid());
        String actionInfo = Base64.encode(builder.build().toByteArray());
        values.put("level", action.getLevel());
        values.put("actioninfo", actionInfo);
        db.insert(sTableName, null, values);
    }

}
