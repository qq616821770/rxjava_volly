package com.pingan.pinganwifi.data;


import android.content.Context;

import com.pingan.ak.component.bus.BaseBusEvent;
import com.pingan.ak.component.bus.RxBus;
import com.pingan.pingandata.common.CommonUtils;
import com.pingan.pingandata.location.Location;

import org.json.JSONObject;

import cn.core.net.Lg;
import rx.functions.Action1;

/**
 * 全局的APP信息，暂时的设计，应该解耦
 * Created by yueang on 16/10/13.
 */

public class AppInfo {

    private static volatile AppInfo instance = null;
    private static Object lock = new Object();

    private int versionCode = 0;
    private String version = "";
    private String channel;
    private String deviceType = "ANDROID";
    private String product = "PADT";
    private String uid = "";

    private String location = "";

    public static AppInfo getInstance() {
        if (instance == null) {
            synchronized (lock) {
                if (instance == null) {
                    instance = new AppInfo();
                }
            }
        }

        return instance;
    }

    public void initialize(Context context, String uidStr) {
        versionCode = CommonUtils.getVersionCode(context);
        version = CommonUtils.getVersionName(context);
        channel = CommonUtils.getChannelName(context);
        uid = uidStr == null ? "" : uidStr;
        RxBus.getInstance().toObservable(BaseBusEvent.LoginEvent.class)
                .subscribe(new Action1<BaseBusEvent.LoginEvent>() {
            @Override
            public void call(BaseBusEvent.LoginEvent loginEvent) {
                int loginState = loginEvent.getLoginState();
                if (loginState == BaseBusEvent.LoginEvent.LOGIN_STATE_SUCESS) {
                    uid = loginEvent.getUid() + "";
                } else {
                    uid = "";
                }
            }
        });

        RxBus.getInstance().toObservable(BaseBusEvent.LocationUpdateEvent.class)
                .subscribe(new Action1<BaseBusEvent.LocationUpdateEvent>() {
            @Override
            public void call(BaseBusEvent.LocationUpdateEvent locationUpdateEvent) {
                Location location = locationUpdateEvent.getLocation();

                JSONObject locationJson = new JSONObject();
                if (location != null) {
                    try {
                        locationJson.put("type", location.getType());
                        locationJson.put("longgitude", Double.parseDouble(location.getLongitude()));
                        locationJson.put("latitude", Double.parseDouble(location.getLatitude()));
                    } catch (Exception e) {
                    }
                }

                AppInfo.this.location = locationJson.toString();
            }
        });
    }

    public int getVersionCode() {
        return versionCode;
    }

    public String getVersion() {
        return version;
    }

    public String getChannel() {
        return channel;
    }

    public String getDeviceType() {
        return deviceType;
    }

    public String getProduct() {
        return product;
    }

    public String getUid() {
        return uid;
    }

    public String getLocation() {
        return location;
    }

    public void setVersionCode(int versionCode) {
        this.versionCode = versionCode;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public void setChannel(String channel) {
        this.channel = channel;
    }

    public void setDeviceType(String deviceType) {
        this.deviceType = deviceType;
    }

    public void setProduct(String product) {
        this.product = product;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }
}
