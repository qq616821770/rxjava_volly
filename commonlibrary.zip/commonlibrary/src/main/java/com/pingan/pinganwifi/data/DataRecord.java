package com.pingan.pinganwifi.data;

import android.content.Context;

import com.paic.pdi.logger.protobuf.ActionV2ProtoBuf.ActionV2Message;
import com.pingan.pinganwifi.data.DataRecordType.Actions;

import org.json.JSONException;
import org.json.JSONObject;

import cn.core.net.Lg;

/**
 * record user action data
 *
 * @author tangxun E-mail:tangxun325@pingan.com.cn
 * @version 1.1.0
 */
public class DataRecord {

    private static DataRecord instance = null;

    private DataRecordSQL drsql;

    private Context mContext;

    private boolean isInited;

    public static synchronized DataRecord getInstance() {
        if (instance == null) {
            instance = new DataRecord();
        }
        return instance;
    }

    public void init(Context context) {
        if (!isInited) {
            this.mContext = context.getApplicationContext();
            drsql = new DataRecordSQL(mContext);
            isInited = true;
        }
    }

    private DataRecord() {
    }

    /**
     * check whether call init before,if not throw IllegalStateException
     */
    private void checkInit() {
        if (!isInited) {
            throw new IllegalStateException("not inited pls call init(Context context) first");
        }
    }

    /**
     * record an action
     *
     * @param action Actions
     * @param actionInfo Actions.actionInfo
     */
    public void recordAction(Actions action, String actionInfo) {
        checkInit();
        action.setActionInfo(actionInfo);
        drsql.addAction(action);
    }

    public void recordActionJson(Actions action, String key, String value) {
        checkInit();
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put(key,value);
            action.setActionInfo(jsonObject.toString());
        } catch (JSONException e) {
            Lg.w(e);
        }
        drsql.addAction(action);
    }

    public void recordActionJson(Actions action, String key, String value, String key2, String value2) {
        checkInit();
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put(key,value);
            jsonObject.put(key2,value2);
            action.setActionInfo(jsonObject.toString());
        } catch (JSONException e) {
            Lg.w(e);
        }
        drsql.addAction(action);
    }

    public void recordAction(DataAction action) {
        checkInit();
        drsql.addAction(action);
    }

    public ActionV2Message getTopActions() {
        checkInit();
        return drsql.getTopAction();
    }


}