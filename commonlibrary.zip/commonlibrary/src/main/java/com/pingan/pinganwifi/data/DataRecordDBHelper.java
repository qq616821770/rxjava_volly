package com.pingan.pinganwifi.data;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteOpenHelper;

import cn.core.net.Lg;

/**
 * @author tangxun E-mail:tangxun@pingan.com.cn
 * @version 1.1.0 actions data table -------------------------- |_id |
 *          actioninfo | level | --------------------------
 */
public class DataRecordDBHelper extends SQLiteOpenHelper {

	public static final String sDbName = "com_pingan_pinganwifi_action_database.db";
	public static final String sTableName = "table_actons";
    public static final String CREATE_ACTONS = "create table if not exists " + sTableName + "("
            + "_id integer primary key autoincrement," + "actioninfo text," + "level integer" + ")";


	// 增加UID字段
	private static final int version = 2015072201; // 上个版本：2015071801

	public DataRecordDBHelper(Context context) {
		super(context, sDbName, null, version);
	}

	/**
	 * @param context
	 * @param name
	 * @param factory
	 * @param version
	 */
	public DataRecordDBHelper(Context context, String name,
							  CursorFactory factory, int version) {
		super(context, name, factory, version);
		context.openOrCreateDatabase(sDbName, Context.MODE_PRIVATE, factory);
	}

	@Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_ACTONS);
    }

	@Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        Lg.i(this + " onUpgrade oldVersion " + oldVersion + " newVersion" + newVersion);
        db.execSQL("drop table if exists " + sTableName);
        db.execSQL(CREATE_ACTONS);
    }

}
