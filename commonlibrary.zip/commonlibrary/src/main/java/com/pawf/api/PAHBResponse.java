package com.pawf.api;

import java.util.Map;

import cn.core.net.Lg;

/**
 * Created by hexiaohong on 16/9/28.
 */
public class PAHBResponse {

    public Map<String, Object> header;

    public String body;

    public boolean isOK() {
        return code() == 200;
    }

    public int code() {
        if (header != null) {
            String code = (String) header.get("code");
            if (code != null) {
                try {
                    return Integer.valueOf(code);
                } catch (NumberFormatException e) {
                    Lg.w(e);
                }
            }
        }
        return 0;
    }

    public String msg() {
        if (header != null) {
            return (String) header.get("msg");
        }
        return null;
    }

    public boolean expire() {
        return code() == 602;
    }

    /**
     * 返回string类型的body数据，其他类型直接使用body成员变量，自行转换
     */
    public String bodyString() {
        if (body != null) {
            if (body instanceof String) {
                return (String) body;
            }
        }
        return null;
    }
}
