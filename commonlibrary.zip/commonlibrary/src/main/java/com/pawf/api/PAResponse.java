package com.pawf.api;

import cn.core.net.Lg;

/**
 * Created by hexiaohong on 16/8/18.
 */
public class PAResponse {

    public String code;

    public String msg;

    public boolean isOK() {
        return code() == 200;
    }

    public int code() {
        if (code != null) {
            try {
                return Integer.valueOf(code);
            } catch (NumberFormatException e) {
                Lg.w(e);
            }
        }
        return 0;
    }

    public String msg() {
        return msg;
    }

    public boolean expire() {
        return code() == 602;
    }
}
