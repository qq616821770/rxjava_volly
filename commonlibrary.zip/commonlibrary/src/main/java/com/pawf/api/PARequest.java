package com.pawf.api;

import android.support.annotation.Keep;

import com.paic.pdi.logger.protobuf.ActionV2ProtoBuf;
import com.pingan.ak.component.net.http.BaseOkHttpRequest;
import com.pingan.ak.component.net.http.IRequestCallBack;
import com.pingan.pinganwifi.data.AppInfo;
import com.pingan.pinganwifi.data.DataRecord;

import cn.core.net.Lg;


/**
 * Created by hexiaohong on 16/8/18.
 */
public abstract class PARequest<T> extends BaseOkHttpRequest<T> {

//    static {
//        DEBUG = !"prd".equals(PAConfig.getConfig("CONFIG_TAG"));
//    }

    @Keep
    public PARequest(Class<T> clazz, IRequestCallBack<T> callback) {
        super(clazz, callback);
    }

    @Override
    protected void setDefaultReqHeader() {
        super.setDefaultReqHeader();

        // TODO: 暂时沿用以前的实现，但数据关联性太强，需要整改

        int actionId = 0, processId = 0;
        try {
            ActionV2ProtoBuf.ActionV2Message action = DataRecord.getInstance().getTopActions();
            if (action != null) {
                actionId = action.getActionId();
                processId = action.getProcessId();
            }
        } catch (Exception e) {
            Lg.w(e);
        }

        addHead("actionid", String.valueOf(actionId));
        addHead("processid", String.valueOf(processId));

        addHead("channel", AppInfo.getInstance().getChannel());
        addHead("deviceType", AppInfo.getInstance().getDeviceType());
        addHead("product", AppInfo.getInstance().getProduct());
        addHead("version", AppInfo.getInstance().getVersion());
    }
}
