//
// Created by yueang on 16/10/3.
//

#include <jni.h>
#include <android/log.h>
#include <string.h>

// Use system API to get APP's signature and package name, compare the two things
// with predefined appSignature and appPackageName
jboolean isValidAPK(JNIEnv *pEnv, jobject pJobject, jboolean isPrd);

jboolean checkPrd(JNIEnv *pEnv, jstring environment, unsigned char *pLogSwitch);

const char *getDes3SecureKey(JNIEnv *env, jstring keyType, jboolean isPrd);

const char *getSha1SecureKey(JNIEnv *env, jstring keyType, jboolean isPrd);

//jboolean isEqualsIgnoreCase(JNIEnv *pEnv, jstring jstring1, jstring jstring2);

jboolean isEquals(const char char1[], const char char2[], int size, int sizeLocal);

void log(const char *msg);
char signatureStg[] = {(char) 0x33, (char) 0x30, (char) 0x38, (char) 0x32, (char) 0x30, (char) 0x31,
                       (char) 0x65, (char) 0x35, (char) 0x33, (char) 0x30, (char) 0x38, (char) 0x32,
                       (char) 0x30, (char) 0x31, (char) 0x34, (char) 0x65, (char) 0x61, (char) 0x30,
                       (char) 0x30, (char) 0x33, (char) 0x30, (char) 0x32, (char) 0x30, (char) 0x31,
                       (char) 0x30, (char) 0x32, (char) 0x30, (char) 0x32, (char) 0x30, (char) 0x34,
                       (char) 0x35, (char) 0x32, (char) 0x36, (char) 0x62, (char) 0x66, (char) 0x30,
                       (char) 0x38, (char) 0x30, (char) 0x33, (char) 0x30, (char) 0x30, (char) 0x64,
                       (char) 0x30, (char) 0x36, (char) 0x30, (char) 0x39, (char) 0x32, (char) 0x61,
                       (char) 0x38, (char) 0x36, (char) 0x34, (char) 0x38, (char) 0x38, (char) 0x36,
                       (char) 0x66, (char) 0x37, (char) 0x30, (char) 0x64, (char) 0x30, (char) 0x31,
                       (char) 0x30, (char) 0x31, (char) 0x30, (char) 0x35, (char) 0x30, (char) 0x35,
                       (char) 0x30, (char) 0x30, (char) 0x33, (char) 0x30, (char) 0x33, (char) 0x37,
                       (char) 0x33, (char) 0x31, (char) 0x30, (char) 0x62, (char) 0x33, (char) 0x30,
                       (char) 0x30, (char) 0x39, (char) 0x30, (char) 0x36, (char) 0x30, (char) 0x33,
                       (char) 0x35, (char) 0x35, (char) 0x30, (char) 0x34, (char) 0x30, (char) 0x36,
                       (char) 0x31, (char) 0x33, (char) 0x30, (char) 0x32, (char) 0x35, (char) 0x35,
                       (char) 0x35, (char) 0x33, (char) 0x33, (char) 0x31, (char) 0x31, (char) 0x30,
                       (char) 0x33, (char) 0x30, (char) 0x30, (char) 0x65, (char) 0x30, (char) 0x36,
                       (char) 0x30, (char) 0x33, (char) 0x35, (char) 0x35, (char) 0x30, (char) 0x34,
                       (char) 0x30, (char) 0x61, (char) 0x31, (char) 0x33, (char) 0x30, (char) 0x37,
                       (char) 0x34, (char) 0x31, (char) 0x36, (char) 0x65, (char) 0x36, (char) 0x34,
                       (char) 0x37, (char) 0x32, (char) 0x36, (char) 0x66, (char) 0x36, (char) 0x39,
                       (char) 0x36, (char) 0x34, (char) 0x33, (char) 0x31, (char) 0x31, (char) 0x36,
                       (char) 0x33, (char) 0x30, (char) 0x31, (char) 0x34, (char) 0x30, (char) 0x36,
                       (char) 0x30, (char) 0x33, (char) 0x35, (char) 0x35, (char) 0x30, (char) 0x34,
                       (char) 0x30, (char) 0x33, (char) 0x31, (char) 0x33, (char) 0x30, (char) 0x64,
                       (char) 0x34, (char) 0x31, (char) 0x36, (char) 0x65, (char) 0x36, (char) 0x34,
                       (char) 0x37, (char) 0x32, (char) 0x36, (char) 0x66, (char) 0x36, (char) 0x39,
                       (char) 0x36, (char) 0x34, (char) 0x32, (char) 0x30, (char) 0x34, (char) 0x34,
                       (char) 0x36, (char) 0x35, (char) 0x36, (char) 0x32, (char) 0x37, (char) 0x35,
                       (char) 0x36, (char) 0x37, (char) 0x33, (char) 0x30, (char) 0x31, (char) 0x65,
                       (char) 0x31, (char) 0x37, (char) 0x30, (char) 0x64, (char) 0x33, (char) 0x31,
                       (char) 0x33, (char) 0x33, (char) 0x33, (char) 0x31, (char) 0x33, (char) 0x30,
                       (char) 0x33, (char) 0x32, (char) 0x33, (char) 0x36, (char) 0x33, (char) 0x31,
                       (char) 0x33, (char) 0x36, (char) 0x33, (char) 0x34, (char) 0x33, (char) 0x30,
                       (char) 0x33, (char) 0x33, (char) 0x33, (char) 0x32, (char) 0x35, (char) 0x61,
                       (char) 0x31, (char) 0x37, (char) 0x30, (char) 0x64, (char) 0x33, (char) 0x34,
                       (char) 0x33, (char) 0x33, (char) 0x33, (char) 0x31, (char) 0x33, (char) 0x30,
                       (char) 0x33, (char) 0x31, (char) 0x33, (char) 0x39, (char) 0x33, (char) 0x31,
                       (char) 0x33, (char) 0x36, (char) 0x33, (char) 0x34, (char) 0x33, (char) 0x30,
                       (char) 0x33, (char) 0x33, (char) 0x33, (char) 0x32, (char) 0x35, (char) 0x61,
                       (char) 0x33, (char) 0x30, (char) 0x33, (char) 0x37, (char) 0x33, (char) 0x31,
                       (char) 0x30, (char) 0x62, (char) 0x33, (char) 0x30, (char) 0x30, (char) 0x39,
                       (char) 0x30, (char) 0x36, (char) 0x30, (char) 0x33, (char) 0x35, (char) 0x35,
                       (char) 0x30, (char) 0x34, (char) 0x30, (char) 0x36, (char) 0x31, (char) 0x33,
                       (char) 0x30, (char) 0x32, (char) 0x35, (char) 0x35, (char) 0x35, (char) 0x33,
                       (char) 0x33, (char) 0x31, (char) 0x31, (char) 0x30, (char) 0x33, (char) 0x30,
                       (char) 0x30, (char) 0x65, (char) 0x30, (char) 0x36, (char) 0x30, (char) 0x33,
                       (char) 0x35, (char) 0x35, (char) 0x30, (char) 0x34, (char) 0x30, (char) 0x61,
                       (char) 0x31, (char) 0x33, (char) 0x30, (char) 0x37, (char) 0x34, (char) 0x31,
                       (char) 0x36, (char) 0x65, (char) 0x36, (char) 0x34, (char) 0x37, (char) 0x32,
                       (char) 0x36, (char) 0x66, (char) 0x36, (char) 0x39, (char) 0x36, (char) 0x34,
                       (char) 0x33, (char) 0x31, (char) 0x31, (char) 0x36, (char) 0x33, (char) 0x30,
                       (char) 0x31, (char) 0x34, (char) 0x30, (char) 0x36, (char) 0x30, (char) 0x33,
                       (char) 0x35, (char) 0x35, (char) 0x30, (char) 0x34, (char) 0x30, (char) 0x33,
                       (char) 0x31, (char) 0x33, (char) 0x30, (char) 0x64, (char) 0x34, (char) 0x31,
                       (char) 0x36, (char) 0x65, (char) 0x36, (char) 0x34, (char) 0x37, (char) 0x32,
                       (char) 0x36, (char) 0x66, (char) 0x36, (char) 0x39, (char) 0x36, (char) 0x34,
                       (char) 0x32, (char) 0x30, (char) 0x34, (char) 0x34, (char) 0x36, (char) 0x35,
                       (char) 0x36, (char) 0x32, (char) 0x37, (char) 0x35, (char) 0x36, (char) 0x37,
                       (char) 0x33, (char) 0x30, (char) 0x38, (char) 0x31, (char) 0x39, (char) 0x66,
                       (char) 0x33, (char) 0x30, (char) 0x30, (char) 0x64, (char) 0x30, (char) 0x36,
                       (char) 0x30, (char) 0x39, (char) 0x32, (char) 0x61, (char) 0x38, (char) 0x36,
                       (char) 0x34, (char) 0x38, (char) 0x38, (char) 0x36, (char) 0x66, (char) 0x37,
                       (char) 0x30, (char) 0x64, (char) 0x30, (char) 0x31, (char) 0x30, (char) 0x31,
                       (char) 0x30, (char) 0x31, (char) 0x30, (char) 0x35, (char) 0x30, (char) 0x30,
                       (char) 0x30, (char) 0x33, (char) 0x38, (char) 0x31, (char) 0x38, (char) 0x64,
                       (char) 0x30, (char) 0x30, (char) 0x33, (char) 0x30, (char) 0x38, (char) 0x31,
                       (char) 0x38, (char) 0x39, (char) 0x30, (char) 0x32, (char) 0x38, (char) 0x31,
                       (char) 0x38, (char) 0x31, (char) 0x30, (char) 0x30, (char) 0x39, (char) 0x65,
                       (char) 0x32, (char) 0x64, (char) 0x35, (char) 0x30, (char) 0x62, (char) 0x66,
                       (char) 0x61, (char) 0x33, (char) 0x32, (char) 0x63, (char) 0x31, (char) 0x36,
                       (char) 0x61, (char) 0x33, (char) 0x36, (char) 0x38, (char) 0x36, (char) 0x61,
                       (char) 0x63, (char) 0x62, (char) 0x30, (char) 0x34, (char) 0x65, (char) 0x62,
                       (char) 0x61, (char) 0x66, (char) 0x34, (char) 0x37, (char) 0x65, (char) 0x31,
                       (char) 0x33, (char) 0x31, (char) 0x64, (char) 0x66, (char) 0x33, (char) 0x31,
                       (char) 0x31, (char) 0x35, (char) 0x37, (char) 0x37, (char) 0x65, (char) 0x63,
                       (char) 0x37, (char) 0x34, (char) 0x37, (char) 0x39, (char) 0x61, (char) 0x65,
                       (char) 0x32, (char) 0x65, (char) 0x61, (char) 0x38, (char) 0x39, (char) 0x39,
                       (char) 0x65, (char) 0x63, (char) 0x66, (char) 0x64, (char) 0x62, (char) 0x39,
                       (char) 0x34, (char) 0x63, (char) 0x65, (char) 0x37, (char) 0x37, (char) 0x64,
                       (char) 0x38, (char) 0x32, (char) 0x34, (char) 0x38, (char) 0x32, (char) 0x63,
                       (char) 0x34, (char) 0x32, (char) 0x34, (char) 0x37, (char) 0x32, (char) 0x37,
                       (char) 0x30, (char) 0x30, (char) 0x66, (char) 0x39, (char) 0x63, (char) 0x34,
                       (char) 0x30, (char) 0x35, (char) 0x30, (char) 0x38, (char) 0x36, (char) 0x37,
                       (char) 0x64, (char) 0x34, (char) 0x36, (char) 0x31, (char) 0x64, (char) 0x30,
                       (char) 0x62, (char) 0x62, (char) 0x64, (char) 0x31, (char) 0x36, (char) 0x32,
                       (char) 0x65, (char) 0x34, (char) 0x33, (char) 0x33, (char) 0x39, (char) 0x63,
                       (char) 0x64, (char) 0x39, (char) 0x38, (char) 0x31, (char) 0x34, (char) 0x61,
                       (char) 0x64, (char) 0x61, (char) 0x31, (char) 0x39, (char) 0x34, (char) 0x39,
                       (char) 0x34, (char) 0x64, (char) 0x35, (char) 0x64, (char) 0x38, (char) 0x37,
                       (char) 0x36, (char) 0x34, (char) 0x38, (char) 0x63, (char) 0x39, (char) 0x37,
                       (char) 0x39, (char) 0x31, (char) 0x36, (char) 0x65, (char) 0x64, (char) 0x30,
                       (char) 0x62, (char) 0x65, (char) 0x66, (char) 0x34, (char) 0x65, (char) 0x66,
                       (char) 0x33, (char) 0x31, (char) 0x33, (char) 0x35, (char) 0x65, (char) 0x62,
                       (char) 0x30, (char) 0x35, (char) 0x31, (char) 0x30, (char) 0x63, (char) 0x32,
                       (char) 0x38, (char) 0x64, (char) 0x30, (char) 0x37, (char) 0x37, (char) 0x64,
                       (char) 0x66, (char) 0x31, (char) 0x34, (char) 0x38, (char) 0x61, (char) 0x36,
                       (char) 0x32, (char) 0x32, (char) 0x30, (char) 0x66, (char) 0x36, (char) 0x64,
                       (char) 0x34, (char) 0x35, (char) 0x36, (char) 0x64, (char) 0x39, (char) 0x34,
                       (char) 0x34, (char) 0x61, (char) 0x65, (char) 0x61, (char) 0x65, (char) 0x37,
                       (char) 0x35, (char) 0x36, (char) 0x31, (char) 0x61, (char) 0x61, (char) 0x39,
                       (char) 0x32, (char) 0x36, (char) 0x33, (char) 0x31, (char) 0x63, (char) 0x66,
                       (char) 0x35, (char) 0x38, (char) 0x34, (char) 0x63, (char) 0x34, (char) 0x61,
                       (char) 0x37, (char) 0x62, (char) 0x61, (char) 0x33, (char) 0x32, (char) 0x34,
                       (char) 0x39, (char) 0x39, (char) 0x63, (char) 0x63, (char) 0x61, (char) 0x37,
                       (char) 0x37, (char) 0x35, (char) 0x39, (char) 0x39, (char) 0x31, (char) 0x37,
                       (char) 0x64, (char) 0x34, (char) 0x63, (char) 0x31, (char) 0x37, (char) 0x61,
                       (char) 0x36, (char) 0x64, (char) 0x63, (char) 0x65, (char) 0x34, (char) 0x38,
                       (char) 0x32, (char) 0x36, (char) 0x62, (char) 0x32, (char) 0x66, (char) 0x62,
                       (char) 0x62, (char) 0x35, (char) 0x39, (char) 0x66, (char) 0x61, (char) 0x64,
                       (char) 0x64, (char) 0x30, (char) 0x62, (char) 0x38, (char) 0x61, (char) 0x61,
                       (char) 0x37, (char) 0x66, (char) 0x30, (char) 0x32, (char) 0x30, (char) 0x33,
                       (char) 0x30, (char) 0x31, (char) 0x30, (char) 0x30, (char) 0x30, (char) 0x31,
                       (char) 0x33, (char) 0x30, (char) 0x30, (char) 0x64, (char) 0x30, (char) 0x36,
                       (char) 0x30, (char) 0x39, (char) 0x32, (char) 0x61, (char) 0x38, (char) 0x36,
                       (char) 0x34, (char) 0x38, (char) 0x38, (char) 0x36, (char) 0x66, (char) 0x37,
                       (char) 0x30, (char) 0x64, (char) 0x30, (char) 0x31, (char) 0x30, (char) 0x31,
                       (char) 0x30, (char) 0x35, (char) 0x30, (char) 0x35, (char) 0x30, (char) 0x30,
                       (char) 0x30, (char) 0x33, (char) 0x38, (char) 0x31, (char) 0x38, (char) 0x31,
                       (char) 0x30, (char) 0x30, (char) 0x38, (char) 0x63, (char) 0x30, (char) 0x36,
                       (char) 0x63, (char) 0x63, (char) 0x62, (char) 0x61, (char) 0x62, (char) 0x64,
                       (char) 0x32, (char) 0x32, (char) 0x39, (char) 0x65, (char) 0x34, (char) 0x63,
                       (char) 0x31, (char) 0x35, (char) 0x34, (char) 0x39, (char) 0x33, (char) 0x64,
                       (char) 0x38, (char) 0x61, (char) 0x31, (char) 0x35, (char) 0x63, (char) 0x65,
                       (char) 0x33, (char) 0x61, (char) 0x30, (char) 0x31, (char) 0x65, (char) 0x63,
                       (char) 0x63, (char) 0x37, (char) 0x66, (char) 0x61, (char) 0x61, (char) 0x62,
                       (char) 0x63, (char) 0x35, (char) 0x32, (char) 0x31, (char) 0x33, (char) 0x64,
                       (char) 0x33, (char) 0x35, (char) 0x30, (char) 0x66, (char) 0x61, (char) 0x32,
                       (char) 0x31, (char) 0x39, (char) 0x31, (char) 0x32, (char) 0x32, (char) 0x63,
                       (char) 0x30, (char) 0x64, (char) 0x63, (char) 0x63, (char) 0x32, (char) 0x66,
                       (char) 0x37, (char) 0x66, (char) 0x39, (char) 0x38, (char) 0x65, (char) 0x64,
                       (char) 0x32, (char) 0x30, (char) 0x61, (char) 0x61, (char) 0x38, (char) 0x61,
                       (char) 0x34, (char) 0x65, (char) 0x36, (char) 0x32, (char) 0x37, (char) 0x30,
                       (char) 0x36, (char) 0x32, (char) 0x38, (char) 0x34, (char) 0x38, (char) 0x63,
                       (char) 0x61, (char) 0x32, (char) 0x62, (char) 0x61, (char) 0x64, (char) 0x32,
                       (char) 0x63, (char) 0x65, (char) 0x32, (char) 0x33, (char) 0x36, (char) 0x30,
                       (char) 0x30, (char) 0x64, (char) 0x61, (char) 0x36, (char) 0x30, (char) 0x65,
                       (char) 0x61, (char) 0x32, (char) 0x35, (char) 0x35, (char) 0x62, (char) 0x31,
                       (char) 0x39, (char) 0x33, (char) 0x36, (char) 0x30, (char) 0x36, (char) 0x39,
                       (char) 0x37, (char) 0x36, (char) 0x30, (char) 0x38, (char) 0x32, (char) 0x65,
                       (char) 0x32, (char) 0x38, (char) 0x63, (char) 0x66, (char) 0x32, (char) 0x39,
                       (char) 0x38, (char) 0x66, (char) 0x35, (char) 0x36, (char) 0x63, (char) 0x61,
                       (char) 0x66, (char) 0x61, (char) 0x39, (char) 0x36, (char) 0x30, (char) 0x66,
                       (char) 0x39, (char) 0x37, (char) 0x30, (char) 0x38, (char) 0x64, (char) 0x61,
                       (char) 0x35, (char) 0x39, (char) 0x62, (char) 0x61, (char) 0x38, (char) 0x65,
                       (char) 0x34, (char) 0x39, (char) 0x38, (char) 0x61, (char) 0x30, (char) 0x33,
                       (char) 0x66, (char) 0x64, (char) 0x36, (char) 0x31, (char) 0x30, (char) 0x61,
                       (char) 0x32, (char) 0x30, (char) 0x38, (char) 0x66, (char) 0x32, (char) 0x32,
                       (char) 0x36, (char) 0x64, (char) 0x64, (char) 0x35, (char) 0x66, (char) 0x66,
                       (char) 0x32, (char) 0x36, (char) 0x63, (char) 0x33, (char) 0x31, (char) 0x37,
                       (char) 0x30, (char) 0x65, (char) 0x37, (char) 0x31, (char) 0x61, (char) 0x61,
                       (char) 0x34, (char) 0x63, (char) 0x36, (char) 0x37, (char) 0x31, (char) 0x31,
                       (char) 0x33, (char) 0x61, (char) 0x31, (char) 0x36, (char) 0x38, (char) 0x37,
                       (char) 0x65, (char) 0x37, (char) 0x38, (char) 0x39, (char) 0x35, (char) 0x66,
                       (char) 0x35, (char) 0x37, (char) 0x35, (char) 0x61, (char) 0x35, (char) 0x34,
                       (char) 0x65, (char) 0x63, (char) 0x63, (char) 0x37, (char) 0x66, (char) 0x37,
                       (char) 0x36, (char) 0x33, (char) 0x33, (char) 0x34, (char) 0x30, (char) 0x38,
                       (char) 0x65, (char) 0x35, (char) 0x33, (char) 0x30, (char) 0x37, (char) 0x62,
                       (char) 0x31, (char) 0x66, (char) 0x62, (char) 0x65, (char) 0x37, (char) 0x31,
                       (char) 0x31, (char) 0x34, (char) 0x33, (char) 0x30, (char) 0x64, (char) 0x61,
                       (char) 0x33, (char) 0x30, (char) 0x39, (char) 0x35, (char) 0x63, (char) 0x66,
                       (char) 0x31, (char) 0x63, (char) 0x63, (char) 0x37, (char) 0x39,
                       (char) 0x30};
char signaturePrd[] = {(char) 0x33, (char) 0x30, (char) 0x38, (char) 0x32, (char) 0x30, (char) 0x32,
                       (char) 0x34, (char) 0x39, (char) 0x33, (char) 0x30, (char) 0x38, (char) 0x32,
                       (char) 0x30, (char) 0x31, (char) 0x62, (char) 0x32, (char) 0x61, (char) 0x30,
                       (char) 0x30, (char) 0x33, (char) 0x30, (char) 0x32, (char) 0x30, (char) 0x31,
                       (char) 0x30, (char) 0x32, (char) 0x30, (char) 0x32, (char) 0x30, (char) 0x34,
                       (char) 0x35, (char) 0x34, (char) 0x37, (char) 0x65, (char) 0x63, (char) 0x66,
                       (char) 0x38, (char) 0x32, (char) 0x33, (char) 0x30, (char) 0x30, (char) 0x64,
                       (char) 0x30, (char) 0x36, (char) 0x30, (char) 0x39, (char) 0x32, (char) 0x61,
                       (char) 0x38, (char) 0x36, (char) 0x34, (char) 0x38, (char) 0x38, (char) 0x36,
                       (char) 0x66, (char) 0x37, (char) 0x30, (char) 0x64, (char) 0x30, (char) 0x31,
                       (char) 0x30, (char) 0x31, (char) 0x30, (char) 0x35, (char) 0x30, (char) 0x35,
                       (char) 0x30, (char) 0x30, (char) 0x33, (char) 0x30, (char) 0x36, (char) 0x38,
                       (char) 0x33, (char) 0x31, (char) 0x30, (char) 0x62, (char) 0x33, (char) 0x30,
                       (char) 0x30, (char) 0x39, (char) 0x30, (char) 0x36, (char) 0x30, (char) 0x33,
                       (char) 0x35, (char) 0x35, (char) 0x30, (char) 0x34, (char) 0x30, (char) 0x36,
                       (char) 0x31, (char) 0x33, (char) 0x30, (char) 0x32, (char) 0x33, (char) 0x38,
                       (char) 0x33, (char) 0x36, (char) 0x33, (char) 0x31, (char) 0x31, (char) 0x32,
                       (char) 0x33, (char) 0x30, (char) 0x31, (char) 0x30, (char) 0x30, (char) 0x36,
                       (char) 0x30, (char) 0x33, (char) 0x35, (char) 0x35, (char) 0x30, (char) 0x34,
                       (char) 0x30, (char) 0x38, (char) 0x31, (char) 0x33, (char) 0x30, (char) 0x39,
                       (char) 0x34, (char) 0x37, (char) 0x37, (char) 0x35, (char) 0x36, (char) 0x31,
                       (char) 0x36, (char) 0x65, (char) 0x36, (char) 0x37, (char) 0x34, (char) 0x34,
                       (char) 0x36, (char) 0x66, (char) 0x36, (char) 0x65, (char) 0x36, (char) 0x37,
                       (char) 0x33, (char) 0x31, (char) 0x31, (char) 0x31, (char) 0x33, (char) 0x30,
                       (char) 0x30, (char) 0x66, (char) 0x30, (char) 0x36, (char) 0x30, (char) 0x33,
                       (char) 0x35, (char) 0x35, (char) 0x30, (char) 0x34, (char) 0x30, (char) 0x37,
                       (char) 0x31, (char) 0x33, (char) 0x30, (char) 0x38, (char) 0x35, (char) 0x33,
                       (char) 0x36, (char) 0x38, (char) 0x36, (char) 0x35, (char) 0x36, (char) 0x65,
                       (char) 0x35, (char) 0x61, (char) 0x36, (char) 0x38, (char) 0x36, (char) 0x35,
                       (char) 0x36, (char) 0x65, (char) 0x33, (char) 0x31, (char) 0x30, (char) 0x66,
                       (char) 0x33, (char) 0x30, (char) 0x30, (char) 0x64, (char) 0x30, (char) 0x36,
                       (char) 0x30, (char) 0x33, (char) 0x35, (char) 0x35, (char) 0x30, (char) 0x34,
                       (char) 0x30, (char) 0x61, (char) 0x31, (char) 0x33, (char) 0x30, (char) 0x36,
                       (char) 0x35, (char) 0x30, (char) 0x36, (char) 0x39, (char) 0x36, (char) 0x65,
                       (char) 0x36, (char) 0x37, (char) 0x34, (char) 0x31, (char) 0x36, (char) 0x65,
                       (char) 0x33, (char) 0x31, (char) 0x30, (char) 0x66, (char) 0x33, (char) 0x30,
                       (char) 0x30, (char) 0x64, (char) 0x30, (char) 0x36, (char) 0x30, (char) 0x33,
                       (char) 0x35, (char) 0x35, (char) 0x30, (char) 0x34, (char) 0x30, (char) 0x62,
                       (char) 0x31, (char) 0x33, (char) 0x30, (char) 0x36, (char) 0x35, (char) 0x30,
                       (char) 0x36, (char) 0x39, (char) 0x36, (char) 0x65, (char) 0x36, (char) 0x37,
                       (char) 0x34, (char) 0x31, (char) 0x36, (char) 0x65, (char) 0x33, (char) 0x31,
                       (char) 0x31, (char) 0x30, (char) 0x33, (char) 0x30, (char) 0x30, (char) 0x65,
                       (char) 0x30, (char) 0x36, (char) 0x30, (char) 0x33, (char) 0x35, (char) 0x35,
                       (char) 0x30, (char) 0x34, (char) 0x30, (char) 0x33, (char) 0x31, (char) 0x33,
                       (char) 0x30, (char) 0x37, (char) 0x35, (char) 0x39, (char) 0x37, (char) 0x35,
                       (char) 0x36, (char) 0x35, (char) 0x32, (char) 0x30, (char) 0x34, (char) 0x31,
                       (char) 0x36, (char) 0x65, (char) 0x36, (char) 0x37, (char) 0x33, (char) 0x30,
                       (char) 0x32, (char) 0x30, (char) 0x31, (char) 0x37, (char) 0x30, (char) 0x64,
                       (char) 0x33, (char) 0x31, (char) 0x33, (char) 0x34, (char) 0x33, (char) 0x31,
                       (char) 0x33, (char) 0x32, (char) 0x33, (char) 0x30, (char) 0x33, (char) 0x33,
                       (char) 0x33, (char) 0x30, (char) 0x33, (char) 0x38, (char) 0x33, (char) 0x35,
                       (char) 0x33, (char) 0x33, (char) 0x33, (char) 0x32, (char) 0x33, (char) 0x32,
                       (char) 0x35, (char) 0x61, (char) 0x31, (char) 0x38, (char) 0x30, (char) 0x66,
                       (char) 0x33, (char) 0x33, (char) 0x33, (char) 0x30, (char) 0x33, (char) 0x31,
                       (char) 0x33, (char) 0x33, (char) 0x33, (char) 0x30, (char) 0x33, (char) 0x34,
                       (char) 0x33, (char) 0x30, (char) 0x33, (char) 0x35, (char) 0x33, (char) 0x30,
                       (char) 0x33, (char) 0x38, (char) 0x33, (char) 0x35, (char) 0x33, (char) 0x33,
                       (char) 0x33, (char) 0x32, (char) 0x33, (char) 0x32, (char) 0x35, (char) 0x61,
                       (char) 0x33, (char) 0x30, (char) 0x36, (char) 0x38, (char) 0x33, (char) 0x31,
                       (char) 0x30, (char) 0x62, (char) 0x33, (char) 0x30, (char) 0x30, (char) 0x39,
                       (char) 0x30, (char) 0x36, (char) 0x30, (char) 0x33, (char) 0x35, (char) 0x35,
                       (char) 0x30, (char) 0x34, (char) 0x30, (char) 0x36, (char) 0x31, (char) 0x33,
                       (char) 0x30, (char) 0x32, (char) 0x33, (char) 0x38, (char) 0x33, (char) 0x36,
                       (char) 0x33, (char) 0x31, (char) 0x31, (char) 0x32, (char) 0x33, (char) 0x30,
                       (char) 0x31, (char) 0x30, (char) 0x30, (char) 0x36, (char) 0x30, (char) 0x33,
                       (char) 0x35, (char) 0x35, (char) 0x30, (char) 0x34, (char) 0x30, (char) 0x38,
                       (char) 0x31, (char) 0x33, (char) 0x30, (char) 0x39, (char) 0x34, (char) 0x37,
                       (char) 0x37, (char) 0x35, (char) 0x36, (char) 0x31, (char) 0x36, (char) 0x65,
                       (char) 0x36, (char) 0x37, (char) 0x34, (char) 0x34, (char) 0x36, (char) 0x66,
                       (char) 0x36, (char) 0x65, (char) 0x36, (char) 0x37, (char) 0x33, (char) 0x31,
                       (char) 0x31, (char) 0x31, (char) 0x33, (char) 0x30, (char) 0x30, (char) 0x66,
                       (char) 0x30, (char) 0x36, (char) 0x30, (char) 0x33, (char) 0x35, (char) 0x35,
                       (char) 0x30, (char) 0x34, (char) 0x30, (char) 0x37, (char) 0x31, (char) 0x33,
                       (char) 0x30, (char) 0x38, (char) 0x35, (char) 0x33, (char) 0x36, (char) 0x38,
                       (char) 0x36, (char) 0x35, (char) 0x36, (char) 0x65, (char) 0x35, (char) 0x61,
                       (char) 0x36, (char) 0x38, (char) 0x36, (char) 0x35, (char) 0x36, (char) 0x65,
                       (char) 0x33, (char) 0x31, (char) 0x30, (char) 0x66, (char) 0x33, (char) 0x30,
                       (char) 0x30, (char) 0x64, (char) 0x30, (char) 0x36, (char) 0x30, (char) 0x33,
                       (char) 0x35, (char) 0x35, (char) 0x30, (char) 0x34, (char) 0x30, (char) 0x61,
                       (char) 0x31, (char) 0x33, (char) 0x30, (char) 0x36, (char) 0x35, (char) 0x30,
                       (char) 0x36, (char) 0x39, (char) 0x36, (char) 0x65, (char) 0x36, (char) 0x37,
                       (char) 0x34, (char) 0x31, (char) 0x36, (char) 0x65, (char) 0x33, (char) 0x31,
                       (char) 0x30, (char) 0x66, (char) 0x33, (char) 0x30, (char) 0x30, (char) 0x64,
                       (char) 0x30, (char) 0x36, (char) 0x30, (char) 0x33, (char) 0x35, (char) 0x35,
                       (char) 0x30, (char) 0x34, (char) 0x30, (char) 0x62, (char) 0x31, (char) 0x33,
                       (char) 0x30, (char) 0x36, (char) 0x35, (char) 0x30, (char) 0x36, (char) 0x39,
                       (char) 0x36, (char) 0x65, (char) 0x36, (char) 0x37, (char) 0x34, (char) 0x31,
                       (char) 0x36, (char) 0x65, (char) 0x33, (char) 0x31, (char) 0x31, (char) 0x30,
                       (char) 0x33, (char) 0x30, (char) 0x30, (char) 0x65, (char) 0x30, (char) 0x36,
                       (char) 0x30, (char) 0x33, (char) 0x35, (char) 0x35, (char) 0x30, (char) 0x34,
                       (char) 0x30, (char) 0x33, (char) 0x31, (char) 0x33, (char) 0x30, (char) 0x37,
                       (char) 0x35, (char) 0x39, (char) 0x37, (char) 0x35, (char) 0x36, (char) 0x35,
                       (char) 0x32, (char) 0x30, (char) 0x34, (char) 0x31, (char) 0x36, (char) 0x65,
                       (char) 0x36, (char) 0x37, (char) 0x33, (char) 0x30, (char) 0x38, (char) 0x31,
                       (char) 0x39, (char) 0x66, (char) 0x33, (char) 0x30, (char) 0x30, (char) 0x64,
                       (char) 0x30, (char) 0x36, (char) 0x30, (char) 0x39, (char) 0x32, (char) 0x61,
                       (char) 0x38, (char) 0x36, (char) 0x34, (char) 0x38, (char) 0x38, (char) 0x36,
                       (char) 0x66, (char) 0x37, (char) 0x30, (char) 0x64, (char) 0x30, (char) 0x31,
                       (char) 0x30, (char) 0x31, (char) 0x30, (char) 0x31, (char) 0x30, (char) 0x35,
                       (char) 0x30, (char) 0x30, (char) 0x30, (char) 0x33, (char) 0x38, (char) 0x31,
                       (char) 0x38, (char) 0x64, (char) 0x30, (char) 0x30, (char) 0x33, (char) 0x30,
                       (char) 0x38, (char) 0x31, (char) 0x38, (char) 0x39, (char) 0x30, (char) 0x32,
                       (char) 0x38, (char) 0x31, (char) 0x38, (char) 0x31, (char) 0x30, (char) 0x30,
                       (char) 0x38, (char) 0x33, (char) 0x33, (char) 0x36, (char) 0x65, (char) 0x32,
                       (char) 0x39, (char) 0x37, (char) 0x66, (char) 0x66, (char) 0x64, (char) 0x37,
                       (char) 0x36, (char) 0x31, (char) 0x32, (char) 0x35, (char) 0x31, (char) 0x63,
                       (char) 0x38, (char) 0x34, (char) 0x32, (char) 0x65, (char) 0x62, (char) 0x30,
                       (char) 0x30, (char) 0x39, (char) 0x34, (char) 0x31, (char) 0x37, (char) 0x30,
                       (char) 0x66, (char) 0x63, (char) 0x36, (char) 0x64, (char) 0x66, (char) 0x39,
                       (char) 0x61, (char) 0x35, (char) 0x64, (char) 0x66, (char) 0x39, (char) 0x36,
                       (char) 0x39, (char) 0x64, (char) 0x30, (char) 0x35, (char) 0x66, (char) 0x39,
                       (char) 0x34, (char) 0x65, (char) 0x61, (char) 0x62, (char) 0x33, (char) 0x62,
                       (char) 0x64, (char) 0x33, (char) 0x39, (char) 0x34, (char) 0x61, (char) 0x66,
                       (char) 0x39, (char) 0x39, (char) 0x61, (char) 0x36, (char) 0x31, (char) 0x64,
                       (char) 0x61, (char) 0x66, (char) 0x35, (char) 0x36, (char) 0x66, (char) 0x36,
                       (char) 0x35, (char) 0x62, (char) 0x35, (char) 0x64, (char) 0x36, (char) 0x32,
                       (char) 0x64, (char) 0x31, (char) 0x31, (char) 0x33, (char) 0x63, (char) 0x61,
                       (char) 0x35, (char) 0x34, (char) 0x63, (char) 0x35, (char) 0x37, (char) 0x62,
                       (char) 0x31, (char) 0x39, (char) 0x35, (char) 0x32, (char) 0x65, (char) 0x64,
                       (char) 0x39, (char) 0x66, (char) 0x37, (char) 0x34, (char) 0x39, (char) 0x33,
                       (char) 0x32, (char) 0x30, (char) 0x64, (char) 0x39, (char) 0x36, (char) 0x30,
                       (char) 0x62, (char) 0x32, (char) 0x33, (char) 0x30, (char) 0x66, (char) 0x30,
                       (char) 0x32, (char) 0x34, (char) 0x33, (char) 0x61, (char) 0x64, (char) 0x66,
                       (char) 0x63, (char) 0x61, (char) 0x32, (char) 0x30, (char) 0x61, (char) 0x30,
                       (char) 0x63, (char) 0x61, (char) 0x33, (char) 0x64, (char) 0x38, (char) 0x30,
                       (char) 0x37, (char) 0x64, (char) 0x36, (char) 0x37, (char) 0x65, (char) 0x32,
                       (char) 0x39, (char) 0x30, (char) 0x64, (char) 0x36, (char) 0x61, (char) 0x31,
                       (char) 0x39, (char) 0x36, (char) 0x65, (char) 0x36, (char) 0x30, (char) 0x39,
                       (char) 0x37, (char) 0x31, (char) 0x36, (char) 0x34, (char) 0x33, (char) 0x35,
                       (char) 0x31, (char) 0x30, (char) 0x30, (char) 0x66, (char) 0x31, (char) 0x32,
                       (char) 0x62, (char) 0x30, (char) 0x35, (char) 0x30, (char) 0x35, (char) 0x65,
                       (char) 0x61, (char) 0x31, (char) 0x37, (char) 0x39, (char) 0x39, (char) 0x31,
                       (char) 0x31, (char) 0x39, (char) 0x36, (char) 0x32, (char) 0x30, (char) 0x33,
                       (char) 0x62, (char) 0x66, (char) 0x38, (char) 0x38, (char) 0x63, (char) 0x63,
                       (char) 0x37, (char) 0x34, (char) 0x34, (char) 0x37, (char) 0x62, (char) 0x32,
                       (char) 0x63, (char) 0x62, (char) 0x65, (char) 0x38, (char) 0x66, (char) 0x33,
                       (char) 0x61, (char) 0x65, (char) 0x30, (char) 0x62, (char) 0x38, (char) 0x36,
                       (char) 0x61, (char) 0x36, (char) 0x38, (char) 0x61, (char) 0x61, (char) 0x64,
                       (char) 0x33, (char) 0x39, (char) 0x64, (char) 0x63, (char) 0x64, (char) 0x65,
                       (char) 0x65, (char) 0x35, (char) 0x65, (char) 0x63, (char) 0x62, (char) 0x31,
                       (char) 0x61, (char) 0x30, (char) 0x33, (char) 0x37, (char) 0x37, (char) 0x33,
                       (char) 0x66, (char) 0x64, (char) 0x39, (char) 0x32, (char) 0x61, (char) 0x36,
                       (char) 0x32, (char) 0x36, (char) 0x34, (char) 0x66, (char) 0x37, (char) 0x38,
                       (char) 0x31, (char) 0x61, (char) 0x62, (char) 0x30, (char) 0x37, (char) 0x65,
                       (char) 0x36, (char) 0x65, (char) 0x63, (char) 0x35, (char) 0x34, (char) 0x64,
                       (char) 0x37, (char) 0x37, (char) 0x35, (char) 0x35, (char) 0x30, (char) 0x32,
                       (char) 0x30, (char) 0x33, (char) 0x30, (char) 0x31, (char) 0x30, (char) 0x30,
                       (char) 0x30, (char) 0x31, (char) 0x33, (char) 0x30, (char) 0x30, (char) 0x64,
                       (char) 0x30, (char) 0x36, (char) 0x30, (char) 0x39, (char) 0x32, (char) 0x61,
                       (char) 0x38, (char) 0x36, (char) 0x34, (char) 0x38, (char) 0x38, (char) 0x36,
                       (char) 0x66, (char) 0x37, (char) 0x30, (char) 0x64, (char) 0x30, (char) 0x31,
                       (char) 0x30, (char) 0x31, (char) 0x30, (char) 0x35, (char) 0x30, (char) 0x35,
                       (char) 0x30, (char) 0x30, (char) 0x30, (char) 0x33, (char) 0x38, (char) 0x31,
                       (char) 0x38, (char) 0x31, (char) 0x30, (char) 0x30, (char) 0x38, (char) 0x30,
                       (char) 0x30, (char) 0x35, (char) 0x32, (char) 0x63, (char) 0x65, (char) 0x66,
                       (char) 0x31, (char) 0x34, (char) 0x35, (char) 0x66, (char) 0x38, (char) 0x32,
                       (char) 0x33, (char) 0x66, (char) 0x65, (char) 0x64, (char) 0x35, (char) 0x31,
                       (char) 0x39, (char) 0x39, (char) 0x33, (char) 0x36, (char) 0x63, (char) 0x64,
                       (char) 0x61, (char) 0x30, (char) 0x39, (char) 0x31, (char) 0x65, (char) 0x61,
                       (char) 0x61, (char) 0x35, (char) 0x32, (char) 0x63, (char) 0x39, (char) 0x39,
                       (char) 0x31, (char) 0x62, (char) 0x33, (char) 0x37, (char) 0x32, (char) 0x62,
                       (char) 0x30, (char) 0x34, (char) 0x66, (char) 0x66, (char) 0x38, (char) 0x64,
                       (char) 0x32, (char) 0x64, (char) 0x66, (char) 0x35, (char) 0x35, (char) 0x32,
                       (char) 0x34, (char) 0x31, (char) 0x37, (char) 0x35, (char) 0x38, (char) 0x34,
                       (char) 0x35, (char) 0x35, (char) 0x64, (char) 0x35, (char) 0x63, (char) 0x39,
                       (char) 0x34, (char) 0x30, (char) 0x31, (char) 0x37, (char) 0x64, (char) 0x34,
                       (char) 0x62, (char) 0x36, (char) 0x32, (char) 0x30, (char) 0x36, (char) 0x37,
                       (char) 0x36, (char) 0x36, (char) 0x66, (char) 0x63, (char) 0x61, (char) 0x38,
                       (char) 0x32, (char) 0x66, (char) 0x31, (char) 0x65, (char) 0x30, (char) 0x35,
                       (char) 0x34, (char) 0x39, (char) 0x65, (char) 0x62, (char) 0x36, (char) 0x66,
                       (char) 0x33, (char) 0x37, (char) 0x64, (char) 0x38, (char) 0x66, (char) 0x31,
                       (char) 0x32, (char) 0x36, (char) 0x61, (char) 0x37, (char) 0x62, (char) 0x38,
                       (char) 0x62, (char) 0x30, (char) 0x30, (char) 0x62, (char) 0x32, (char) 0x39,
                       (char) 0x34, (char) 0x66, (char) 0x64, (char) 0x63, (char) 0x37, (char) 0x34,
                       (char) 0x65, (char) 0x61, (char) 0x34, (char) 0x30, (char) 0x64, (char) 0x31,
                       (char) 0x31, (char) 0x62, (char) 0x37, (char) 0x63, (char) 0x37, (char) 0x64,
                       (char) 0x34, (char) 0x30, (char) 0x30, (char) 0x37, (char) 0x61, (char) 0x62,
                       (char) 0x33, (char) 0x35, (char) 0x65, (char) 0x39, (char) 0x34, (char) 0x33,
                       (char) 0x35, (char) 0x38, (char) 0x37, (char) 0x30, (char) 0x63, (char) 0x34,
                       (char) 0x66, (char) 0x62, (char) 0x34, (char) 0x39, (char) 0x33, (char) 0x61,
                       (char) 0x35, (char) 0x62, (char) 0x34, (char) 0x61, (char) 0x31, (char) 0x37,
                       (char) 0x32, (char) 0x62, (char) 0x34, (char) 0x61, (char) 0x38, (char) 0x65,
                       (char) 0x32, (char) 0x66, (char) 0x33, (char) 0x63, (char) 0x65, (char) 0x61,
                       (char) 0x32, (char) 0x32, (char) 0x36, (char) 0x31, (char) 0x36, (char) 0x34,
                       (char) 0x64, (char) 0x31, (char) 0x37, (char) 0x34, (char) 0x37, (char) 0x64,
                       (char) 0x35, (char) 0x34, (char) 0x30, (char) 0x39, (char) 0x66, (char) 0x65,
                       (char) 0x34, (char) 0x31, (char) 0x61, (char) 0x39, (char) 0x37, (char) 0x64,
                       (char) 0x31, (char) 0x66, (char) 0x36, (char) 0x66, (char) 0x64, (char) 0x39,
                       (char) 0x33, (char) 0x34, (char) 0x36, (char) 0x31, (char) 0x66, (char) 0x36,
                       (char) 0x63, (char) 0x33, (char) 0x64, (char) 0x62, (char) 0x38, (char) 0x62,
                       (char) 0x61, (char) 0x63, (char) 0x63, (char) 0x36, (char) 0x64, (char) 0x62,
                       (char) 0x65, (char) 0x38, (char) 0x66, (char) 0x30, (char) 0x31, (char) 0x36,
                       (char) 0x31, (char) 0x64, (char) 0x31, (char) 0x63, (char) 0x34, (char) 0x39,
                       (char) 0x30, (char) 0x30, (char) 0x64, (char) 0x66, (char) 0x39, (char) 0x37,
                       (char) 0x66, (char) 0x61, (char) 0x63, (char) 0x65, (char) 0x66, (char) 0x30,
                       (char) 0x32, (char) 0x31, (char) 0x31, (char) 0x63, (char) 0x65, (char) 0x34,
                       (char) 0x30, (char) 0x35};
int signatureStgLength = 978;
int signaturePrdLength = 1178;
//加密库改造新key测试环境sha1 key
const char *sha1AppNewStg = "9be26b1c6dac4aabb202a14d2cea5b2b";
//加密库改造新key生产环境sha1 key
const char *sha1AppNewPrd = "45d33423e94e4ad1976d394ef4cf0d26";
//APP测试环境sha1 key
const char *sha1AppStg = "0633179746fe4eda90c7e8d4c3027988";
//APP生产环境sha1 key
const char *sha1AppPrd = "6de5863c48b947a3bae7424c36cd5e98";
//任意门测试环境sha1 key
const char *sha1AnyDoorStg = "0633179746fe4eda90c7e8d4c3027988";
//任意门生产环境sha1 key
const char *sha1AnyDoorPrd = "895ad1ed698f4eda9dfae8d4c3089568";
//地图sha1 key(无生产测试环境之分)
const char *sha1Map = "27696438b690902ddf2a105f868161ea";
//商户测试环境sha1 key
const char *sha1ShopInfoStg = "167fbe12b9554519866ad67c08112593";
//商户生产环境sha1 key
const char *sha1ShopInfoPrd = "4e7e377891dc4d958286b398550322ec";
//SDK对账测试环境sha1 key
const char *sha1SdkBillingStg = "1157e85a3714940a8d2a84fee31262d5";
//SDK对账生产环境sha1 key
const char *sha1SdkBillingPrd = "343d47e0029dccc6491ed8a2808e1bcc";

const char *SHA1_KEY_PADC_HUZHONG_PRD = "442f8924ccfd4ef1af8d7a8f5b58932b";
const char *SHA1_KEY_PADC_HUZHONG_STG = "5b7b064f5455b646e1deaddc5ef91e6f";

const char *SHA1_KEY_PADC_FLOW_PRD = "93f1fd9d876246c691dba4cc0788d80d";
const char *SHA1_KEY_PADC_FLOW_STG = "5b7b064f5455b646e1deaddc5ef91e6f";

//包名
const char *appPackageName = "com.pingan.pingandata";
//加密库改造新key测试环境3des key
const char *des3keyAppNewStg = "9f304ba751474278bee4267f";
//加密库改造新key生产环境3des key
const char *des3keyAppNewPrd = "199c4ed2b56042ba953df125";
//APP数据存储3des key(无生产测试环境之分)
const char *des3keyCache = "XKr9p8XeywPvMKNjgIIqECQB";
//原APP测试环境3des key
const char *des3keyStg = "12d4161d94b957ea313aeb04";
//原APP生产环境3des key
const char *des3keyPrd = "105d7b9773a312d704f1f4a5";
const char *des3Vector = "01234567";


//RsaKey
const char *rsaKeyStg = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDeWaoBYR3Z1x9jnS7IKrmYaCs38rE5GBW19tADLs+Ui2jG1jy8Pt/yn5t9LaMr1v+T9HPfjqlDZHJkE3DUy7cK6u1UskCdlISjlB/uBja6Usjg/Wdvfc8Mn7Ize53rlUdk+3U3T+yr8rVJZkpTBinjGAq83XT+Kcl2mUGv4Yw13QIDAQAB";
const char *rsaKeyPrd = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDoiLM6EioiXotTFbVywVzuPBK8uWJwhxnjUE6tmQt0Zl7FbUcRrSFBF0KxhvL/CvI0WXcSWZ8BiZjA+j40Dhao053/5xL0msOvDTThgleXcwAEH1S+1gEcmKK/GAp+u71MTwtq154ufLxSLd+HMTlVOUk4z1HmK3wd9a51qyRlZQIDAQAB";


const char *app_cache = "APP_CACHE";
const char *sdk = "SDK";
const char *app_new = "APP_NEW";
const char *anydoor = "ANYDOOR";
const char *app = "APP";
const char *map = "MAP";
const char *shop_info = "SHOP_INFO";
const char *sdk_billing = "SDK_BILLING";
const char *mpush = "MPUSH";
const char *LOGTAG = "WiFiSecure";

const char *PADC_HUZHONG = "PADC_HUZHONG";
const char *PADC_FLOW = "PADC_FLOW";

unsigned char globalLogSwitchOn;

char HexCode[16] = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f'};

extern "C"
jstring
Java_com_pingan_pingandata_secure_WiFiSecure_getSignature(JNIEnv *jEnv, jobject instance,
                                                          jobject contextObject,
                                                          jstring environment, jstring keyType,
                                                          jobjectArray arr) {
    jboolean isPrd = checkPrd(jEnv, environment, &globalLogSwitchOn);

    // 判断是否是合法的应用
    if (!isValidAPK(jEnv, contextObject, isPrd)) {
        return NULL;
    }

    // 对传入的字符串数组加上默认的密码
    int arrayLength = jEnv->GetArrayLength(arr) + 1;
    if (arrayLength <= 1) {
        return NULL;
    }

    jclass stringClass = jEnv->FindClass("java/lang/String");
    jobjectArray stringArray = jEnv->NewObjectArray(arrayLength, stringClass, NULL);
    jEnv->DeleteLocalRef(stringClass);
    for (int i = 0; i < arrayLength - 1; i++) {
        jEnv->SetObjectArrayElement(stringArray, i, jEnv->GetObjectArrayElement(arr, i));
    }

    const char *sha1salt = getSha1SecureKey(jEnv, keyType, isPrd);;
    jEnv->SetObjectArrayElement(stringArray, arrayLength - 1, jEnv->NewStringUTF(sha1salt));

    // 排序
    jclass clzArrays = jEnv->FindClass("java/util/Arrays");
    jmethodID methodID = jEnv->GetStaticMethodID(clzArrays, "sort", "([Ljava/lang/Object;)V");
    jEnv->CallStaticVoidMethod(clzArrays, methodID, stringArray);

    // 拼接
    jclass clzStringBuilder = jEnv->FindClass("java/lang/StringBuilder");
    methodID = jEnv->GetMethodID(clzStringBuilder, "<init>", "()V");
    jobject sbTmp = jEnv->NewObject(clzStringBuilder, methodID);
    methodID = jEnv->GetMethodID(clzStringBuilder, "append",
                                 "(Ljava/lang/String;)Ljava/lang/StringBuilder;");
    for (int i = 0; i < arrayLength; i++) {
        jEnv->CallObjectMethod(sbTmp, methodID, jEnv->GetObjectArrayElement(stringArray, i));
    }

    methodID = jEnv->GetMethodID(clzStringBuilder, "toString", "()Ljava/lang/String;");
    jstring jstrUndone = (jstring) jEnv->CallObjectMethod(sbTmp, methodID);
    jEnv->DeleteLocalRef(clzStringBuilder);

    const char *cstrUndone = jEnv->GetStringUTFChars(jstrUndone, NULL);
    log(cstrUndone);
    jEnv->ReleaseStringUTFChars(jstrUndone, cstrUndone);

    // SHA1
    jclass clzMessageDigest = jEnv->FindClass("java/security/MessageDigest");
    methodID = jEnv->GetStaticMethodID(clzMessageDigest, "getInstance",
                                       "(Ljava/lang/String;)Ljava/security/MessageDigest;");
    jobject objMessageDigest = jEnv->CallStaticObjectMethod(clzMessageDigest, methodID,
                                                            jEnv->NewStringUTF("SHA-1"));

    jclass clzString = jEnv->FindClass("java/lang/String");
    methodID = jEnv->GetMethodID(clzString, "getBytes", "()[B");
    jbyteArray byteArrayUndone = (jbyteArray) jEnv->CallObjectMethod(jstrUndone, methodID);
    jEnv->DeleteLocalRef(clzString);

    methodID = jEnv->GetMethodID(clzMessageDigest, "digest", "([B)[B");
    jbyteArray byteArrayDone = (jbyteArray) jEnv->CallObjectMethod(objMessageDigest, methodID,
                                                                   byteArrayUndone);

    //toHexString
    jsize array_size = jEnv->GetArrayLength(byteArrayDone);
    jbyte *sha1 = jEnv->GetByteArrayElements(byteArrayDone, NULL);
    char *hex_sha = (char *) malloc(array_size * 2 + 1);
    for (int i = 0; i < array_size; ++i) {
        hex_sha[2 * i + 1] = HexCode[sha1[i] & 0xF];
        hex_sha[2 * i] = HexCode[sha1[i] >> 4 & 0xF];
    }
    hex_sha[array_size * 2] = '\0';
    jstring result = jEnv->NewStringUTF(hex_sha);
    free(hex_sha);
    return result;
}

void log(const char *msg) {
    if (globalLogSwitchOn) {
        __android_log_print(ANDROID_LOG_DEBUG, LOGTAG, "%s", msg);
    }
}

jboolean isValidAPK(JNIEnv *jEnv, jobject context_object, jboolean isPrd) {
    jclass context_class = jEnv->GetObjectClass(context_object);

    //context.getPackageManager()
    jmethodID methodId = jEnv->GetMethodID(context_class, "getPackageManager",
                                           "()Landroid/content/pm/PackageManager;");
    jobject package_manager_object = jEnv->CallObjectMethod(context_object, methodId);
    if (package_manager_object == NULL) {
        log("getPackageManager() Failed!");
        return JNI_FALSE;
    }

    //context.getPackageName()
    methodId = jEnv->GetMethodID(context_class, "getPackageName", "()Ljava/lang/String;");
    jstring package_name_string = (jstring) jEnv->CallObjectMethod(context_object, methodId);
    if (package_name_string == NULL) {
        log("getPackageName() Failed!");
        return JNI_FALSE;
    }

    jboolean isCopy;
    const char *packageNameNativeString = jEnv->GetStringUTFChars(package_name_string, &isCopy);
    if (strcmp(packageNameNativeString, appPackageName) != 0) {
        jEnv->ReleaseStringUTFChars(package_name_string, packageNameNativeString);
        log("app package name incorrect");
        return JNI_FALSE;
    }
    jEnv->ReleaseStringUTFChars(package_name_string, packageNameNativeString);

    jEnv->DeleteLocalRef(context_class);

    //PackageManager.getPackageInfo(Sting, int)
    jclass pack_manager_class = jEnv->GetObjectClass(package_manager_object);
    methodId = jEnv->GetMethodID(pack_manager_class, "getPackageInfo",
                                 "(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;");
    jEnv->DeleteLocalRef(pack_manager_class);
    jobject package_info_object = jEnv->CallObjectMethod(package_manager_object, methodId,
                                                         package_name_string, 64);
    if (package_info_object == NULL) {
        log("getPackageInfo() Failed!");
        return JNI_FALSE;
    }

    jEnv->DeleteLocalRef(package_manager_object);

    //PackageInfo.signatures[0]
    jclass package_info_class = jEnv->GetObjectClass(package_info_object);
    jfieldID fieldId = jEnv->GetFieldID(package_info_class, "signatures",
                                        "[Landroid/content/pm/Signature;");
    jEnv->DeleteLocalRef(package_info_class);
    jobjectArray signature_object_array = (jobjectArray) jEnv->GetObjectField(package_info_object,
                                                                              fieldId);
    if (signature_object_array == NULL) {
        log("PackageInfo.signatures[] is null");
        return JNI_FALSE;
    }
    jobject signature_object = jEnv->GetObjectArrayElement(signature_object_array, 0);

    jEnv->DeleteLocalRef(package_info_object);
    jEnv->DeleteLocalRef(signature_object_array);

    //Signature.toCharsString()
    jclass signature_class = jEnv->GetObjectClass(signature_object);
    methodId = jEnv->GetMethodID(signature_class, "toCharsString", "()Ljava/lang/String;");
    jEnv->DeleteLocalRef(signature_class);
    jstring signature_string = (jstring) jEnv->CallObjectMethod(signature_object, methodId);
    jEnv->DeleteLocalRef(signature_object);
    jclass clzString = jEnv->FindClass("java/lang/String");
    methodId = jEnv->GetMethodID(clzString, "toCharArray", "()[C");
    jcharArray charArraySignature = (jcharArray) jEnv->CallObjectMethod(signature_string, methodId);
    jEnv->DeleteLocalRef(clzString);
    jEnv->DeleteLocalRef(signature_string);
    jint size = jEnv->GetArrayLength(charArraySignature);
    if (!isPrd) {
        if (size != signatureStgLength && size != signaturePrdLength) {
            log("size not equal");
            return JNI_FALSE;
        }
    } else {
        if (size != signaturePrdLength) {
            log("size not equal");
            return JNI_FALSE;
        }
    }
    char signatureNative[size];
    jchar *jpwdPtr = jEnv->GetCharArrayElements(charArraySignature, &isCopy);
    for (int i = 0; i < size; i++) {
        *(signatureNative + i) = (char) (*(jpwdPtr + i));
    }
    jEnv->ReleaseCharArrayElements(charArraySignature, jpwdPtr, 0);
    if (!isPrd) {
        if (isEquals(signatureNative, signatureStg, size, signatureStgLength) || isEquals(signatureNative, signaturePrd, size, signaturePrdLength)) {
            log("stg signature");
            return JNI_TRUE;
        }
    } else {
        if (isEquals(signatureNative, signaturePrd, size, signaturePrdLength)) {
            log("uat/prd 环境下签名匹配");
            return JNI_TRUE;
        }
    }
    return JNI_FALSE;

//    const char *signatureNativeString = jEnv->GetStringUTFChars(signature_string, &isCopy);
//    if (!isPrd) {
//        log("is stg");
//        if (isEqualsIgnoreCase(jEnv, jEnv->NewStringUTF(appSignaturePrd), signature_string)) {
//            log("stg 环境下签名匹配");
//            jEnv->ReleaseStringUTFChars(signature_string, signatureNativeString);
//            return JNI_TRUE;
//        }
//    } else {
//        if (isEqualsIgnoreCase(jEnv,jEnv->NewStringUTF(appSignaturePrd), signature_string)) {
//            jEnv->ReleaseStringUTFChars(signature_string, signatureNativeString);
//            return JNI_TRUE;
//        }
//    }
//
//
//    // Don't forget to release native string
//    jEnv->ReleaseStringUTFChars(signature_string, signatureNativeString);
//    return JNI_FALSE;
}

jboolean checkPrd(JNIEnv *env, jstring environment_, unsigned char *pLogSwitch) {
    const char *environment = env->GetStringUTFChars(environment_, 0);
    jboolean isPrd, logSwitch;
    if (strcasecmp(environment, "stg") == 0) {
        logSwitch = JNI_TRUE;
        isPrd = JNI_FALSE;
    } else if (strcasecmp(environment, "uat") == 0) {
        logSwitch = JNI_TRUE;
        isPrd = JNI_TRUE;
    } else if (strcasecmp(environment, "prd") == 0) {
        logSwitch = JNI_FALSE;
        isPrd = JNI_TRUE;
    }
    env->ReleaseStringUTFChars(environment_, environment);
    if (pLogSwitch) {
        *pLogSwitch = logSwitch;
    }

    return isPrd;
}


extern "C"
jboolean JNICALL
Java_com_pingan_pingandata_secure_WiFiSecure_isValidAPK(JNIEnv *env, jobject instance,
                                                        jobject context, jstring environment_) {
    jboolean isPrd = checkPrd(env, environment_, &globalLogSwitchOn);
    return isValidAPK(env, context, isPrd);
}


//jboolean isEqualsIgnoreCase(JNIEnv *jEnv, jstring s1, jstring s2) {
//    log("start EqualsIgnoreCase");
//    jclass stringClass = jEnv->FindClass("java/lang/String");
////    jmethodID methodID = jEnv->GetMethodID(stringClass, "<init>", "(Ljava/lang/String;)V");
////    jobject s = jEnv->NewObject(stringClass, methodID, s1);
//    jmethodID methodID = jEnv->GetMethodID(stringClass, "equalsIgnoreCase",
//                                           "(Ljava/lang/String;)Z");
//    jboolean isEquals = (jboolean) jEnv->CallBooleanMethod(s1, methodID, s2);
//    if (isEquals) {
//        log("字符串相同");
//    } else {
//        log("字符串不相同");
//    }
//    log("end EqualsIgnoreCase");
//    jEnv->DeleteLocalRef(stringClass);
//    return isEquals;
//}

jboolean isEquals(const char char1[], const char char2[], int size,int sizeLocal) {
    log("start isEquals");
    if (size != sizeLocal) {
        log("字符串len不相同");
        return JNI_FALSE;
    }
    for (int i = 0; i < size; i++) {
        if (char1[i] != char2[i]) {
            log("字符串不相同");
            return JNI_FALSE;
        }
    }
    log("字符串相同");
    return JNI_TRUE;
}

const char *getSha1SecureKey(JNIEnv *env, jstring keyType, jboolean isPrd) {
    const char *type = env->GetStringUTFChars(keyType, 0);
    const char *key = NULL;
    if (strcasecmp(type, app_new) == 0) {
        key = isPrd ? sha1AppNewPrd : sha1AppNewStg;
    } else if (strcasecmp(type, anydoor) == 0) {
        key = isPrd ? sha1AnyDoorPrd : sha1AnyDoorStg;
    } else if (strcasecmp(type, app) == 0 || strcasecmp(type, mpush) == 0 ||
               strcasecmp(type, sdk) == 0) {
        key = isPrd ? sha1AppPrd : sha1AppStg;
    } else if (strcasecmp(type, shop_info) == 0) {
        key = isPrd ? sha1ShopInfoPrd : sha1ShopInfoStg;
    } else if (strcasecmp(type, sdk_billing) == 0) {
        key = isPrd ? sha1SdkBillingPrd : sha1SdkBillingStg;
    } else if (strcasecmp(type, map) == 0) {
        key = sha1Map;
    } else if (strcasecmp(type, PADC_HUZHONG) == 0) {
        key = isPrd ? SHA1_KEY_PADC_HUZHONG_PRD : SHA1_KEY_PADC_HUZHONG_STG;
    } else if (strcasecmp(type, PADC_FLOW) == 0) {
        key = isPrd ? SHA1_KEY_PADC_FLOW_PRD : SHA1_KEY_PADC_FLOW_STG;
    }

    env->ReleaseStringUTFChars(keyType, type);
    return key;
}

const char *getDes3SecureKey(JNIEnv *env, jstring keyType, jboolean isPrd) {
    const char *type = env->GetStringUTFChars(keyType, 0);
    if (strcasecmp(type, app_new) == 0) {
        env->ReleaseStringUTFChars(keyType, type);
        return isPrd ? des3keyAppNewPrd : des3keyAppNewStg;
    } else if (strcasecmp(type, app_cache) == 0) {
        env->ReleaseStringUTFChars(keyType, type);
        return des3keyCache;
    } else if (strcasecmp(type, app) == 0) {
        env->ReleaseStringUTFChars(keyType, type);
        return isPrd ? des3keyPrd : des3keyStg;
    }
}


extern "C"
JNIEXPORT jstring JNICALL
Java_com_pingan_pingandata_secure_WiFiSecure_getRsaKey(JNIEnv *jEnv, jobject instance,
                                                       jobject contextObject, jstring environment) {
    jboolean isPrd = checkPrd(jEnv, environment, &globalLogSwitchOn);

    // 判断是否是合法的应用
    if (!isValidAPK(jEnv, contextObject, isPrd)) {
        return NULL;
    }
    const char *rsaKey = rsaKeyStg;
    if (isPrd) {
        rsaKey = rsaKeyPrd;
    }

    return jEnv->NewStringUTF(rsaKey);
}

extern "C"
jbyteArray JNICALL
Java_com_pingan_pingandata_secure_WiFiSecure_des3Encode(JNIEnv *jEnv, jobject instance,
                                                        jobject context, jstring environment,
                                                        jbyteArray plainBytes, jstring keyType_) {

    jboolean isPrd = checkPrd(jEnv, environment, &globalLogSwitchOn);

    if (!isValidAPK(jEnv, context, isPrd)) {
        return NULL;
    }

    jmethodID methodID = NULL;

    // DESedeKeySpec spec = new DESedeKeySpec(key.getBytes());
    jclass desedeKeySpecClass = jEnv->FindClass("javax/crypto/spec/DESedeKeySpec");

    const char *key = getDes3SecureKey(jEnv, keyType_, isPrd);
    jbyteArray bytes = jEnv->NewByteArray(strlen(key));
    jEnv->SetByteArrayRegion(bytes, 0, strlen(key), (const jbyte *) key);

    methodID = jEnv->GetMethodID(desedeKeySpecClass, "<init>", "([B)V");
    jobject desedeKeySpec = jEnv->NewObject(desedeKeySpecClass, methodID, bytes);
    jEnv->DeleteLocalRef(desedeKeySpecClass);

    // SecretKeyFactory keyfactory = SecretKeyFactory.getInstance("desede");
    jclass secretKeyFactoryClass = jEnv->FindClass("javax/crypto/SecretKeyFactory");
    if (jEnv->ExceptionCheck()) {
        log("exception in finding SecretKeyFactory");
        return NULL;
    }

    methodID = jEnv->GetStaticMethodID(secretKeyFactoryClass, "getInstance",
                                       "(Ljava/lang/String;)Ljavax/crypto/SecretKeyFactory;");
    if (jEnv->ExceptionCheck()) {
        log("exception in find getInstance");
        return NULL;
    }

    jobject secretKeyFactory = jEnv->CallStaticObjectMethod(secretKeyFactoryClass, methodID,
                                                            jEnv->NewStringUTF("desede"));

    // deskey = keyfactory.generateSecret(spec);
    methodID = jEnv->GetMethodID(secretKeyFactoryClass, "generateSecret",
                                 "(Ljava/security/spec/KeySpec;)Ljavax/crypto/SecretKey;");
    if (jEnv->ExceptionCheck()) {
        log("exception in getMethodID");
        return NULL;
    }

    jobject deskey = jEnv->CallObjectMethod(secretKeyFactory, methodID, desedeKeySpec);
    jEnv->DeleteLocalRef(secretKeyFactoryClass);

    // Cipher cipher = Cipher.getInstance("desede/CBC/PKCS5Padding");
    jclass cipherClass = jEnv->FindClass("javax/crypto/Cipher");
    methodID = jEnv->GetStaticMethodID(cipherClass, "getInstance",
                                       "(Ljava/lang/String;)Ljavax/crypto/Cipher;");
    jobject cipher = jEnv->CallStaticObjectMethod(cipherClass, methodID,
                                                  jEnv->NewStringUTF("desede/CBC/PKCS5Padding"));
    if (jEnv->ExceptionCheck()) {
        log("exception in Cipher.getInstance");
    }


    // IvParameterSpec ips = new IvParameterSpec(iv.getBytes());
    bytes = jEnv->NewByteArray(strlen(des3Vector));
    jEnv->SetByteArrayRegion(bytes, 0, strlen(des3Vector), (const jbyte *) des3Vector);
    jclass ivParameterSpecClass = jEnv->FindClass("javax/crypto/spec/IvParameterSpec");
    methodID = jEnv->GetMethodID(ivParameterSpecClass, "<init>", "([B)V");
    jobject ivParameterSpec = jEnv->NewObject(ivParameterSpecClass, methodID, bytes);
    jEnv->DeleteLocalRef(ivParameterSpecClass);

    // cipher.init(Cipher.ENCRYPT_MODE, deskey, ips);
    methodID = jEnv->GetMethodID(cipherClass, "init",
                                 "(ILjava/security/Key;Ljava/security/spec/AlgorithmParameterSpec;)V");
    if (jEnv->ExceptionCheck()) {
        log("exception in getting methodID");
    }

    jEnv->CallVoidMethod(cipher, methodID, 1, deskey, ivParameterSpec);
    if (jEnv->ExceptionCheck()) {
        log("exception in init");
    }

    // encryptData = cipher.doFinal(plainText.getBytes(encoding));
//    jclass stringClass = jEnv->FindClass("java/lang/String");
//    methodID = jEnv->GetMethodID(stringClass, "getBytes", "()[B");
//    bytes = (jbyteArray) jEnv->CallObjectMethod(plainText_, methodID);

    methodID = jEnv->GetMethodID(cipherClass, "doFinal", "([B)[B");
    jbyteArray encryptData = (jbyteArray) jEnv->CallObjectMethod(cipher, methodID, plainBytes);
    jEnv->DeleteLocalRef(cipherClass);

//    jclass base64 = jEnv->FindClass("cn/core/net/secure/Base64");
//    methodID = jEnv->GetStaticMethodID(base64, "encode", "([B)Ljava/lang/String;");
//    jstring result = (jstring) jEnv->CallStaticObjectMethod(base64, methodID, encryptData);
//    jEnv->DeleteLocalRef(base64);

    return encryptData;
}


extern "C"
jbyteArray JNICALL
Java_com_pingan_pingandata_secure_WiFiSecure_des3Decode(JNIEnv *jEnv, jobject instance,
                                                        jobject context, jstring environment,
                                                        jbyteArray encryptBytes, jstring keyType_) {
    jboolean isPrd = checkPrd(jEnv, environment, &globalLogSwitchOn);
    if (!isValidAPK(jEnv, context, isPrd)) {
        return NULL;
    }


    jmethodID methodID = NULL;

    // DESedeKeySpec spec = new DESedeKeySpec(key.getBytes());
    jclass desedeKeySpecClass = jEnv->FindClass("javax/crypto/spec/DESedeKeySpec");
    const char *key = getDes3SecureKey(jEnv, keyType_, isPrd);
    jbyteArray bytes = jEnv->NewByteArray(strlen(key));
    jEnv->SetByteArrayRegion(bytes, 0, strlen(key), (const jbyte *) key);

    methodID = jEnv->GetMethodID(desedeKeySpecClass, "<init>", "([B)V");
    jobject desedeKeySpec = jEnv->NewObject(desedeKeySpecClass, methodID, bytes);
    jEnv->DeleteLocalRef(desedeKeySpecClass);

    // SecretKeyFactory keyfactory = SecretKeyFactory.getInstance("desede");
    jclass secretKeyFactoryClass = jEnv->FindClass("javax/crypto/SecretKeyFactory");
    if (jEnv->ExceptionCheck()) {
        log("exception in finding SecretKeyFactory");
        return NULL;
    }

    methodID = jEnv->GetStaticMethodID(secretKeyFactoryClass, "getInstance",
                                       "(Ljava/lang/String;)Ljavax/crypto/SecretKeyFactory;");
    if (jEnv->ExceptionCheck()) {
        log("exception in find getInstance");
        return NULL;
    }

    jobject secretKeyFactory = jEnv->CallStaticObjectMethod(secretKeyFactoryClass, methodID,
                                                            jEnv->NewStringUTF("desede"));

    // deskey = keyfactory.generateSecret(spec);
    methodID = jEnv->GetMethodID(secretKeyFactoryClass, "generateSecret",
                                 "(Ljava/security/spec/KeySpec;)Ljavax/crypto/SecretKey;");
    if (jEnv->ExceptionCheck()) {
        log("exception in getMethodID");
        return NULL;
    }

    jobject deskey = jEnv->CallObjectMethod(secretKeyFactory, methodID, desedeKeySpec);
    jEnv->DeleteLocalRef(secretKeyFactoryClass);

    // Cipher cipher = Cipher.getInstance("desede/CBC/PKCS5Padding");
    jclass cipherClass = jEnv->FindClass("javax/crypto/Cipher");
    methodID = jEnv->GetStaticMethodID(cipherClass, "getInstance",
                                       "(Ljava/lang/String;)Ljavax/crypto/Cipher;");
    jobject cipher = jEnv->CallStaticObjectMethod(cipherClass, methodID,
                                                  jEnv->NewStringUTF("desede/CBC/PKCS5Padding"));
    if (jEnv->ExceptionCheck()) {
        log("exception in Cipher.getInstance");
    }


    // IvParameterSpec ips = new IvParameterSpec(iv.getBytes());
    bytes = jEnv->NewByteArray(strlen(des3Vector));
    jEnv->SetByteArrayRegion(bytes, 0, strlen(des3Vector), (const jbyte *) des3Vector);
    jclass ivParameterSpecClass = jEnv->FindClass("javax/crypto/spec/IvParameterSpec");
    methodID = jEnv->GetMethodID(ivParameterSpecClass, "<init>", "([B)V");
    jobject ivParameterSpec = jEnv->NewObject(ivParameterSpecClass, methodID, bytes);
    jEnv->DeleteLocalRef(ivParameterSpecClass);

    //  cipher.init(Cipher.DECRYPT_MODE, deskey, ips);
    methodID = jEnv->GetMethodID(cipherClass, "init",
                                 "(ILjava/security/Key;Ljava/security/spec/AlgorithmParameterSpec;)V");
    if (jEnv->ExceptionCheck()) {
        log("exception in getting methodID");
    }

    jEnv->CallVoidMethod(cipher, methodID, 2, deskey, ivParameterSpec);
    if (jEnv->ExceptionCheck()) {
        log("exception in init");
    }

    // decryptData = cipher.doFinal(Base64.decode(encryptText));
//    jclass base64 = jEnv->FindClass("cn/core/net/secure/Base64");
//    methodID = jEnv->GetStaticMethodID(base64, "decode", "(Ljava/lang/String;)[B");
//    bytes = (jbyteArray) jEnv->CallStaticObjectMethod(base64, methodID, encryptText_);
//    jEnv->DeleteLocalRef(base64);

    methodID = jEnv->GetMethodID(cipherClass, "doFinal", "([B)[B");
    jbyteArray encryptData = (jbyteArray) jEnv->CallObjectMethod(cipher, methodID, encryptBytes);
    jEnv->DeleteLocalRef(cipherClass);

//    if (decryptData != null) {
//        result = new String(decryptData, encoding);
//    } else {
//        return "";
//    }
//    if (jEnv->GetArrayLength(encryptData) > 0) {
//        jclass strClass = jEnv->FindClass("Ljava/lang/String;");
//        jmethodID methodID = jEnv->GetMethodID(strClass, "<init>", "([BLjava/lang/String;)V");
//        jstring encoding = jEnv->NewStringUTF("utf-8");
//        return (jstring) jEnv->NewObject(strClass, methodID, bytes, encoding);
//    } else {
//        return encryptData;
//    }
    return encryptData;
}